// ============================================
// CONSCIOUS DISCIPLINE 3-PART SCRIPT
// ============================================

export interface ScriptPart {
  title: string;
  script: string;
}

export type DetectedCategory = "warmth" | "structure" | "autonomy" | "calm" | "curiosity" | "conversation";

export interface ConsciousDisciplineResponse {
  frameworkUsed: string;
  toneUsed: string;
  part1: ScriptPart;  // GET ATTENTION
  part2: ScriptPart;  // SHOW CONSEQUENCE
  part3: ScriptPart;  // REAFFIRM CHARACTER
  detectedCategory?: DetectedCategory;
  parentMantra: string;
  deliveryTip: string;
  // Premium fields (optional)
  whyThisWorks?: string | null;
  proactiveFollowUp?: string | null;
  frameworkReasoning?: string | null;
}

// Legacy alias for backwards compatibility
export type SturdyPilotScript = ConsciousDisciplineResponse;

// Request structure for crisis script generation
export interface CrisisFormRequest {
  situation: string;
  childAge: string;
  neurotype: string;
  isPremium?: boolean;
}

// ============================================
// PROACTIVE "WHAT IF" SCRIPT
// ============================================

export interface ProactiveScript {
  proactiveScript: string;  // The complete "What if..." conversation starter
  practicePrompt: string;   // Follow-up activity suggestion
  parentTip: string;        // Coaching note for the parent
}

export interface ProactiveScriptRequest {
  scenario: string;
  childAge: string;
  neurotype: string;
}

// ============================================
// DATABASE TYPES
// ============================================

export interface Child {
  id: string;
  name: string;
  birth_date?: string;
  neurotype: string;
  parent_id: string;
  triggers?: string[];
  created_at?: string;
  updated_at?: string;
}

export interface Script {
  id: string;
  parent_id: string;
  child_id?: string;
  situation: string;
  script_text: string;
  is_favorite: boolean;
  created_at: string;
  updated_at?: string;
  category?: string;
  child?: Child;
}

export interface Profile {
  id: string;
  subscription_tier: string;
  subscription_status?: string;
  stripe_customer_id?: string;
  default_child_id?: string;
  created_at: string;
  updated_at?: string;
}

export interface CrisisEvent {
  id: string;
  parent_id: string;
  child_id?: string;
  scenario: string;
  description?: string;
  resolution_status?: string;
  created_at: string;
  updated_at?: string;
}

// ============================================
// SUBSCRIPTION & PRICING
// ============================================

export interface SubscriptionData {
  tier: string;
  status: string | null;
  isPremium: boolean;
  stripeCustomerId: string | null;
}

export interface PricingTier {
  id: string;
  name: string;
  price: number;
  interval: 'month' | 'year' | 'lifetime';
  features: string[];
  stripePriceId?: string;
  trialDays?: number;
  popular?: boolean;
}

// ============================================
// CRISIS SCENARIOS
// ============================================

export interface Scenario {
  id: string;
  label: string;
  color: string;
  icon: string; // Ionicons name
  description?: string;
}

// ============================================
// NEUROTYPES
// ============================================

export type Neurotype =
  | 'neurotypical'
  | 'ADHD'
  | 'Autism'
  | 'AuDHD'
  | 'Anxiety'
  | 'Highly Sensitive'
  | 'Sensory'
  | 'Gifted';

export interface NeurotypeOption {
  value: Neurotype;
  label: string;
  description?: string;
}

// ============================================
// NAVIGATION TYPES
// ============================================

export type RootStackParamList = {
  '(auth)/sign-in': undefined;
  '(auth)/sign-up': undefined;
  '(auth)/forgot-password': undefined;
  '(tabs)': undefined;
  'script/[id]': { id: string };
  '(modals)/pricing': undefined;
  '(modals)/onboarding': undefined;
  'reset-password': undefined;
};

export type TabParamList = {
  index: undefined;
  crisis: undefined;
  library: undefined;
  children: undefined;
  settings: undefined;
};

// ============================================
// FORM TYPES
// ============================================

export interface ChildFormData {
  name: string;
  birthDate: string;
  neurotype: string;
}

export interface CrisisFormData {
  scenario: string;
  childId?: string;
  childAge: string;
  neurotype: string;
  situation: string;
}

// ============================================
// API RESPONSE TYPES
// ============================================

export interface ApiError {
  message: string;
  code?: string;
  details?: any;
}

export interface ApiResponse<T> {
  data?: T;
  error?: ApiError;
}

// ============================================
// UTILITY TYPES
// ============================================

export interface LoadingState {
  isLoading: boolean;
  error: string | null;
}

export interface PaginationParams {
  page: number;
  perPage: number;
}

export interface FilterParams {
  childId?: string;
  isFavorite?: boolean;
  category?: string;
  dateFrom?: string;
  dateTo?: string;
}

// ============================================
// LEGACY TYPES - Kept for backwards compatibility
// ============================================

export interface CrisisScript {
  id: string;
  title: string;
  script_content: {
    part1: { text: string; whyItWorks: string };
    part2: { text: string; whyItWorks: string };
    part3: { text: string; whyItWorks: string };
  };
  situation_description: string;
  child_age: string;
  neurotype: string;
  created_at: string;
}

export interface CrisisFormScript {
  // Section 1: Getting Child's Attention (connection before correction)
  attentionPhrases: {
    observe: string;      // "I notice..." - neutral observation
    direct: string;       // "The TV is going off." - firm boundary
  };
  
  // Section 2: Building Empathy (not shame)
  empathyPhrases: {
    perspectiveTaking: string; // "It is so hard to stop playing."
    makeAmends: string;        // "How can we make this better?"
  };
  
  // Section 3: Parent Self-Regulation
  parentRegulation: {
    neutralStatement: string;     // Grounding thought for the parent
    modelAccountability: string;  // Script if parent lost their cool
  };
  
  // Section 4: Delivery Guidance (2 brief tips)
  deliveryTips: string[];  // ["Voice: Low and Slow", "Body: Open Hands"]
  
  // Premium fields (optional) - shown only to premium subscribers
  whyThisWorks?: string | null;
  proactiveFollowUp?: string | null;
  frameworkUsed?: string | null;
  frameworkReasoning?: string | null;
  detected_category?: string | null;
}
