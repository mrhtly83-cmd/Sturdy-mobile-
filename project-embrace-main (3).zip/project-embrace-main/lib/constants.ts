/**
 * Shared constants for the mobile app
 */

// API Configuration
export const API_CONFIG = {
  SUPABASE_FUNCTIONS_URL: process.env.EXPO_PUBLIC_SUPABASE_URL
    ? `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1`
    : '',
  GENERATE_SCRIPT_ENDPOINT: 'generate-script',
  TIMEOUT: 30000, // 30 seconds
};

// App Configuration
export const APP_CONFIG = {
  APP_NAME: 'Sturdy',
  APP_VERSION: '1.0.0',
  MIN_CHILD_AGE: 0,
  MAX_CHILD_AGE: 18,
  SITUATION_MAX_LENGTH: 500,
  SITUATION_MIN_LENGTH: 10,
};

// Storage Keys
export const STORAGE_KEYS = {
  ONBOARDING_COMPLETED: '@sturdy:onboarding_completed',
  DEFAULT_CHILD: '@sturdy:default_child',
  THEME_PREFERENCE: '@sturdy:theme_preference',
  LAST_SYNC: '@sturdy:last_sync',
};

// Query Keys (for React Query if we add it)
export const QUERY_KEYS = {
  AUTH_SESSION: 'auth-session',
  USER_PROFILE: 'user-profile',
  CHILDREN: 'children',
  SCRIPTS: 'scripts',
  SUBSCRIPTION: 'subscription',
  CRISIS_EVENTS: 'crisis-events',
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network connection failed. Please check your internet connection.',
  AUTH_ERROR: 'Authentication failed. Please sign in again.',
  GENERIC_ERROR: 'Something went wrong. Please try again.',
  SCRIPT_GENERATION_ERROR: 'Failed to generate script. Please try again.',
  SAVE_ERROR: 'Failed to save. Please try again.',
  DELETE_ERROR: 'Failed to delete. Please try again.',
  PAYWALL_ERROR: 'This feature requires a premium subscription.',
  FORM_VALIDATION_ERROR: 'Please check your input and try again.',
};

// Success Messages
export const SUCCESS_MESSAGES = {
  SCRIPT_SAVED: 'Script saved successfully!',
  CHILD_ADDED: 'Child profile created successfully!',
  CHILD_UPDATED: 'Child profile updated successfully!',
  CHILD_DELETED: 'Child profile deleted successfully!',
  SETTINGS_SAVED: 'Settings saved successfully!',
};

// Debounce delays (in milliseconds)
export const DEBOUNCE_DELAYS = {
  SEARCH: 300,
  INPUT: 500,
  AUTO_SAVE: 1000,
};

export default {
  API_CONFIG,
  APP_CONFIG,
  STORAGE_KEYS,
  QUERY_KEYS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  DEBOUNCE_DELAYS,
};
