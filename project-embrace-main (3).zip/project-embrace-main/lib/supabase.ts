import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";
import "react-native-url-polyfill/auto";

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.warn(
    "Missing Supabase env vars. Set EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY in mobile/.env"
  );
}

function makeMissingClient(message: string) {
  const err = new Error(message);
  const rejected = async () => ({ data: null, error: err });
  return {
    _isConfigured: false,
    auth: {
      getSession: rejected,
      getUser: rejected,
      signInWithPassword: rejected,
      signUp: rejected,
      signOut: rejected,
      updateUser: rejected,
      resetPasswordForEmail: rejected,
      signInAnonymously: rejected,
      onAuthStateChange: () => ({ data: null, subscription: { unsubscribe: () => {} } }),
    },
    from: () => ({ select: rejected, insert: rejected, update: rejected, delete: rejected }),
    functions: { invoke: rejected },
  } as any;
}

export const supabase =
  SUPABASE_URL && SUPABASE_ANON_KEY
    ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: {
          storage: AsyncStorage,
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: false,
        },
      })
    : makeMissingClient(
        "Supabase not configured. Set EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY in mobile/.env"
      );
