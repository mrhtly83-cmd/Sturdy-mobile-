/**
 * Central Type Exports for Mobile App
 * 
 * This file re-exports all types from lib/types.ts for convenience.
 * Import from this file for better discoverability and consistency.
 * 
 * @example
 * // Instead of: import { Child } from '../lib/types'
 * // Use: import { Child } from '../types'
 */

export * from '../lib/types';
