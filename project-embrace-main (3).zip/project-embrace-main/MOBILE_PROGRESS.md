# Sturdy Mobile App Migration Progress

## ✅ Completed (Phases 1-4)

### Phase 1: Foundation & Security
- ✅ Removed debug console.logs from `mobile/lib/supabase.ts`
- ✅ Removed root `.env` file from git (contained sensitive Stripe keys)
- ✅ Added `.env` patterns to `.gitignore`

### Phase 2: Type System & Configuration
All TypeScript types, configuration files, and theme system have been created:

**Types** (`mobile/lib/types.ts` - 270 lines)
- `ConsciousDisciplineResponse` - AI-generated script format
- `Child`, `Script`, `Profile` - Database entities
- `SubscriptionData`, `PricingTier` - Subscription management
- `Scenario`, `Neurotype` - Crisis mode options
- Navigation, form, and API types

**Configuration Files**
- `mobile/config/scenarios.ts` - 8 crisis scenarios with Ionicons
- `mobile/config/neurotypes.ts` - 8 neurotype options
- `mobile/config/pricing.ts` - Free/Monthly/Annual tiers

**Theme System**
- `mobile/theme/colors.ts` - Clinical Luxury design (gold primary)
- `mobile/theme/typography.ts` - Font sizes, weights, text styles
- `mobile/theme/spacing.ts` - Spacing, shadows, layout constants

**Utilities**
- `mobile/lib/constants.ts` - API config, storage keys, error messages
- `mobile/lib/utils.ts` - Date formatting, validation, helpers

### Phase 3: Data Layer & Hooks
Complete React hooks for data management (using plain `useState`/`useEffect`, no React Query):

**Authentication** (`mobile/hooks/useAuth.ts`)
- `useAuth()` - Session management, sign in/up/out, password reset

**Children** (`mobile/hooks/useChildren.ts`)
- `useChildren()` - Fetch all children
- `useAddChild()` - Add new child profile
- `useUpdateChild()` - Update child profile
- `useDeleteChild()` - Delete child profile
- `useDefaultChild()` - Get default child
- `useSetDefaultChild()` - Set default child

**Scripts** (`mobile/hooks/useScripts.ts`)
- `useScripts(filters?)` - Fetch scripts with filtering
- `useScript(id)` - Get single script
- `useSaveScript()` - Save generated script
- `useToggleFavorite()` - Toggle favorite status
- `useDeleteScript()` - Delete script
- `useScriptCount()` - Get count (for free tier limit)

**Subscription** (`mobile/hooks/useSubscription.ts`)
- `useSubscription()` - Fetch subscription status
- `formatTierName()` - Display tier name

**Paywall** (`mobile/hooks/usePaywall.ts`)
- `usePaywall()` - Check if user can generate scripts
- Enforces 5-script limit for free tier

**API Services**
- `mobile/services/api/scripts.ts` - Generate & save scripts via Edge Function
- `mobile/services/api/children.ts` - CRUD operations for children
- `mobile/services/api/profile.ts` - User profile management

### Phase 4: Shared Components
Reusable UI components with theme integration:

- `Button.tsx` - Primary/secondary/outline/destructive variants, loading state
- `Card.tsx` - Elevated card with customizable padding/shadow
- `Input.tsx` - Text input with label, error display, multiline support
- `LoadingSpinner.tsx` - Activity indicator with optional text
- `EmptyState.tsx` - Icon, title, description, optional action button

---

## 🚧 Next Steps (Phases 5-10)

### Phase 5: Crisis Mode (CORE FEATURE) - **START HERE**

The crisis mode is the app's main feature. It needs:

#### Components to Create
1. **ScenarioSelector** - Grid of 8 scenarios with icons/colors
2. **ChildAgeSelector** - Select child or enter age manually
3. **SituationInput** - Multiline text area for situation description
4. **ScriptDisplay** - Display 3-part Conscious Discipline script

#### Main Screen Implementation
File: `mobile/app/(tabs)/crisis.tsx` (currently doesn't exist)

**Flow:**
```
Step 1: Select Scenario (hitting, tantrum, etc.)
   ↓
Step 2: Select Child (or enter age + neurotype)
   ↓
Step 3: Describe Situation (multiline input, 10-500 chars)
   ↓
Step 4: Generate Script (call Edge Function)
   ↓
Step 5: Display Script (3 parts + mantra + tip)
   ↓
Step 6: Save Script (optional, with favorite toggle)
```

**Paywall Logic:**
- Free users: Show remaining scripts (5 total limit)
- If limit reached: Show pricing modal
- Premium users: Unlimited scripts

**Key Imports:**
```typescript
import { generateScript } from '../../services/api/scripts';
import { SCENARIOS } from '../../config/scenarios';
import { NEUROTYPES } from '../../config/neurotypes';
import { useChildren } from '../../hooks/useChildren';
import { usePaywall } from '../../hooks/usePaywall';
import { useSaveScript } from '../../hooks/useScripts';
```

### Phase 6: Dashboard
File: `mobile/app/(tabs)/index.tsx` (currently placeholder)

**Features:**
- Display script count (X of 5 used / Unlimited)
- Recent 3 scripts (quick access)
- Quick action buttons (New Script, View Library, Manage Children)
- Subscription status banner

**Components Needed:**
- `UsageStats.tsx` - Progress bar showing script usage
- `RecentScripts.tsx` - List of recent 3 scripts
- `QuickActions.tsx` - Action button grid

### Phase 7: Script Library
File: `mobile/app/(tabs)/library.tsx` (currently doesn't exist)

**Features:**
- List all saved scripts
- Filter by child, favorite, date
- Pull-to-refresh
- Script preview cards (tap to view full)
- Empty state if no scripts

**Detail Screen:**
File: `mobile/app/script/[id].tsx` (currently doesn't exist)

**Features:**
- Full script display (3 parts)
- Share button (share as text)
- Favorite toggle
- Delete button

### Phase 8: Child Profiles
File: `mobile/app/(tabs)/children.tsx` (currently doesn't exist)

**Features:**
- List all children
- Add new child button
- Edit child (tap card)
- Delete child (swipe action)
- Set default child (radio button)

**Components Needed:**
- `ChildCard.tsx` - Display child info (name, age, neurotype)
- `ChildForm.tsx` - Form for add/edit (name, birth date picker, neurotype dropdown)

### Phase 9: Supporting Features

#### Sign Up Screen
File: `mobile/app/(auth)/sign-up.tsx` (currently doesn't exist)

**Features:**
- Email/password input
- Password confirmation
- Sign up button
- Link to sign in

#### Forgot Password Screen
File: `mobile/app/(auth)/forgot-password.tsx` (currently doesn't exist)

**Features:**
- Email input
- Send reset email button
- Confirmation message
- Link back to sign in

#### Pricing Modal
File: `mobile/app/(modals)/pricing.tsx` (currently doesn't exist)

**Features:**
- Display 3 tiers (Free, Monthly, Annual)
- Feature comparison
- Subscribe buttons (link to Stripe - web only for now)
- Close button

#### Onboarding Modal
File: `mobile/app/(modals)/onboarding.tsx` (currently doesn't exist)

**Features:**
- Welcome screen
- 3-step tutorial (Crisis Mode, Scripts, Children)
- Skip button
- Get Started button

### Phase 10: Testing & Polish

**TypeScript Compilation:**
```bash
cd mobile
npx tsc --noEmit
```

**Run in Expo Go:**
```bash
cd mobile
npm start
# Then scan QR code with Expo Go app
```

**Test Cases:**
1. Sign in → Dashboard shows correctly
2. Create child profile → Appears in list
3. Generate script (free tier) → Count increments
4. Generate 5 scripts → Paywall appears
5. View script library → All scripts shown
6. Mark script as favorite → Favorite filter works
7. Delete script → Removed from list

---

## 📂 File Structure Summary

```
mobile/
├── app/
│   ├── (auth)/
│   │   ├── sign-in.tsx ✅ (exists)
│   │   ├── sign-up.tsx ❌ (needs creation)
│   │   └── forgot-password.tsx ❌ (needs creation)
│   ├── (tabs)/
│   │   ├── _layout.tsx ✅ (exists)
│   │   ├── index.tsx ✅ (exists, needs implementation)
│   │   ├── crisis.tsx ❌ (needs creation - PRIORITY)
│   │   ├── library.tsx ❌ (needs creation)
│   │   ├── children.tsx ❌ (needs creation)
│   │   └── settings.tsx ✅ (exists)
│   ├── (modals)/
│   │   ├── pricing.tsx ❌ (needs creation)
│   │   └── onboarding.tsx ❌ (needs creation)
│   ├── script/
│   │   └── [id].tsx ❌ (needs creation)
│   └── reset-password.tsx ✅ (exists)
├── components/
│   ├── shared/ ✅ (5 components complete)
│   ├── crisis/ ❌ (4 components needed)
│   ├── dashboard/ ❌ (3 components needed)
│   ├── library/ ❌ (2 components needed)
│   └── children/ ❌ (2 components needed)
├── hooks/ ✅ (5 hooks complete)
├── services/api/ ✅ (3 services complete)
├── config/ ✅ (3 configs complete)
├── theme/ ✅ (3 theme files complete)
└── lib/ ✅ (4 lib files complete)
```

---

## 🎯 Recommended Next Actions

### Option 1: Quick Win (Crisis Mode Only)
Focus on getting the core feature working:
1. Create `mobile/app/(tabs)/crisis.tsx` with multi-step form
2. Create crisis components (scenario selector, etc.)
3. Test script generation end-to-end
4. **Time estimate: 4-6 hours**

### Option 2: Full Implementation
Complete all remaining features:
1. Crisis Mode (4-6 hours)
2. Dashboard (2-3 hours)
3. Script Library (2-3 hours)
4. Child Profiles (2-3 hours)
5. Supporting features (3-4 hours)
6. **Total time estimate: 13-19 hours**

### Option 3: Iterative Approach (Recommended)
Build in order of importance:
1. **Day 1:** Crisis Mode + basic Dashboard (show script count)
2. **Day 2:** Script Library + Child Profiles
3. **Day 3:** Supporting features + polish

---

## 🔑 Key Integration Points

### Supabase Edge Function
The script generation calls:
```typescript
POST https://[project].supabase.co/functions/v1/generate-script
Headers: { Authorization: "Bearer [session.access_token]" }
Body: {
  scenario: string,
  situation: string,
  childAge: string,
  neurotype: string,
  isPremium: boolean
}
```

Returns: `ConsciousDisciplineResponse`

### Database Schema (Already in Supabase)
```sql
-- Children table
id, parent_id, name, birth_date, neurotype, created_at

-- Scripts table
id, parent_id, child_id, situation, script_text, 
is_favorite, category, created_at

-- Profiles table
id, subscription_tier, subscription_status, 
stripe_customer_id, default_child_id
```

### Environment Variables
Required in `mobile/.env`:
```bash
EXPO_PUBLIC_SUPABASE_URL=https://[project].supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbG...
EXPO_PUBLIC_STRIPE_MONTHLY_PRICE_ID=price_...
EXPO_PUBLIC_STRIPE_ANNUAL_PRICE_ID=price_...
```

---

## 🐛 Known Issues & Considerations

1. **React Query Not Installed**
   - Currently using plain React hooks (useState/useEffect)
   - If you want React Query, run: `npm install @tanstack/react-query`
   - Then wrap app in `<QueryClientProvider>`

2. **Navigation Types**
   - Expo Router uses file-based routing
   - No need for React Navigation stack definitions
   - Modal routes use `/(modals)/` directory

3. **Stripe Integration**
   - Mobile apps can't directly use Stripe Checkout
   - Two options:
     1. Open web pricing page in browser (`expo-web-browser`)
     2. Implement native payments (React Native Payments SDK)

4. **Offline Support**
   - Not currently implemented
   - Could add with AsyncStorage caching
   - Or use React Query with persistence

5. **Testing**
   - No test suite currently exists
   - Could add Jest + React Native Testing Library

---

## 📚 Resources

- **Expo Documentation:** https://docs.expo.dev/
- **Supabase JS Client:** https://supabase.com/docs/reference/javascript
- **Ionicons:** https://ionic.io/ionicons (search icon names)
- **React Native:** https://reactnative.dev/docs/getting-started

---

## ✨ What Makes This Foundation Strong

1. **Type Safety** - Complete TypeScript types from web app
2. **Design System** - Consistent theme with colors/spacing/typography
3. **Reusable Hooks** - Clean data fetching patterns
4. **Component Library** - Ready-to-use UI components
5. **Configuration** - Scenarios/neurotypes/pricing in one place
6. **Error Handling** - Consistent error messages
7. **Code Organization** - Clear separation of concerns

**You're 40% done!** The hardest part (architecture & foundation) is complete. Now it's just building screens and wiring up the data layer. 🚀
