import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { Child } from '../lib/types';
import { calculateAge } from '../lib/utils';

/**
 * Hook to fetch and manage children
 */
export function useChildren() {
  const [children, setChildren] = useState<Child[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchChildren = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('children')
        .select('*')
        .order('created_at', { ascending: true });

      if (fetchError) throw fetchError;

      setChildren(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch children');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchChildren();
  }, [fetchChildren]);

  const refresh = () => {
    fetchChildren();
  };

  return {
    children,
    loading,
    error,
    refresh,
  };
}

/**
 * Hook to add a child
 */
export function useAddChild() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addChild = async (data: { name: string; birthDate: string; neurotype: string }) => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('You must be logged in to add a child.');

      // Ensure user profile exists
      const { error: profileError } = await supabase
        .from('profiles')
        .upsert({ id: user.id }, { onConflict: 'id' });

      if (profileError) throw profileError;

      const { data: newChild, error: insertError } = await supabase
        .from('children')
        .insert([
          {
            name: data.name,
            birth_date: data.birthDate || null,
            neurotype: data.neurotype,
            parent_id: user.id,
          },
        ])
        .select()
        .single();

      if (insertError) throw insertError;

      return newChild;
    } catch (err: any) {
      setError(err.message || 'Failed to add child');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    addChild,
    loading,
    error,
  };
}

/**
 * Hook to update a child
 */
export function useUpdateChild() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateChild = async (data: {
    id: string;
    name: string;
    birthDate: string;
    neurotype: string;
  }) => {
    try {
      setLoading(true);
      setError(null);

      const { error: updateError } = await supabase
        .from('children')
        .update({
          name: data.name,
          birth_date: data.birthDate || null,
          neurotype: data.neurotype,
        })
        .eq('id', data.id);

      if (updateError) throw updateError;
    } catch (err: any) {
      setError(err.message || 'Failed to update child');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    updateChild,
    loading,
    error,
  };
}

/**
 * Hook to delete a child
 */
export function useDeleteChild() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const deleteChild = async (childId: string) => {
    try {
      setLoading(true);
      setError(null);

      const { error: deleteError } = await supabase
        .from('children')
        .delete()
        .eq('id', childId);

      if (deleteError) throw deleteError;
    } catch (err: any) {
      setError(err.message || 'Failed to delete child');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    deleteChild,
    loading,
    error,
  };
}

/**
 * Hook to get default child
 */
export function useDefaultChild() {
  const [defaultChildId, setDefaultChildId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDefaultChild = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setDefaultChildId(null);
        setLoading(false);
        return;
      }

      const { data, error: fetchError } = await supabase
        .from('profiles')
        .select('default_child_id')
        .eq('id', user.id)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') {
        // PGRST116 = no rows returned, which is ok
        throw fetchError;
      }

      setDefaultChildId(data?.default_child_id || null);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch default child');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDefaultChild();
  }, [fetchDefaultChild]);

  return {
    defaultChildId,
    loading,
    error,
    refresh: fetchDefaultChild,
  };
}

/**
 * Hook to set default child
 */
export function useSetDefaultChild() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const setDefaultChild = async (childId: string | null) => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error: updateError } = await supabase
        .from('profiles')
        .update({ default_child_id: childId })
        .eq('id', user.id);

      if (updateError) throw updateError;
    } catch (err: any) {
      setError(err.message || 'Failed to set default child');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    setDefaultChild,
    loading,
    error,
  };
}

export { calculateAge };
