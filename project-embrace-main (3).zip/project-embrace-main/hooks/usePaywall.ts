import { useSubscription } from './useSubscription';
import { useScriptCount } from './useScripts';
import { FREE_TIER_SCRIPT_LIMIT } from '../config/pricing';

/**
 * Hook to check if user can access a feature based on subscription
 */
export function usePaywall() {
  const { isPremium, tier, loading: subscriptionLoading } = useSubscription();
  const { count: scriptCount, loading: countLoading } = useScriptCount();

  const loading = subscriptionLoading || countLoading;

  // Check if user can generate a new script
  const canGenerateScript = () => {
    if (isPremium) return true;
    return scriptCount < FREE_TIER_SCRIPT_LIMIT;
  };

  // Get remaining scripts for free tier
  const getRemainingScripts = () => {
    if (isPremium) return null; // Unlimited
    return Math.max(0, FREE_TIER_SCRIPT_LIMIT - scriptCount);
  };

  // Check if user has hit the free limit
  const hasHitFreeLimit = () => {
    if (isPremium) return false;
    return scriptCount >= FREE_TIER_SCRIPT_LIMIT;
  };

  return {
    isPremium,
    tier,
    scriptCount,
    canGenerateScript: canGenerateScript(),
    remainingScripts: getRemainingScripts(),
    hasHitFreeLimit: hasHitFreeLimit(),
    loading,
  };
}
