import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { Script, FilterParams } from '../lib/types';

/**
 * Hook to fetch and manage scripts
 */
export function useScripts(filters?: FilterParams) {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchScripts = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      let query = supabase
        .from('scripts')
        .select('*, child:children(*)')
        .order('created_at', { ascending: false });

      // Apply filters
      if (filters?.childId) {
        query = query.eq('child_id', filters.childId);
      }
      if (filters?.isFavorite !== undefined) {
        query = query.eq('is_favorite', filters.isFavorite);
      }
      if (filters?.category) {
        query = query.eq('category', filters.category);
      }
      if (filters?.dateFrom) {
        query = query.gte('created_at', filters.dateFrom);
      }
      if (filters?.dateTo) {
        query = query.lte('created_at', filters.dateTo);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;

      setScripts(data || []);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch scripts');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchScripts();
  }, [fetchScripts]);

  const refresh = () => {
    fetchScripts();
  };

  return {
    scripts,
    loading,
    error,
    refresh,
  };
}

/**
 * Hook to get a single script by ID
 */
export function useScript(scriptId: string) {
  const [script, setScript] = useState<Script | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchScript = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('scripts')
        .select('*, child:children(*)')
        .eq('id', scriptId)
        .single();

      if (fetchError) throw fetchError;

      setScript(data);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch script');
    } finally {
      setLoading(false);
    }
  }, [scriptId]);

  useEffect(() => {
    fetchScript();
  }, [fetchScript]);

  return {
    script,
    loading,
    error,
    refresh: fetchScript,
  };
}

/**
 * Hook to save a script
 */
export function useSaveScript() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const saveScript = async (data: {
    situation: string;
    scriptText: string;
    childId?: string;
    category?: string;
  }) => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('You must be logged in to save a script.');

      const { data: newScript, error: insertError } = await supabase
        .from('scripts')
        .insert([
          {
            parent_id: user.id,
            child_id: data.childId || null,
            situation: data.situation,
            script_text: data.scriptText,
            category: data.category || null,
            is_favorite: false,
          },
        ])
        .select()
        .single();

      if (insertError) throw insertError;

      return newScript;
    } catch (err: any) {
      setError(err.message || 'Failed to save script');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    saveScript,
    loading,
    error,
  };
}

/**
 * Hook to toggle favorite status
 */
export function useToggleFavorite() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleFavorite = async (scriptId: string, currentFavorite: boolean) => {
    try {
      setLoading(true);
      setError(null);

      const { error: updateError } = await supabase
        .from('scripts')
        .update({ is_favorite: !currentFavorite })
        .eq('id', scriptId);

      if (updateError) throw updateError;
    } catch (err: any) {
      setError(err.message || 'Failed to toggle favorite');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    toggleFavorite,
    loading,
    error,
  };
}

/**
 * Hook to delete a script
 */
export function useDeleteScript() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const deleteScript = async (scriptId: string) => {
    try {
      setLoading(true);
      setError(null);

      const { error: deleteError } = await supabase
        .from('scripts')
        .delete()
        .eq('id', scriptId);

      if (deleteError) throw deleteError;
    } catch (err: any) {
      setError(err.message || 'Failed to delete script');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    deleteScript,
    loading,
    error,
  };
}

/**
 * Hook to get script count (for free tier limit)
 */
export function useScriptCount() {
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCount = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { count, error: countError } = await supabase
        .from('scripts')
        .select('*', { count: 'exact', head: true });

      if (countError) throw countError;

      setCount(count || 0);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch script count');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCount();
  }, [fetchCount]);

  return {
    count,
    loading,
    error,
    refresh: fetchCount,
  };
}
