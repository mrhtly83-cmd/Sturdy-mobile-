import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { SubscriptionData } from '../lib/types';
import { isPremiumTier } from '../config/pricing';

/**
 * Hook to fetch and manage user subscription status
 */
export function useSubscription() {
  const [data, setData] = useState<SubscriptionData>({
    tier: 'free',
    status: null,
    isPremium: false,
    stripeCustomerId: null,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchSubscription = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setData({
          tier: 'free',
          status: null,
          isPremium: false,
          stripeCustomerId: null,
        });
        setLoading(false);
        return;
      }

      const { data: profile, error: fetchError } = await supabase
        .from('profiles')
        .select('subscription_tier, subscription_status, stripe_customer_id')
        .eq('id', user.id)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') {
        // PGRST116 = no rows returned, which is ok for new users
        throw fetchError;
      }

      const tier = profile?.subscription_tier || 'free';
      const status = profile?.subscription_status || null;

      // Premium includes both active AND trialing users
      const isPremium =
        isPremiumTier(tier) && (status === 'active' || status === 'trialing');

      setData({
        tier,
        status,
        isPremium,
        stripeCustomerId: profile?.stripe_customer_id || null,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to fetch subscription');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSubscription();
  }, [fetchSubscription]);

  const refresh = () => {
    fetchSubscription();
  };

  return {
    tier: data.tier,
    status: data.status,
    isPremium: data.isPremium,
    hasStripeCustomer: !!data.stripeCustomerId,
    loading,
    error,
    refresh,
  };
}

/**
 * Format tier name for display
 */
export function formatTierName(tier: string): string {
  const tierLabels: Record<string, string> = {
    free: 'Free',
    weekly: 'Weekly',
    monthly: 'Monthly',
    annual: 'Annual',
    lifetime: 'Lifetime',
    premium: 'Premium',
    complete: 'Complete',
  };
  return tierLabels[tier] || tier.charAt(0).toUpperCase() + tier.slice(1);
}
