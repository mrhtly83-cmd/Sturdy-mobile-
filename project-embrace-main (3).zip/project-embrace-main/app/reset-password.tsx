import { useEffect, useState } from "react";
import { Alert, Pressable, Text, TextInput, View } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { supabase } from "../lib/supabase";

export default function ResetPassword() {
  const params = useLocalSearchParams<{
    access_token?: string;
    refresh_token?: string;
    type?: string;
  }>();

  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [sessionReady, setSessionReady] = useState(false);

  useEffect(() => {
    const access_token = params.access_token;
    const refresh_token = params.refresh_token;

    // Supabase recovery links redirect with tokens in the URL
    if (!access_token || !refresh_token) {
      setSessionReady(true); // still render UI so user sees message
      return;
    }

    supabase.auth
      .setSession({ access_token, refresh_token })
      .then(({ error }) => {
        if (error) {
          Alert.alert("Reset link error", error.message);
        }
        setSessionReady(true);
      })
      .catch((e) => {
        Alert.alert("Reset link error", String(e));
        setSessionReady(true);
      });
  }, [params.access_token, params.refresh_token]);

  const onSave = async () => {
    if (password.length < 8) {
      return Alert.alert("Password too short", "Use at least 8 characters.");
    }

    try {
      setLoading(true);

      const { error } = await supabase.auth.updateUser({ password });
      if (error) return Alert.alert("Update failed", error.message);

      Alert.alert("Success", "Password updated. Please sign in.");
      await supabase.auth.signOut(); // force clean sign-in with new password
      router.replace("/(auth)/sign-in");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, padding: 24, justifyContent: "center", gap: 12 }}>
      <Text style={{ fontSize: 24, fontWeight: "700" }}>Reset password</Text>

      {!sessionReady ? (
        <Text style={{ opacity: 0.7 }}>Preparing reset session…</Text>
      ) : (
        <>
          <Text style={{ opacity: 0.7 }}>
            Enter a new password for your account.
          </Text>

          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="New password"
            secureTextEntry
            style={{
              borderWidth: 1,
              borderColor: "#ddd",
              padding: 12,
              borderRadius: 10,
            }}
          />

          <Pressable
            onPress={onSave}
            disabled={loading}
            style={{
              marginTop: 12,
              paddingVertical: 14,
              borderRadius: 12,
              alignItems: "center",
              backgroundColor: "#111827",
              opacity: loading ? 0.6 : 1,
            }}
          >
            <Text style={{ color: "white", fontSize: 16, fontWeight: "600" }}>
              {loading ? "Saving..." : "Save new password"}
            </Text>
          </Pressable>
        </>
      )}
    </View>
  );
}
