import { useEffect, useState } from "react";
import { Pressable, StyleSheet, Text, View, ScrollView, ImageBackground } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { supabase } from "../lib/supabase";
import { dimensions, responsiveFontSize, responsiveSpacing, responsiveHeight } from "../theme/dimensions";

const GOLD = "#D4AF37";

export default function Index() {
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) router.replace("/(tabs)");
      setChecking(false);
    });
  }, []);

  if (checking) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>Sturdy</Text>
        <Text style={styles.loadingSub}>Loading…</Text>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      {/* Background Image with Overlay */}
      <ImageBackground
        source={require("../assets/images/hero-home.jpg")}
        style={StyleSheet.absoluteFillObject}
        resizeMode="cover"
      >
        <View style={styles.overlay} />
      </ImageBackground>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Top brand */}
        <View style={styles.top}>
          <Text style={styles.brand}>Sturdy</Text>
          <Text style={styles.tag}>Calm words, on demand</Text>
        </View>

        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.headline}>
            Stop freezing.
            {"\n"}
            <Text style={styles.gold}>Start connecting.</Text>
          </Text>

          <Text style={styles.subhead}>
            Get calm, neuroscience-backed scripts in seconds—for tantrums, defiance, sibling fights & more.
          </Text>

          {/* Social Proof */}
          <View style={styles.proofContainer}>
            <View style={styles.proofBadge}>
              <Text style={styles.proofNumber}>5,000+</Text>
              <Text style={styles.proofLabel}>Parents trust Sturdy</Text>
            </View>
          </View>
        </View>

        {/* Features Grid */}
        <View style={styles.features}>
          <View style={styles.featureCard}>
            <Text style={styles.featureIcon}>⚡</Text>
            <Text style={styles.featureTitle}>Instant Scripts</Text>
            <Text style={styles.featureText}>
              Get the exact words you need in under 30 seconds
            </Text>
          </View>

          <View style={styles.featureCard}>
            <Text style={styles.featureIcon}>🧠</Text>
            <Text style={styles.featureTitle}>Neuro-Informed</Text>
            <Text style={styles.featureText}>
              Tailored for ADHD, autism, anxiety & more
            </Text>
          </View>

          <View style={styles.featureCard}>
            <Text style={styles.featureIcon}>💾</Text>
            <Text style={styles.featureTitle}>Save & Reuse</Text>
            <Text style={styles.featureText}>
              Build your library of scripts that work
            </Text>
          </View>

          <View style={styles.featureCard}>
            <Text style={styles.featureIcon}>✨</Text>
            <Text style={styles.featureTitle}>Free to Start</Text>
            <Text style={styles.featureText}>
              5 free scripts/month—no credit card needed
            </Text>
          </View>
        </View>

        {/* Trust Line */}
        <View style={styles.trustContainer}>
          <Text style={styles.trust}>
            🧬 Backed by neuroscience • 🏡 Built for real life
          </Text>
        </View>

        {/* CTAs */}
        <View style={styles.ctas}>
          <Pressable
            onPress={() => router.push("/guest-crisis")}
            style={({ pressed }) => [
              styles.primaryBtn,
              pressed && { transform: [{ scale: 0.98 }], opacity: 0.95 },
            ]}
          >
            <LinearGradient
              colors={["#fbbf24", "#f59e0b", "#d97706"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.primaryGradient}
            >
              <Text style={styles.primaryText}>Get Your First Script Free</Text>
              <Text style={styles.primarySub}>No signup required • Takes 30 seconds</Text>
            </LinearGradient>
          </Pressable>

          <Pressable
            onPress={() => router.push("/(auth)/sign-in")}
            style={({ pressed }) => [
              styles.secondaryBtn,
              pressed && { transform: [{ scale: 0.98 }], opacity: 0.95 },
            ]}
          >
            <Text style={styles.secondaryText}>I already have an account</Text>
          </Pressable>

          <Text style={styles.micro}>
            Join 5,000+ parents getting calm words on demand
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    backgroundColor: "#0B0F19",
    alignItems: "center",
    justifyContent: "center",
    gap: responsiveSpacing(6),
  },
  loadingText: { color: "white", fontSize: dimensions.fontSize["2xl"], fontWeight: "900" },
  loadingSub: { color: "rgba(255,255,255,0.6)", fontWeight: "700" },

  screen: {
    flex: 1,
    backgroundColor: "#0B0F19",
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.65)",
  },
  scrollContent: {
    paddingHorizontal: dimensions.padding.lg,
    paddingTop: responsiveHeight(64, 48, 80),
    paddingBottom: dimensions.padding.xl,
    gap: responsiveSpacing(32, 28, 40),
  },
  top: {
    gap: responsiveSpacing(4),
  },
  brand: {
    color: "white",
    fontSize: dimensions.fontSize["2xl"],
    fontWeight: "900",
    letterSpacing: 0.2,
  },
  tag: {
    color: "rgba(255,255,255,0.65)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "700",
  },

  hero: {
    gap: responsiveSpacing(16),
  },
  headline: {
    color: "white",
    fontSize: dimensions.fontSize["4xl"],
    fontWeight: "900",
    lineHeight: responsiveHeight(40, 36, 48),
    letterSpacing: -0.2,
  },
  gold: { color: GOLD },
  subhead: {
    color: "rgba(255,255,255,0.78)",
    fontSize: dimensions.fontSize.base,
    fontWeight: "600",
    lineHeight: responsiveHeight(24, 20, 28),
  },

  // Social Proof
  proofContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: responsiveSpacing(12),
  },
  proofBadge: {
    backgroundColor: "rgba(212, 175, 55, 0.1)",
    borderWidth: 1,
    borderColor: "rgba(212, 175, 55, 0.3)",
    borderRadius: dimensions.borderRadius.md,
    paddingHorizontal: dimensions.padding.md,
    paddingVertical: responsiveSpacing(10),
    flexDirection: "row",
    alignItems: "center",
    gap: responsiveSpacing(8),
  },
  proofNumber: {
    color: GOLD,
    fontSize: dimensions.fontSize.lg,
    fontWeight: "900",
  },
  proofLabel: {
    color: "rgba(255,255,255,0.7)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
  },

  // Features
  features: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: responsiveSpacing(12),
    marginTop: responsiveSpacing(-8),
  },
  featureCard: {
    flex: 1,
    minWidth: "45%",
    backgroundColor: "rgba(255,255,255,0.05)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
    borderRadius: dimensions.borderRadius.lg,
    padding: dimensions.padding.md,
    gap: responsiveSpacing(8),
  },
  featureIcon: {
    fontSize: responsiveFontSize(28, 24, 32),
  },
  featureTitle: {
    color: "white",
    fontSize: dimensions.fontSize.base,
    fontWeight: "900",
  },
  featureText: {
    color: "rgba(255,255,255,0.65)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
    lineHeight: responsiveHeight(18, 16, 22),
  },

  // Trust
  trustContainer: {
    alignItems: "center",
    marginTop: responsiveSpacing(-16),
  },
  trust: {
    color: "rgba(255,255,255,0.55)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "700",
    textAlign: "center",
  },

  // CTAs
  ctas: {
    gap: dimensions.margin.sm,
  },
  primaryBtn: {
    borderRadius: dimensions.borderRadius.lg,
    overflow: "hidden",
  },
  primaryGradient: {
    paddingVertical: dimensions.padding.md,
    paddingHorizontal: dimensions.padding.md,
    alignItems: "center",
  },
  primaryText: {
    color: "#101318",
    fontSize: dimensions.fontSize.md,
    fontWeight: "900",
  },
  primarySub: {
    marginTop: responsiveSpacing(4),
    color: "rgba(16,19,24,0.75)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "700",
  },

  secondaryBtn: {
    borderRadius: dimensions.borderRadius.lg,
    paddingVertical: dimensions.padding.md,
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.05)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.12)",
  },
  secondaryText: {
    color: "rgba(255,255,255,0.85)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "700",
  },

  micro: {
    textAlign: "center",
    marginTop: responsiveSpacing(6),
    color: "rgba(255,255,255,0.5)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "600",
  },
});
