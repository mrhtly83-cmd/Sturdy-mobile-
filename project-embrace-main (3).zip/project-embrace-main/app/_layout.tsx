import { Stack, router } from "expo-router";
import { useEffect } from "react";
import { supabase } from "../lib/supabase";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function RootLayout() {
  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {

      // ✅ If logged in, check for pending script request
      if (data.session) {
        const pending = await AsyncStorage.getItem('pending_script_request');
        if (pending) {
          // Clear the pending request
          await AsyncStorage.removeItem('pending_script_request');
          // Redirect to crisis tab to complete the flow
          router.replace("/(tabs)/crisis");
        } else {
          // Normal flow - go to tabs
          router.replace("/(tabs)");
        }
      }
      // ❌ If logged out, do nothing (let / show landing)
    });

    const { data: sub } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
      if (newSession) {
        // Check for pending script request when auth state changes (e.g., after email confirmation)
        const pending = await AsyncStorage.getItem('pending_script_request');
        if (pending) {
          await AsyncStorage.removeItem('pending_script_request');
          router.replace("/(tabs)/crisis");
        } else {
          router.replace("/(tabs)");
        }
      }
      // logged out? stay on landing ("/")
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <Stack screenOptions={{ headerShown: false }} />
  );
}
