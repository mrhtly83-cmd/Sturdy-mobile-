import React, { useState } from "react";
import {
  View,
  StyleSheet,
  Alert,
  Text,
  Pressable,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";

import { ScriptDisplay } from "../components/crisis/ScriptDisplay";
import { ConsciousDisciplineResponse } from "../lib/types";
import { dimensions, responsiveSpacing, responsiveHeight } from "../theme/dimensions";

const GOLD = "#D4AF37";

const AGE_OPTIONS = [
  { value: "2-4", label: "2-4 years", icon: "👶" },
  { value: "4-6", label: "4-6 years", icon: "🧒" },
  { value: "6-10", label: "6-10 years", icon: "👦" },
  { value: "10-13", label: "10-13 years", icon: "🧑" },
  { value: "13+", label: "13+ years", icon: "👨" },
];

const NEUROTYPE_OPTIONS = [
  { value: "neurotypical", label: "Standard / No Diagnosis", icon: "🧠" },
  { value: "adhd", label: "High Energy / ADHD", icon: "⚡" },
  { value: "autism", label: "Literal Thinker / Autism", icon: "🌈" },
  { value: "anxiety", label: "Anxious / Worrier", icon: "💜" },
  { value: "sensory", label: "Deeply Feeling / HSC", icon: "🌸" },
];

export default function GuestCrisisScreen() {
  const [formData, setFormData] = useState({
    situation: "",
    age: "",
    neurotype: "",
  });
  const [generatedScript, setGeneratedScript] = useState<ConsciousDisciplineResponse | null>(null);

  const isFormValid = formData.situation.trim() && formData.age && formData.neurotype;

  const handleGenerate = async () => {
    if (!isFormValid) {
      Alert.alert("Almost there!", "Please fill in all three steps.");
      return;
    }

    // Store the form data in AsyncStorage
    try {
      await AsyncStorage.setItem('pending_script_request', JSON.stringify({
        situation: formData.situation,
        childAge: formData.age,
        neurotype: formData.neurotype,
      }));
    } catch (err) {
      console.error('Failed to save pending request:', err);
    }

    // Show signup gate
    Alert.alert(
      "Your script is ready! ✨",
      "Create a free account to see your personalized script. No credit card required—takes 30 seconds.",
      [
        {
          text: "Create Free Account",
          onPress: () => router.push("/(auth)/sign-up?returnTo=crisis"),
          style: "default"
        },
        {
          text: "I have an account",
          onPress: () => router.push("/(auth)/sign-in?returnTo=crisis"),
        },
        { text: "Cancel", style: "cancel" },
      ]
    );
  };

  const handleReset = () => {
    setGeneratedScript(null);
    setFormData({
      situation: "",
      age: "",
      neurotype: "",
    });
  };

  // Result state (if somehow they got a script - shouldn't happen for guests)
  if (generatedScript) {
    return (
      <SafeAreaView style={styles.screen}>
        <LinearGradient
          colors={["rgba(0,0,0,0.92)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.92)"]}
          style={StyleSheet.absoluteFillObject}
        />
        <ScriptDisplay
          script={generatedScript}
          isSaving={false}
          onSave={() => {
            Alert.alert(
              "Sign up to save",
              "Create a free account to save your scripts and get 5 free scripts per month.",
              [
                { text: "Sign Up", onPress: () => router.push("/(auth)/sign-up") },
                { text: "Not now", style: "cancel" },
              ]
            );
          }}
          onStartOver={handleReset}
          isPremium={false}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.screen}>
      <LinearGradient
        colors={["rgba(0,0,0,0.92)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.92)"]}
        style={StyleSheet.absoluteFillObject}
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} hitSlop={12}>
            <Text style={styles.backButton}>← Back</Text>
          </Pressable>
          <Text style={styles.headerTitle}>Try Sturdy Free</Text>
          <View style={styles.headerSpacer} />
        </View>

        <ScrollView style={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Form Card */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Get Your First Script Free</Text>
            <Text style={styles.cardSubtitle}>
              3 quick steps • 30 seconds • No signup yet
            </Text>

            {/* Step 1: Situation */}
            <View style={styles.stepContainer}>
              <View style={styles.stepHeader}>
                <View style={styles.stepBadge}>
                  <Text style={styles.stepNumber}>1</Text>
                </View>
                <Text style={styles.stepTitle}>What's happening?</Text>
              </View>
              <TextInput
                style={styles.textarea}
                placeholder="e.g., My 4-year-old is hitting when frustrated..."
                placeholderTextColor="rgba(255,255,255,0.4)"
                value={formData.situation}
                onChangeText={(text) => setFormData(prev => ({ ...prev, situation: text }))}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                maxLength={300}
              />
              <Text style={styles.charCount}>{formData.situation.length}/300</Text>
            </View>

            {/* Step 2: Age */}
            <View style={styles.stepContainer}>
              <View style={styles.stepHeader}>
                <View style={styles.stepBadge}>
                  <Text style={styles.stepNumber}>2</Text>
                </View>
                <Text style={styles.stepTitle}>Child's age</Text>
              </View>
              <View style={styles.buttonGrid}>
                {AGE_OPTIONS.map((option) => (
                  <Pressable
                    key={option.value}
                    style={[
                      styles.optionButton,
                      formData.age === option.value && styles.optionButtonSelected,
                    ]}
                    onPress={() => setFormData(prev => ({ ...prev, age: option.value }))}
                  >
                    <Text style={styles.optionIcon}>{option.icon}</Text>
                    <Text
                      style={[
                        styles.optionLabel,
                        formData.age === option.value && styles.optionLabelSelected,
                      ]}
                    >
                      {option.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            {/* Step 3: Neurotype */}
            <View style={styles.stepContainer}>
              <View style={styles.stepHeader}>
                <View style={styles.stepBadge}>
                  <Text style={styles.stepNumber}>3</Text>
                </View>
                <Text style={styles.stepTitle}>Any considerations?</Text>
              </View>
              <View style={styles.buttonGrid}>
                {NEUROTYPE_OPTIONS.map((option) => (
                  <Pressable
                    key={option.value}
                    style={[
                      styles.optionButton,
                      formData.neurotype === option.value && styles.optionButtonSelected,
                    ]}
                    onPress={() => setFormData(prev => ({ ...prev, neurotype: option.value }))}
                  >
                    <Text style={styles.optionIcon}>{option.icon}</Text>
                    <Text
                      style={[
                        styles.optionLabel,
                        formData.neurotype === option.value && styles.optionLabelSelected,
                      ]}
                    >
                      {option.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            {/* Generate Button */}
            <Pressable
              style={[styles.generateButton, !isFormValid && styles.generateButtonDisabled]}
              onPress={handleGenerate}
              disabled={!isFormValid}
            >
              <LinearGradient
                colors={isFormValid ? [GOLD, "#f59e0b"] : ["rgba(255,255,255,0.1)", "rgba(255,255,255,0.1)"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.generateButtonGradient}
              >
                <Text style={[styles.generateButtonText, !isFormValid && styles.generateButtonTextDisabled]}>
                  ✨ See My Script
                </Text>
              </LinearGradient>
            </Pressable>
          </View>
        </ScrollView>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            ✨ Sign up after to get 5 scripts/month and save your scripts
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#0B0F19",
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: dimensions.padding.md,
    paddingTop: responsiveSpacing(12),
    paddingBottom: responsiveSpacing(16),
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    color: "rgba(255,255,255,0.7)",
    fontSize: dimensions.fontSize.md,
    fontWeight: "600",
    width: 60,
  },
  headerTitle: {
    color: 'white',
    fontSize: dimensions.fontSize.lg,
    fontWeight: '900',
    textAlign: 'center',
  },
  headerSpacer: {
    width: 60,
  },
  scrollContent: {
    flex: 1,
    paddingHorizontal: dimensions.padding.md,
  },
  card: {
    backgroundColor: "rgba(15, 23, 42, 0.6)",
    borderRadius: dimensions.borderRadius.xl,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
    padding: dimensions.padding.lg,
    marginVertical: dimensions.margin.lg,
  },
  cardTitle: {
    color: "white",
    fontSize: dimensions.fontSize["2xl"],
    fontWeight: "900",
    marginBottom: responsiveSpacing(8),
    textAlign: "center",
  },
  cardSubtitle: {
    color: "rgba(255,255,255,0.6)",
    fontSize: dimensions.fontSize.sm,
    textAlign: "center",
    marginBottom: dimensions.margin.xl,
  },
  stepContainer: {
    marginBottom: dimensions.margin.xl,
  },
  stepHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: responsiveSpacing(12),
    gap: responsiveSpacing(12),
  },
  stepBadge: {
    width: responsiveSpacing(32),
    height: responsiveSpacing(32),
    borderRadius: 999,
    backgroundColor: "rgba(212, 175, 55, 0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  stepNumber: {
    color: GOLD,
    fontSize: dimensions.fontSize.md,
    fontWeight: "700",
  },
  stepTitle: {
    color: "white",
    fontSize: dimensions.fontSize.lg,
    fontWeight: "900",
    flex: 1,
  },
  textarea: {
    backgroundColor: "rgba(255,255,255,0.1)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
    borderRadius: dimensions.borderRadius.md,
    padding: dimensions.padding.md,
    color: "white",
    fontSize: dimensions.fontSize.base,
    minHeight: responsiveHeight(100, 90, 120),
  },
  charCount: {
    color: "rgba(255,255,255,0.5)",
    fontSize: dimensions.fontSize.sm,
    textAlign: "right",
    marginTop: responsiveSpacing(4),
  },
  buttonGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: responsiveSpacing(12),
  },
  optionButton: {
    backgroundColor: "rgba(255,255,255,0.08)",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.15)",
    borderRadius: dimensions.borderRadius.md,
    padding: dimensions.padding.md,
    alignItems: "center",
    width: "48%",
    minHeight: responsiveSpacing(90),
    justifyContent: "center",
  },
  optionButtonSelected: {
    backgroundColor: GOLD,
    borderColor: GOLD,
  },
  optionIcon: {
    fontSize: dimensions.fontSize["2xl"],
    marginBottom: responsiveSpacing(8),
  },
  optionLabel: {
    color: "white",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "700",
    textAlign: "center",
  },
  optionLabelSelected: {
    color: "#0B0F19",
  },
  generateButton: {
    borderRadius: dimensions.borderRadius.md,
    overflow: "hidden",
    marginTop: dimensions.margin.md,
  },
  generateButtonDisabled: {
    opacity: 0.5,
  },
  generateButtonGradient: {
    paddingVertical: dimensions.padding.md,
    alignItems: "center",
    justifyContent: "center",
  },
  generateButtonText: {
    color: "#0B0F19",
    fontSize: dimensions.fontSize.lg,
    fontWeight: "700",
  },
  generateButtonTextDisabled: {
    color: "rgba(255,255,255,0.4)",
  },
  footer: {
    paddingHorizontal: dimensions.padding.lg,
    paddingVertical: responsiveSpacing(16),
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  footerText: {
    color: "rgba(255,255,255,0.5)",
    fontSize: dimensions.fontSize.sm,
    textAlign: "center",
    lineHeight: responsiveSpacing(20),
  },
});
