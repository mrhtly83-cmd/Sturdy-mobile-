import { useState, useEffect } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { supabase } from "../../lib/supabase";
import { dimensions, responsiveSpacing, responsiveHeight } from "../../theme/dimensions";

const GOLD = "#D4AF37";

export default function SignUp() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasPendingScript, setHasPendingScript] = useState(false);
  const { returnTo } = useLocalSearchParams<{ returnTo?: string }>();

  // Check if user has a pending script request
  useEffect(() => {
    checkPendingScript();
  }, []);

  const checkPendingScript = async () => {
    try {
      const pending = await AsyncStorage.getItem('pending_script_request');
      if (pending) {
        setHasPendingScript(true);
      }
    } catch (err) {
      console.error('Failed to check pending script:', err);
    }
  };

  const onSignUp = async () => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      return Alert.alert("Missing info", "Enter email and password.");
    }

    try {
      setLoading(true);

      const { data, error } = await supabase.auth.signUp({
        email: cleanEmail,
        password,
      });

      if (error) return Alert.alert("Sign up failed", error.message);

      // If email confirmation is enabled
      if (!data.session) {
        Alert.alert(
          "Check your email",
          "Confirm your email to activate your account, then come back to sign in."
        );
        // Redirect to sign-in with the returnTo parameter
        if (returnTo) {
          router.replace(`/(auth)/sign-in?returnTo=${returnTo}`);
        } else {
          router.replace("/(auth)/sign-in");
        }
        return;
      }

      // Successful sign up with immediate session
      if (returnTo === "crisis") {
        router.replace("/(tabs)/crisis");
      } else {
        router.replace("/(tabs)");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.background}>
      <LinearGradient
        colors={["rgba(0,0,0,0.65)", "rgba(0,0,0,0.85)"]}
        style={StyleSheet.absoluteFillObject}
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.container}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.logo}>Sturdy</Text>
          <Pressable onPress={() => router.push("/(auth)/sign-in")}>
            <Text style={styles.headerLink}>Sign In</Text>
          </Pressable>
        </View>

        {/* Script Ready Banner */}
        {hasPendingScript && (
          <View style={styles.banner}>
            <LinearGradient
              colors={[GOLD, "#f59e0b"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.bannerGradient}
            >
              <Text style={styles.bannerIcon}>✨</Text>
              <View style={styles.bannerTextContainer}>
                <Text style={styles.bannerTitle}>Your script is ready!</Text>
                <Text style={styles.bannerSubtitle}>
                  Sign up to see your personalized parenting script
                </Text>
              </View>
            </LinearGradient>
          </View>
        )}

        {/* Glass Card */}
        <View style={styles.card}>
          <Text style={styles.title}>
            Raise calm.
            {"\n"}
            <Text style={styles.goldText}>Lead with confidence.</Text>
          </Text>

          <Text style={styles.subtitle}>
            Build stronger moments — one response at a time.
          </Text>

          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Email"
            placeholderTextColor="rgba(255,255,255,0.5)"
            autoCapitalize="none"
            keyboardType="email-address"
            style={styles.input}
          />

          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Password (min 6 characters)"
            placeholderTextColor="rgba(255,255,255,0.5)"
            secureTextEntry
            style={styles.input}
          />

          <Pressable
            onPress={onSignUp}
            disabled={loading}
            style={[
              styles.button,
              { opacity: loading ? 0.6 : 1 },
            ]}
          >
            <Text style={styles.buttonText}>
              {loading ? "Creating account..." : "Get 5 Free Scripts"}
            </Text>
          </Pressable>

          <Text style={styles.note}>
            No credit card required.
          </Text>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: "#0B0F19",
  },
  container: {
    flex: 1,
    paddingHorizontal: dimensions.padding.lg,
    paddingTop: responsiveHeight(60, 48, 72),
    justifyContent: "space-between",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  logo: {
    fontSize: dimensions.fontSize["2xl"],
    fontWeight: "700",
    color: "white",
  },
  headerLink: {
    color: "white",
    opacity: 0.8,
    fontWeight: "500",
    fontSize: dimensions.fontSize.base,
  },
  banner: {
    marginTop: responsiveSpacing(20),
    marginBottom: responsiveSpacing(12),
    borderRadius: dimensions.borderRadius.lg,
    overflow: 'hidden',
  },
  bannerGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: dimensions.padding.md,
  },
  bannerIcon: {
    fontSize: dimensions.fontSize['2xl'],
    marginRight: responsiveSpacing(12),
  },
  bannerTextContainer: {
    flex: 1,
  },
  bannerTitle: {
    color: '#0B0F19',
    fontSize: dimensions.fontSize.base,
    fontWeight: '900',
    marginBottom: responsiveSpacing(4),
  },
  bannerSubtitle: {
    color: 'rgba(11, 15, 25, 0.8)',
    fontSize: dimensions.fontSize.sm,
    fontWeight: '600',
  },
  card: {
    backgroundColor: "rgba(255,255,255,0.08)",
    borderRadius: dimensions.borderRadius.xl,
    padding: dimensions.padding.lg,
    marginBottom: responsiveHeight(80, 60, 100),
  },
  title: {
    fontSize: dimensions.fontSize["2xl"],
    fontWeight: "700",
    color: "white",
    marginBottom: responsiveSpacing(8),
  },
  goldText: {
    color: GOLD,
  },
  subtitle: {
    color: "rgba(255,255,255,0.7)",
    fontSize: dimensions.fontSize.base,
    marginBottom: dimensions.margin.lg,
  },
  input: {
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)",
    borderRadius: dimensions.borderRadius.md,
    padding: dimensions.padding.md,
    marginBottom: dimensions.margin.md,
    color: "white",
    fontSize: dimensions.fontSize.base,
    backgroundColor: "rgba(255,255,255,0.05)",
  },
  button: {
    backgroundColor: GOLD,
    borderRadius: dimensions.borderRadius.md,
    padding: dimensions.padding.md,
    alignItems: "center",
    marginTop: dimensions.margin.sm,
  },
  buttonText: {
    color: "#0B0F19",
    fontSize: dimensions.fontSize.base,
    fontWeight: "700",
  },
  note: {
    textAlign: "center",
    color: "rgba(255,255,255,0.5)",
    fontSize: dimensions.fontSize.sm,
    marginTop: dimensions.margin.md,
  },
});
