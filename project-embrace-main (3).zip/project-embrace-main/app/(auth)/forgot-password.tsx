import { useState } from "react";
import {
  Alert,
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { supabase } from "../../lib/supabase";
import { Button } from "../../components/shared/Button";
import { dimensions, responsiveSpacing, responsiveFontSize } from "../../theme/dimensions";

const GOLD = "#D4AF37";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const onSendResetLink = async () => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      return Alert.alert("Missing info", "Enter your email address.");
    }

    try {
      setLoading(true);

      const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
        redirectTo: "sturdyapp://reset-password",
      });

      if (error) {
        return Alert.alert("Error", error.message);
      }

      setSent(true);
    } catch (error: any) {
      Alert.alert("Error", error.message || "Failed to send reset link");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ImageBackground
      source={require("../../assets/images/hero-home.jpg")}
      style={styles.background}
      resizeMode="cover"
    >
      <LinearGradient
        colors={["rgba(0,0,0,0.65)", "rgba(0,0,0,0.9)"]}
        style={StyleSheet.absoluteFillObject}
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.container}
      >
        {/* Header */}
        <View style={styles.header}>
          <Pressable onPress={() => router.back()}>
            <Text style={styles.headerLink}>← Back</Text>
          </Pressable>
          <Image source={require("../../assets/images/logo.png")} style={styles.logoImage} />
          <View style={{ width: 60 }} />
        </View>

        {/* Glass Card */}
        <View style={styles.card}>
          {!sent ? (
            <>
              <Text style={styles.title}>Reset Password</Text>

              <Text style={styles.subtitle}>
                Enter your email and we'll send you a link to reset your password.
              </Text>

              <TextInput
                value={email}
                onChangeText={setEmail}
                placeholder="Email"
                placeholderTextColor="rgba(255,255,255,0.5)"
                autoCapitalize="none"
                keyboardType="email-address"
                style={styles.input}
              />

              <Button
                title={loading ? "Sending..." : "Send Reset Link"}
                onPress={onSendResetLink}
                disabled={loading}
              />

              <Pressable onPress={() => router.push("/(auth)/sign-in")} style={styles.linkRow}>
                <Text style={styles.linkText}>Remember your password? </Text>
                <Text style={[styles.linkText, styles.linkHighlight]}>Sign In</Text>
              </Pressable>
            </>
          ) : (
            <>
              <Text style={styles.title}>Check Your Email</Text>

              <Text style={styles.subtitle}>
                We've sent a password reset link to{" "}
                <Text style={styles.gold}>{email}</Text>
                {"\n\n"}
                Check your inbox and click the link to reset your password.
              </Text>

              <Button title="Back to Sign In" onPress={() => router.push("/(auth)/sign-in")} />
            </>
          )}
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>You don't need perfect. You need steady.</Text>
        </View>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    paddingHorizontal: dimensions.padding.md,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: responsiveSpacing(56, 48, 64),
    paddingBottom: responsiveSpacing(20, 16, 24),
  },
  headerLink: {
    color: "rgba(255,255,255,0.85)",
    fontSize: responsiveFontSize(15, 14, 16),
    fontWeight: "700",
  },
  logoImage: {
    width: responsiveSpacing(48, 42, 54),
    height: responsiveSpacing(48, 42, 54),
    resizeMode: "contain",
  },
  card: {
    backgroundColor: "rgba(255,255,255,0.08)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    borderRadius: dimensions.borderRadius.lg,
    padding: dimensions.padding.lg,
    marginTop: responsiveSpacing(24, 20, 28),
  },
  title: {
    color: "white",
    fontSize: responsiveFontSize(28, 26, 30),
    fontWeight: "800",
    marginBottom: responsiveSpacing(12, 10, 14),
  },
  gold: {
    color: GOLD,
  },
  subtitle: {
    color: "rgba(255,255,255,0.75)",
    fontSize: responsiveFontSize(15, 14, 16),
    fontWeight: "600",
    lineHeight: 22,
    marginBottom: responsiveSpacing(24, 20, 28),
  },
  input: {
    backgroundColor: "rgba(255,255,255,0.10)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    borderRadius: dimensions.borderRadius.md,
    paddingHorizontal: dimensions.padding.md,
    paddingVertical: dimensions.padding.sm,
    color: "white",
    fontSize: responsiveFontSize(16, 15, 17),
    fontWeight: "600",
    marginBottom: responsiveSpacing(16, 14, 18),
  },
  linkRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: responsiveSpacing(16, 14, 18),
  },
  linkText: {
    color: "rgba(255,255,255,0.7)",
    fontSize: responsiveFontSize(14, 13, 15),
    fontWeight: "600",
  },
  linkHighlight: {
    color: GOLD,
    fontWeight: "800",
  },
  footer: {
    marginTop: "auto",
    paddingVertical: responsiveSpacing(24, 20, 28),
    alignItems: "center",
  },
  footerText: {
    color: "rgba(255,255,255,0.45)",
    fontSize: responsiveFontSize(12, 11, 13),
    fontWeight: "600",
  },
});
