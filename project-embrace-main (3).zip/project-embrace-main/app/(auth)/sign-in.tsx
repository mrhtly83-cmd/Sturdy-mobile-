import { useState } from "react";
import {
  Alert,
  Image,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { supabase } from "../../lib/supabase";
import { dimensions, responsiveSpacing, responsiveHeight } from "../../theme/dimensions";

export default function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { returnTo } = useLocalSearchParams<{ returnTo?: string }>();

  const onSignIn = async () => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      return Alert.alert("Missing info", "Enter email and password.");
    }

    try {
      setLoading(true);

      const { error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password,
      });

      if (error) return Alert.alert("Sign in failed", error.message);

      // Redirect based on returnTo parameter
      if (returnTo === "crisis") {
        router.replace("/(tabs)/crisis");
      } else {
        router.replace("/(tabs)");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <ImageBackground 
      source={require("../../assets/images/hero-home.jpg")} 
      style={styles.background}
      resizeMode="cover"
    >
      <LinearGradient
        colors={["rgba(0,0,0,0.65)", "rgba(0,0,0,0.9)"]}
        style={StyleSheet.absoluteFillObject}
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.container}
      >
        {/* Header */}
        <View style={styles.header}>
          <Image 
            source={require("../../assets/images/logo.png")} 
            style={styles.logoImage} 
          />
          <Pressable onPress={() => router.push("/sign-up")}>
            <Text style={styles.headerLink}>Sign Up</Text>
          </Pressable>
        </View>

        {/* Glass Card */}
        <View style={styles.card}>
          <Text style={styles.title}>
            Stop freezing.
            {"\n"}
            <Text style={styles.gold}>Start connecting.</Text>
          </Text>

          <Text style={styles.subtitle}>
            Research-backed parenting scripts in 3 taps.
          </Text>

          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Email"
            placeholderTextColor="rgba(255,255,255,0.5)"
            autoCapitalize="none"
            keyboardType="email-address"
            style={styles.input}
          />

          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Password"
            placeholderTextColor="rgba(255,255,255,0.5)"
            secureTextEntry
            style={styles.input}
          />

          <Pressable onPress={() => router.push("/(auth)/forgot-password")} style={styles.forgotLink}>
            <Text style={styles.forgotText}>Forgot password?</Text>
          </Pressable>

          <Pressable
            onPress={onSignIn}
            disabled={loading}
            style={[styles.button, loading && { opacity: 0.6 }]}
          >
            <Text style={styles.buttonText}>
              {loading ? "Signing in..." : "Continue"}
            </Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    paddingHorizontal: dimensions.padding.lg,
    paddingTop: responsiveHeight(60, 48, 72),
    justifyContent: "space-between",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  logoImage: {
    width: responsiveSpacing(40, 36, 48),
    height: responsiveSpacing(40, 36, 48),
    resizeMode: "contain",
  },
  headerLink: {
    color: "white",
    opacity: 0.8,
    fontWeight: "500",
    fontSize: dimensions.fontSize.base,
  },
  card: {
    backgroundColor: "rgba(255,255,255,0.08)",
    borderRadius: dimensions.borderRadius.xl,
    padding: dimensions.padding.lg,
    marginBottom: responsiveHeight(80, 60, 100),
  },
  title: {
    fontSize: dimensions.fontSize["2xl"],
    fontWeight: "700",
    color: "white",
    marginBottom: responsiveSpacing(8),
  },
  gold: {
    color: "#D4AF37",
  },
  subtitle: {
    color: "rgba(255,255,255,0.7)",
    fontSize: dimensions.fontSize.base,
    marginBottom: dimensions.margin.lg,
  },
  input: {
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.2)",
    borderRadius: dimensions.borderRadius.md,
    padding: dimensions.padding.md,
    fontSize: dimensions.fontSize.base,
    color: "white",
    marginBottom: dimensions.margin.sm,
    backgroundColor: "rgba(255,255,255,0.06)",
  },
  forgotLink: {
    alignSelf: "flex-end",
    marginBottom: responsiveSpacing(12),
  },
  forgotText: {
    color: "#D4AF37",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
  },
  button: {
    backgroundColor: "#D4AF37",
    paddingVertical: dimensions.padding.md,
    borderRadius: dimensions.borderRadius.md,
    alignItems: "center",
    marginTop: responsiveSpacing(4),
  },
  buttonText: {
    color: "#111",
    fontWeight: "700",
    fontSize: dimensions.fontSize.md,
  },
});
