import React, { useMemo, useState, useEffect } from "react";
import {
  View,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Text,
  Pressable,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";

import { Button } from "../../components/shared/Button";
import { LoadingSpinner } from "../../components/shared/LoadingSpinner";
import { SituationInput } from "../../components/crisis/SituationInput";
import { ChildAgeSelector } from "../../components/crisis/ChildAgeSelector";
import { ScriptDisplay } from "../../components/crisis/ScriptDisplay";

import { useChildren } from "../../hooks/useChildren";
import { usePaywall } from "../../hooks/usePaywall";
import { generateScript, saveScriptToDatabase } from "../../services/api/scripts";
import { ConsciousDisciplineResponse } from "../../lib/types";
import { supabase } from "../../lib/supabase";
import {
  dimensions,
  responsiveFontSize,
  responsiveSpacing,
  responsiveHeight,
} from "../../theme/dimensions";

type Step = "situation" | "child" | "generating" | "display";

const GUEST_LIMIT_PER_MONTH = 1;

function monthKey() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${yyyy}-${mm}`;
}

function guestStorageKey() {
  return `sturdy:guest_crisis_uses:${monthKey()}`;
}

async function getGuestUsesThisMonth(): Promise<number> {
  const raw = await AsyncStorage.getItem(guestStorageKey());
  const n = raw ? Number(raw) : 0;
  return Number.isFinite(n) ? n : 0;
}

async function incrementGuestUsesThisMonth(): Promise<number> {
  const current = await getGuestUsesThisMonth();
  const next = current + 1;
  await AsyncStorage.setItem(guestStorageKey(), String(next));
  return next;
}

const GOLD = "#D4AF37";

const NEUROTYPES = [
  { key: "neurotypical", label: "Neurotypical" },
  { key: "adhd", label: "ADHD" },
  { key: "autism", label: "Autism" },
  { key: "anxiety", label: "Anxiety" },
  { key: "sensory", label: "Sensory" },
];

export default function CrisisScreen() {
  const [step, setStep] = useState<Step>("situation");
  const [situation, setSituation] = useState("");
  const [selectedChildId, setSelectedChildId] = useState<string | null>(null);
  const [customAge, setCustomAge] = useState("");
  const [selectedNeurotype, setSelectedNeurotype] = useState<string>("neurotypical");
  const [neurotypeOpen, setNeurotypeOpen] = useState(false);
  const [generatedScript, setGeneratedScript] =
    useState<ConsciousDisciplineResponse | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // NEW: when a script is saved, we keep its id so ScriptDisplay can attach user_rating
  const [savedScriptId, setSavedScriptId] = useState<string | null>(null);

  const { children, loading: childrenLoading } = useChildren();
  const { isPremium, remainingScripts, hasHitFreeLimit, loading: paywallLoading } = usePaywall();

  // ✅ Check for pending script request from guest flow
  useEffect(() => {
    const loadPendingRequest = async () => {
      try {
        const pending = await AsyncStorage.getItem("pending_script_request");
        if (pending) {
          const data = JSON.parse(pending);
          // Pre-fill the form with saved data
          setSituation(data.situation || "");
          setCustomAge(data.childAge || "");
          setSelectedNeurotype(data.neurotype || "neurotypical");
          // Clear the pending request immediately
          await AsyncStorage.removeItem("pending_script_request");

          // Show a helpful message
          Alert.alert(
            "Welcome back!",
            "Your form has been restored. Click 'Generate Script' to continue.",
            [{ text: "Got it" }]
          );
        }
      } catch (err) {
        console.error("Failed to load pending request:", err);
      }
    };

    loadPendingRequest();
  }, []);

  const selectedChild = useMemo(
    () => children.find((c) => c.id === selectedChildId),
    [children, selectedChildId]
  );

  const childAge = useMemo(() => {
    if (selectedChild?.birth_date) return calculateChildAge(selectedChild.birth_date);
    return customAge;
  }, [selectedChild?.birth_date, customAge]);

  const childNeurotype = useMemo(() => {
    // If child profile has neurotype, use it; otherwise use selectedNeurotype.
    return selectedChild?.neurotype || selectedNeurotype;
  }, [selectedChild?.neurotype, selectedNeurotype]);

  function calculateChildAge(birthDate?: string): string {
    if (!birthDate) return "";
    const birth = new Date(birthDate);
    const today = new Date();
    const years = today.getFullYear() - birth.getFullYear();
    const months = today.getMonth() - birth.getMonth();

    if (years <= 0) return `${Math.max(0, months)} months`;
    if (years < 2) return `${years} year, ${Math.max(0, months)} months`;
    return `${years} years`;
  }

  const handleBack = () => {
    setNeurotypeOpen(false);
    if (step === "child") setStep("situation");
    else if (step === "display") setStep("child");
  };

  const goNextFromSituation = () => {
    if (!situation.trim()) {
      Alert.alert("Required", "Describe what's happening in one sentence.");
      return;
    }
    if (situation.length > 300) {
      Alert.alert("Too long", "Keep it under 300 characters.");
      return;
    }
    setStep("child");
  };

  const handleGenerateScript = async () => {
    if (!situation.trim()) return Alert.alert("Required", "Describe the situation first.");
    if (!childAge) return Alert.alert("Required", "Select a child or enter an age.");

    if (hasHitFreeLimit) {
      Alert.alert(
        "Upgrade Required",
        "You've used all your free scripts. Upgrade to Premium for unlimited scripts!",
        [
          { text: "Not now", style: "cancel" },
          { text: "Upgrade", onPress: () => router.push("/(tabs)/settings") },
        ]
      );
      return;
    }

    try {
      // Reset any previously saved script id when generating a new one
      setSavedScriptId(null);

      // ✅ Ensure we have a session (guest users get anonymous auth)
      let {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        const { data, error } = await supabase.auth.signInAnonymously();
        if (error) {
          throw new Error(error.message || "Unable to start guest session.");
        }
        session = data.session ?? null;
      }

      const isLoggedIn = !!session?.user;

      // ✅ Guest gating (no account)
      if (!isLoggedIn) {
        const used = await getGuestUsesThisMonth();
        if (used >= GUEST_LIMIT_PER_MONTH) {
          Alert.alert(
            "Free try used",
            "You've used your 1 free script for this month. Create a free account to get more (and save your scripts).",
            [
              { text: "Sign In", onPress: () => router.push("/(auth)/sign-in") },
              { text: "Sign Up", onPress: () => router.push("/(auth)/sign-up") },
              { text: "OK", style: "cancel" },
            ]
          );
          return;
        }
      }

      setStep("generating");

      const script = await generateScript({
        situation,
        childAge,
        neurotype: childNeurotype,
        isPremium,
      });

      // ✅ Count guest usage only after a successful generation
      if (!isLoggedIn) {
        await incrementGuestUsesThisMonth();
      }

      setGeneratedScript(script);
      setStep("display");
    } catch (error: any) {
      console.error("Generate script error:", error);
      Alert.alert("Error", error.message || "Failed to generate script. Try again.");
      setStep("child");
    }
  };

  const handleSaveScript = async () => {
    if (!generatedScript) return;

    try {
      setIsSaving(true);

      const scriptText = `${generatedScript.part1.title}\n${generatedScript.part1.script}\n\n${generatedScript.part2.title}\n${generatedScript.part2.script}\n\n${generatedScript.part3.title}\n${generatedScript.part3.script}\n\nMantra: ${generatedScript.parentMantra}`;

      // NEW: save metadata + get script id back
      const scriptId = await saveScriptToDatabase({
        situation,
        scriptText,
        childId: selectedChildId || undefined,
        category: "crisis",

        mode: "crisis",
        childAge,
        neurotype: childNeurotype,
        scriptJson: generatedScript,
      });

      setSavedScriptId(scriptId);

      // IMPORTANT: don't reset immediately — user will rate it in ScriptDisplay
      Alert.alert("Saved", "Added to your library. Rate how it went below 👇");
    } catch (error: any) {
      console.error("Save script error:", error);
      Alert.alert("Error", "Failed to save. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleStartOver = () => {
    setStep("situation");
    setSituation("");
    setSelectedChildId(null);
    setCustomAge("");
    setSelectedNeurotype("neurotypical");
    setNeurotypeOpen(false);
    setGeneratedScript(null);
    setSavedScriptId(null);
  };

  if (childrenLoading || paywallLoading) {
    return (
      <SafeAreaView style={styles.screen}>
        <LoadingSpinner />
      </SafeAreaView>
    );
  }

  if (step === "generating") {
    return (
      <SafeAreaView style={styles.screen}>
        <LinearGradient
          colors={["rgba(0,0,0,0.85)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.95)"]}
          style={styles.ambience}
        />
        <View style={styles.center}>
          <LoadingSpinner size="large" />
          <Text style={styles.generatingTitle}>Finding your words…</Text>
          <Text style={styles.generatingSub}>Regulate → Connect → Guide</Text>
          <View style={{ height: 14 }} />
          <Button title="Generating…" variant="secondary" disabled onPress={() => {}} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
      <LinearGradient
        colors={["rgba(0,0,0,0.85)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.95)"]}
        style={styles.ambience}
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} hitSlop={12}>
            <Text style={styles.headerLink}>Back</Text>
          </Pressable>

          <View style={{ alignItems: "center" }}>
            <Text style={styles.headerTitle}>Crisis Mode</Text>
            <Text style={styles.headerSub}>Instant script in 2 steps</Text>
          </View>

          <View style={{ width: 48, alignItems: "flex-end" }}>
            {!isPremium && typeof remainingScripts === "number" && (
              <Text style={styles.pill}>{remainingScripts} free</Text>
            )}
          </View>
        </View>

        <View style={styles.body}>
          <View style={styles.glass}>
            {/* Step 1: Situation */}
            {step === "situation" && (
              <>
                <Text style={styles.stepTitle}>What’s happening?</Text>
                <Text style={styles.stepSub}>
                  One sentence is enough. Avoid names if you can.
                </Text>
                <View style={{ height: 12 }} />
                <SituationInput situation={situation} onSituationChange={setSituation} />
                <View style={styles.footer}>
                  <Button title="Next" onPress={goNextFromSituation} style={{ flex: 1 }} />
                </View>
              </>
            )}

            {/* Step 2: Child + Neurotype */}
            {step === "child" && (
              <>
                <Text style={styles.stepTitle}>Age + neurotype</Text>
                <Text style={styles.stepSub}>
                  This helps Sturdy choose calm + firm words that fit.
                </Text>

                <View style={{ height: 12 }} />
                <ChildAgeSelector
                  childrenList={children}
                  selectedChildId={selectedChildId}
                  customAge={customAge}
                  onSelectChild={setSelectedChildId}
                  onCustomAgeChange={setCustomAge}
                />

                {/* Neurotype dropdown (Crisis Mode) */}
                <View style={{ marginTop: 12 }}>
                  <Text style={styles.neuroLabel}>Neurotype</Text>

                  <Pressable
                    onPress={() => setNeurotypeOpen((v) => !v)}
                    style={styles.dropdownTrigger}
                  >
                    <Text style={styles.dropdownValue}>
                      {NEUROTYPES.find((n) => n.key === selectedNeurotype)?.label ?? "Select"}
                    </Text>
                    <Text style={styles.dropdownChevron}>{neurotypeOpen ? "▲" : "▼"}</Text>
                  </Pressable>

                  {neurotypeOpen && (
                    <View style={styles.dropdownMenu}>
                      {NEUROTYPES.map((n) => {
                        const active = selectedNeurotype === n.key;
                        return (
                          <Pressable
                            key={n.key}
                            onPress={() => {
                              setSelectedNeurotype(n.key);
                              setNeurotypeOpen(false);
                            }}
                            style={[styles.dropdownItem, active && styles.dropdownItemActive]}
                          >
                            <Text
                              style={[
                                styles.dropdownItemText,
                                active && styles.dropdownItemTextActive,
                              ]}
                            >
                              {n.label}
                            </Text>
                          </Pressable>
                        );
                      })}
                    </View>
                  )}

                  <Text style={styles.neuroHint}>
                    If you&apos;re unsure, keep Neurotypical.
                  </Text>
                </View>

                <View style={styles.footer}>
                  <Button title="Back" onPress={handleBack} variant="outline" />
                  <Button
                    title="Generate Script"
                    onPress={handleGenerateScript}
                    disabled={!childAge}
                    style={{ flex: 1, marginLeft: 12 }}
                  />
                </View>
              </>
            )}

            {/* Display */}
            {step === "display" && generatedScript && (
              <ScriptDisplay
                script={generatedScript}
                isSaving={isSaving}
                onSave={handleSaveScript}
                onStartOver={handleStartOver}
                isPremium={isPremium}
                // NEW: enables rating after save
                scriptId={savedScriptId}
              />
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#0B0F19" },
  ambience: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: responsiveHeight(260, 200, 320),
  },

  header: {
    paddingHorizontal: dimensions.padding.md,
    paddingTop: responsiveSpacing(10, 8, 12),
    paddingBottom: responsiveSpacing(10, 8, 12),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerLink: {
    color: "rgba(255,255,255,0.8)",
    fontWeight: "700",
    width: responsiveSpacing(48),
  },
  headerTitle: { color: "white", fontSize: dimensions.fontSize.md, fontWeight: "900" },
  headerSub: {
    color: "rgba(255,255,255,0.65)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "600",
    marginTop: 2,
  },
  pill: {
    color: GOLD,
    fontSize: responsiveFontSize(11, 10, 12),
    fontWeight: "900",
    paddingHorizontal: responsiveSpacing(10, 8, 12),
    paddingVertical: responsiveSpacing(6, 5, 8),
    borderRadius: 999,
    backgroundColor: "rgba(212,175,55,0.14)",
    borderWidth: 1,
    borderColor: "rgba(212,175,55,0.22)",
  },

  body: {
    flex: 1,
    paddingHorizontal: dimensions.padding.md,
    paddingBottom: dimensions.padding.md,
    paddingTop: responsiveSpacing(6),
  },
  glass: {
    flex: 1,
    backgroundColor: "rgba(255,255,255,0.08)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    borderRadius: dimensions.borderRadius.lg,
    padding: dimensions.padding.md,
    overflow: "hidden",
  },

  stepTitle: { color: "white", fontSize: dimensions.fontSize.lg, fontWeight: "900" },
  stepSub: {
    color: "rgba(255,255,255,0.68)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
    marginTop: responsiveSpacing(6),
    lineHeight: responsiveHeight(18, 16, 22),
  },

  neuroLabel: {
    color: "rgba(255,255,255,0.8)",
    fontWeight: "800",
    marginBottom: responsiveSpacing(8),
    marginTop: responsiveSpacing(6),
  },
  dropdownTrigger: {
    marginTop: responsiveSpacing(8),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: dimensions.padding.sm,
    paddingVertical: dimensions.padding.sm,
    borderRadius: dimensions.borderRadius.md,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    backgroundColor: "rgba(255,255,255,0.06)",
  },
  dropdownValue: {
    color: "white",
    fontWeight: "800",
    fontSize: dimensions.fontSize.sm,
  },
  dropdownChevron: {
    color: "rgba(255,255,255,0.7)",
    fontWeight: "900",
    fontSize: dimensions.fontSize.xs,
  },
  dropdownMenu: {
    marginTop: responsiveSpacing(10),
    borderRadius: dimensions.borderRadius.md,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    backgroundColor: "rgba(20,24,36,0.92)",
  },
  dropdownItem: {
    paddingHorizontal: dimensions.padding.sm,
    paddingVertical: dimensions.padding.sm,
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.08)",
  },
  dropdownItemActive: {
    backgroundColor: "rgba(212,175,55,0.14)",
  },
  dropdownItemText: {
    color: "rgba(255,255,255,0.78)",
    fontWeight: "800",
    fontSize: dimensions.fontSize.sm,
  },
  dropdownItemTextActive: {
    color: "white",
  },
  neuroHint: {
    marginTop: responsiveSpacing(8),
    color: "rgba(255,255,255,0.55)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "600",
  },

  footer: {
    flexDirection: "row",
    marginTop: dimensions.margin.sm,
    paddingTop: dimensions.padding.sm,
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.10)",
  },

  center: {
    flex: 1,
    paddingHorizontal: dimensions.padding.md,
    alignItems: "center",
    justifyContent: "center",
  },
  generatingTitle: {
    color: "white",
    fontSize: dimensions.fontSize.lg,
    fontWeight: "900",
    marginTop: dimensions.margin.sm,
  },
  generatingSub: {
    color: "rgba(255,255,255,0.7)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
    marginTop: responsiveSpacing(6),
  },
});
