import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  Modal,
  TextInput,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";

import { Card } from "../../components/shared/Card";
import { Button } from "../../components/shared/Button";
import { LoadingSpinner } from "../../components/shared/LoadingSpinner";
import { EmptyState } from "../../components/shared/EmptyState";
import {
  useChildren,
  useAddChild,
  useUpdateChild,
  useDeleteChild,
  useDefaultChild,
  useSetDefaultChild,
} from "../../hooks/useChildren";
import { NEUROTYPES } from "../../config/neurotypes";
import { dimensions, responsiveFontSize, responsiveSpacing } from "../../theme/dimensions";

const GOLD = "#D4AF37";

type ModalMode = "add" | "edit" | null;

interface ChildFormData {
  id?: string;
  name: string;
  birthDate: string;
  neurotype: string;
}

export default function ChildrenScreen() {
  const [modalMode, setModalMode] = useState<ModalMode>(null);
  const [formData, setFormData] = useState<ChildFormData>({
    name: "",
    birthDate: "",
    neurotype: "neurotypical",
  });
  const [neurotypeOpen, setNeurotypeOpen] = useState(false);

  const { children, loading, refresh } = useChildren();
  const { defaultChildId } = useDefaultChild();
  const { setDefaultChild } = useSetDefaultChild();
  const { addChild, loading: adding } = useAddChild();
  const { updateChild, loading: updating } = useUpdateChild();
  const { deleteChild, loading: deleting } = useDeleteChild();

  const handleOpenAdd = () => {
    setFormData({ name: "", birthDate: "", neurotype: "neurotypical" });
    setModalMode("add");
  };

  const handleOpenEdit = (child: any) => {
    setFormData({
      id: child.id,
      name: child.name,
      birthDate: child.birth_date || "",
      neurotype: child.neurotype || "neurotypical",
    });
    setModalMode("edit");
  };

  const handleCloseModal = () => {
    setModalMode(null);
    setFormData({ name: "", birthDate: "", neurotype: "neurotypical" });
    setNeurotypeOpen(false);
  };

  const handleSubmit = async () => {
    if (!formData.name.trim()) {
      Alert.alert("Required", "Please enter a name");
      return;
    }

    try {
      if (modalMode === "add") {
        await addChild({
          name: formData.name.trim(),
          birthDate: formData.birthDate || undefined,
          neurotype: formData.neurotype,
        });
      } else if (modalMode === "edit" && formData.id) {
        await updateChild({
          id: formData.id,
          name: formData.name.trim(),
          birthDate: formData.birthDate || "",
          neurotype: formData.neurotype,
        });
      }

      await refresh();
      handleCloseModal();
    } catch (error: any) {
      Alert.alert("Error", error.message || "Failed to save child profile");
    }
  };

  const handleDelete = async (childId: string, childName: string) => {
    Alert.alert(
      "Delete Profile",
      `Remove ${childName}? This can't be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteChild(childId);
              await refresh();
            } catch (error: any) {
              Alert.alert("Error", error.message || "Failed to delete child");
            }
          },
        },
      ]
    );
  };

  const handleSetDefault = async (childId: string) => {
    try {
      await setDefaultChild(childId);
      await refresh();
    } catch (error: any) {
      Alert.alert("Error", error.message || "Failed to set default child");
    }
  };

  const calculateAge = (birthDate?: string): string => {
    if (!birthDate) return "Age not set";

    const birth = new Date(birthDate);
    const today = new Date();
    const years = today.getFullYear() - birth.getFullYear();
    const months = today.getMonth() - birth.getMonth();

    if (years <= 0) return `${Math.max(0, months)} months`;
    if (years < 2) return `${years} year, ${Math.max(0, months)} months`;
    return `${years} years`;
  };

  if (loading && children.length === 0) {
    return (
      <SafeAreaView style={styles.screen}>
        <LoadingSpinner />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
      <LinearGradient
        colors={["rgba(0,0,0,0.85)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.95)"]}
        style={styles.ambience}
      />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Children</Text>
          <Text style={styles.headerSub}>
            {children.length} {children.length === 1 ? "profile" : "profiles"}
          </Text>
        </View>
        <Pressable onPress={handleOpenAdd} hitSlop={12}>
          <Text style={styles.headerLink}>+ Add</Text>
        </Pressable>
      </View>

      {/* Children List */}
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        {children.length === 0 ? (
          <EmptyState
            icon="people-outline"
            title="No children yet"
            description="Add a child profile to personalize scripts and track progress"
            actionLabel="Add Child"
            onAction={handleOpenAdd}
          />
        ) : (
          children.map((child) => {
            const isDefault = defaultChildId === child.id;
            const neuro = NEUROTYPES.find((n) => n.value === child.neurotype);

            return (
              <Card key={child.id} style={styles.childCard}>
                <View style={styles.cardHeader}>
                  <View style={{ flex: 1 }}>
                    <View style={styles.nameRow}>
                      <Text style={styles.childName}>{child.name}</Text>
                      {isDefault && <Text style={styles.defaultBadge}>Default</Text>}
                    </View>
                    <Text style={styles.childAge}>{calculateAge(child.birth_date)}</Text>
                    {neuro && (
                      <Text style={styles.childNeurotype}>{neuro.label}</Text>
                    )}
                  </View>

                  <View style={styles.cardActions}>
                    <Pressable
                      onPress={() => handleOpenEdit(child)}
                      hitSlop={12}
                      style={styles.actionBtn}
                    >
                      <Text style={styles.actionText}>Edit</Text>
                    </Pressable>
                    <Pressable
                      onPress={() => handleDelete(child.id, child.name)}
                      disabled={deleting}
                      hitSlop={12}
                      style={styles.actionBtn}
                    >
                      <Text style={[styles.actionText, styles.actionTextDelete]}>
                        Delete
                      </Text>
                    </Pressable>
                  </View>
                </View>

                {!isDefault && (
                  <Pressable
                    onPress={() => handleSetDefault(child.id)}
                    style={styles.setDefaultBtn}
                  >
                    <Text style={styles.setDefaultText}>Set as default</Text>
                  </Pressable>
                )}
              </Card>
            );
          })
        )}
      </ScrollView>

      {/* Add/Edit Modal */}
      <Modal
        visible={modalMode !== null}
        animationType="slide"
        transparent
        onRequestClose={handleCloseModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {modalMode === "add" ? "Add Child" : "Edit Child"}
              </Text>
              <Pressable onPress={handleCloseModal} hitSlop={12}>
                <Text style={styles.modalClose}>✕</Text>
              </Pressable>
            </View>

            <View style={styles.form}>
              <View style={styles.formGroup}>
                <Text style={styles.label}>Name</Text>
                <TextInput
                  style={styles.input}
                  value={formData.name}
                  onChangeText={(text) => setFormData({ ...formData, name: text })}
                  placeholder="Child's name"
                  placeholderTextColor="rgba(255,255,255,0.4)"
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.label}>Birth Date (optional)</Text>
                <TextInput
                  style={styles.input}
                  value={formData.birthDate}
                  onChangeText={(text) => setFormData({ ...formData, birthDate: text })}
                  placeholder="YYYY-MM-DD"
                  placeholderTextColor="rgba(255,255,255,0.4)"
                />
                <Text style={styles.hint}>Format: YYYY-MM-DD (e.g., 2020-03-15)</Text>
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.label}>Neurotype</Text>
                <Pressable
                  onPress={() => setNeurotypeOpen(!neurotypeOpen)}
                  style={styles.dropdown}
                >
                  <Text style={styles.dropdownValue}>
                    {NEUROTYPES.find((n) => n.value === formData.neurotype)?.label ||
                      "Select"}
                  </Text>
                  <Text style={styles.dropdownChevron}>
                    {neurotypeOpen ? "▲" : "▼"}
                  </Text>
                </Pressable>

                {neurotypeOpen && (
                  <View style={styles.dropdownMenu}>
                    {NEUROTYPES.map((neuro) => {
                      const active = formData.neurotype === neuro.value;
                      return (
                        <Pressable
                          key={neuro.value}
                          onPress={() => {
                            setFormData({ ...formData, neurotype: neuro.value });
                            setNeurotypeOpen(false);
                          }}
                          style={[
                            styles.dropdownItem,
                            active && styles.dropdownItemActive,
                          ]}
                        >
                          <Text
                            style={[
                              styles.dropdownItemText,
                              active && styles.dropdownItemTextActive,
                            ]}
                          >
                            {neuro.label}
                          </Text>
                        </Pressable>
                      );
                    })}
                  </View>
                )}
              </View>
            </View>

            <View style={styles.modalFooter}>
              <Button
                title="Cancel"
                variant="outline"
                onPress={handleCloseModal}
                style={{ flex: 1 }}
              />
              <Button
                title={modalMode === "add" ? "Add" : "Save"}
                onPress={handleSubmit}
                loading={adding || updating}
                style={{ flex: 1, marginLeft: 12 }}
              />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#0B0F19",
  },
  ambience: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: 200,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: dimensions.padding.md,
    paddingTop: responsiveSpacing(10),
    paddingBottom: responsiveSpacing(10),
  },
  headerTitle: {
    color: "white",
    fontSize: dimensions.fontSize.md,
    fontWeight: "900",
  },
  headerSub: {
    color: "rgba(255,255,255,0.65)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "600",
    marginTop: 2,
  },
  headerLink: {
    color: GOLD,
    fontWeight: "800",
    fontSize: dimensions.fontSize.sm,
  },

  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: dimensions.padding.md,
    paddingBottom: dimensions.padding.md,
  },

  childCard: {
    padding: dimensions.padding.md,
    marginBottom: dimensions.margin.sm,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  nameRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: responsiveSpacing(8),
    marginBottom: 4,
  },
  childName: {
    color: "white",
    fontSize: dimensions.fontSize.md,
    fontWeight: "900",
  },
  defaultBadge: {
    color: GOLD,
    fontSize: responsiveFontSize(10),
    fontWeight: "900",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    paddingHorizontal: responsiveSpacing(8),
    paddingVertical: responsiveSpacing(4),
    borderRadius: dimensions.borderRadius.sm,
    backgroundColor: "rgba(212,175,55,0.14)",
    borderWidth: 1,
    borderColor: "rgba(212,175,55,0.22)",
  },
  childAge: {
    color: "rgba(255,255,255,0.65)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
    marginBottom: 2,
  },
  childNeurotype: {
    color: "rgba(255,255,255,0.5)",
    fontSize: responsiveFontSize(12),
    fontWeight: "600",
  },

  cardActions: {
    flexDirection: "row",
    gap: responsiveSpacing(12),
  },
  actionBtn: {
    padding: 4,
  },
  actionText: {
    color: "rgba(255,255,255,0.75)",
    fontSize: responsiveFontSize(13),
    fontWeight: "700",
  },
  actionTextDelete: {
    color: "rgba(255,100,100,0.85)",
  },

  setDefaultBtn: {
    marginTop: responsiveSpacing(12),
    paddingVertical: responsiveSpacing(10),
    paddingHorizontal: responsiveSpacing(14),
    borderRadius: dimensions.borderRadius.md,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.12)",
    alignSelf: "flex-start",
  },
  setDefaultText: {
    color: "rgba(255,255,255,0.75)",
    fontSize: responsiveFontSize(12),
    fontWeight: "700",
  },

  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.85)",
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: "#1a1f2e",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: dimensions.padding.md,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.1)",
  },
  modalTitle: {
    color: "white",
    fontSize: dimensions.fontSize.lg,
    fontWeight: "900",
  },
  modalClose: {
    color: "rgba(255,255,255,0.6)",
    fontSize: dimensions.fontSize.lg,
    fontWeight: "700",
  },

  form: {
    padding: dimensions.padding.md,
  },
  formGroup: {
    marginBottom: dimensions.margin.md,
  },
  label: {
    color: "rgba(255,255,255,0.8)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "800",
    marginBottom: responsiveSpacing(8),
  },
  input: {
    backgroundColor: "rgba(255,255,255,0.08)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    borderRadius: dimensions.borderRadius.md,
    paddingHorizontal: dimensions.padding.sm,
    paddingVertical: dimensions.padding.sm,
    color: "white",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
  },
  hint: {
    color: "rgba(255,255,255,0.45)",
    fontSize: responsiveFontSize(11),
    fontWeight: "600",
    marginTop: responsiveSpacing(6),
  },

  dropdown: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "rgba(255,255,255,0.08)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    borderRadius: dimensions.borderRadius.md,
    paddingHorizontal: dimensions.padding.sm,
    paddingVertical: dimensions.padding.sm,
  },
  dropdownValue: {
    color: "white",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "800",
  },
  dropdownChevron: {
    color: "rgba(255,255,255,0.7)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "900",
  },
  dropdownMenu: {
    marginTop: responsiveSpacing(10),
    borderRadius: dimensions.borderRadius.md,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
    backgroundColor: "rgba(20,24,36,0.92)",
  },
  dropdownItem: {
    paddingHorizontal: dimensions.padding.sm,
    paddingVertical: dimensions.padding.sm,
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.08)",
  },
  dropdownItemActive: {
    backgroundColor: "rgba(212,175,55,0.14)",
  },
  dropdownItemText: {
    color: "rgba(255,255,255,0.78)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "800",
  },
  dropdownItemTextActive: {
    color: GOLD,
  },

  modalFooter: {
    flexDirection: "row",
    paddingHorizontal: dimensions.padding.md,
    gap: responsiveSpacing(12),
  },
});
