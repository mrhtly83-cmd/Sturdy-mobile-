import React, { useState, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  RefreshControl,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";

import { Card } from "../../components/shared/Card";
import { LoadingSpinner } from "../../components/shared/LoadingSpinner";
import { EmptyState } from "../../components/shared/EmptyState";
import { useScripts, useToggleFavorite, useDeleteScript } from "../../hooks/useScripts";
import { useChildren } from "../../hooks/useChildren";
import { dimensions, responsiveFontSize, responsiveSpacing } from "../../theme/dimensions";

const GOLD = "#D4AF37";

type FilterType = "all" | "favorites" | "child";

export default function LibraryScreen() {
  const [filter, setFilter] = useState<FilterType>("all");
  const [selectedChildId, setSelectedChildId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const { scripts, loading, refresh } = useScripts();
  const { children } = useChildren();
  const { toggleFavorite, loading: toggling } = useToggleFavorite();
  const { deleteScript, loading: deleting } = useDeleteScript();

  const filteredScripts = useMemo(() => {
    let result = scripts;

    if (filter === "favorites") {
      result = result.filter((s) => s.is_favorite);
    } else if (filter === "child" && selectedChildId) {
      result = result.filter((s) => s.child_id === selectedChildId);
    }

    return result.sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }, [scripts, filter, selectedChildId]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
  };

  const handleToggleFavorite = async (scriptId: string, isFavorite: boolean) => {
    try {
      await toggleFavorite(scriptId, isFavorite);
      await refresh();
    } catch (error: any) {
      Alert.alert("Error", error.message || "Failed to update favorite status");
    }
  };

  const handleDeleteScript = async (scriptId: string) => {
    Alert.alert(
      "Delete Script",
      "Are you sure? This can't be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteScript(scriptId);
              await refresh();
            } catch (error: any) {
              Alert.alert("Error", error.message || "Failed to delete script");
            }
          },
        },
      ]
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days < 7) return `${days} days ago`;

    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  if (loading && scripts.length === 0) {
    return (
      <SafeAreaView style={styles.screen}>
        <LoadingSpinner />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
      <LinearGradient
        colors={["rgba(0,0,0,0.85)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.95)"]}
        style={styles.ambience}
      />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Script Library</Text>
          <Text style={styles.headerSub}>
            {filteredScripts.length} {filteredScripts.length === 1 ? "script" : "scripts"}
          </Text>
        </View>
        <Pressable onPress={() => router.push("/(tabs)/crisis")} hitSlop={12}>
          <Text style={styles.headerLink}>+ New</Text>
        </Pressable>
      </View>

      {/* Filters */}
      <View style={styles.filters}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <Pressable
            onPress={() => setFilter("all")}
            style={[styles.filterBtn, filter === "all" && styles.filterBtnActive]}
          >
            <Text
              style={[
                styles.filterBtnText,
                filter === "all" && styles.filterBtnTextActive,
              ]}
            >
              All
            </Text>
          </Pressable>

          <Pressable
            onPress={() => setFilter("favorites")}
            style={[styles.filterBtn, filter === "favorites" && styles.filterBtnActive]}
          >
            <Text
              style={[
                styles.filterBtnText,
                filter === "favorites" && styles.filterBtnTextActive,
              ]}
            >
              ⭐ Favorites
            </Text>
          </Pressable>

          {children.map((child) => (
            <Pressable
              key={child.id}
              onPress={() => {
                setFilter("child");
                setSelectedChildId(child.id);
              }}
              style={[
                styles.filterBtn,
                filter === "child" && selectedChildId === child.id && styles.filterBtnActive,
              ]}
            >
              <Text
                style={[
                  styles.filterBtnText,
                  filter === "child" &&
                    selectedChildId === child.id &&
                    styles.filterBtnTextActive,
                ]}
              >
                {child.name}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      {/* Scripts List */}
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor="white"
          />
        }
      >
        {filteredScripts.length === 0 ? (
          <EmptyState
            icon="document-text-outline"
            title="No scripts yet"
            description={
              filter === "favorites"
                ? "Tap the star on scripts to mark them as favorites"
                : "Generate your first script in Crisis Mode"
            }
            actionLabel={filter === "favorites" ? undefined : "Create Script"}
            onAction={() => router.push("/(tabs)/crisis")}
          />
        ) : (
          filteredScripts.map((script) => {
            const child = children.find((c) => c.id === script.child_id);

            return (
              <Pressable
                key={script.id}
                onPress={() => router.push(`/script/${script.id}`)}
                style={({ pressed }) => [
                  styles.scriptCard,
                  pressed && { opacity: 0.7 },
                ]}
              >
                <Card style={styles.cardInner}>
                  <View style={styles.cardHeader}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.cardDate}>{formatDate(script.created_at)}</Text>
                      {child && <Text style={styles.cardChild}>{child.name}</Text>}
                    </View>
                    <View style={styles.cardActions}>
                      <Pressable
                        onPress={() => handleToggleFavorite(script.id, script.is_favorite)}
                        disabled={toggling}
                        hitSlop={12}
                        style={styles.actionBtn}
                      >
                        <Text style={styles.actionIcon}>
                          {script.is_favorite ? "⭐" : "☆"}
                        </Text>
                      </Pressable>
                      <Pressable
                        onPress={() => handleDeleteScript(script.id)}
                        disabled={deleting}
                        hitSlop={12}
                        style={styles.actionBtn}
                      >
                        <Text style={styles.actionIcon}>🗑️</Text>
                      </Pressable>
                    </View>
                  </View>

                  <Text style={styles.cardSituation} numberOfLines={2}>
                    {script.situation}
                  </Text>

                  <Text style={styles.cardPreview} numberOfLines={3}>
                    {script.script_text}
                  </Text>

                  <View style={styles.cardFooter}>
                    <Text style={styles.cardCategory}>{script.category}</Text>
                    <Text style={styles.cardArrow}>→</Text>
                  </View>
                </Card>
              </Pressable>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#0B0F19",
  },
  ambience: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: 200,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: dimensions.padding.md,
    paddingTop: responsiveSpacing(10),
    paddingBottom: responsiveSpacing(10),
  },
  headerTitle: {
    color: "white",
    fontSize: dimensions.fontSize.md,
    fontWeight: "900",
  },
  headerSub: {
    color: "rgba(255,255,255,0.65)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "600",
    marginTop: 2,
  },
  headerLink: {
    color: GOLD,
    fontWeight: "800",
    fontSize: dimensions.fontSize.sm,
  },

  filters: {
    paddingHorizontal: dimensions.padding.md,
    paddingBottom: responsiveSpacing(12),
  },
  filterBtn: {
    paddingHorizontal: responsiveSpacing(16),
    paddingVertical: responsiveSpacing(10),
    borderRadius: dimensions.borderRadius.full,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.12)",
    marginRight: responsiveSpacing(8),
  },
  filterBtnActive: {
    backgroundColor: "rgba(212,175,55,0.14)",
    borderColor: "rgba(212,175,55,0.3)",
  },
  filterBtnText: {
    color: "rgba(255,255,255,0.75)",
    fontWeight: "700",
    fontSize: responsiveFontSize(13),
  },
  filterBtnTextActive: {
    color: GOLD,
  },

  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: dimensions.padding.md,
    paddingBottom: dimensions.padding.md,
  },

  scriptCard: {
    marginBottom: dimensions.margin.sm,
  },
  cardInner: {
    padding: dimensions.padding.md,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginBottom: responsiveSpacing(8),
  },
  cardDate: {
    color: "rgba(255,255,255,0.5)",
    fontSize: responsiveFontSize(11),
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  cardChild: {
    color: GOLD,
    fontSize: responsiveFontSize(12),
    fontWeight: "800",
    marginTop: 4,
  },
  cardActions: {
    flexDirection: "row",
    gap: responsiveSpacing(8),
  },
  actionBtn: {
    padding: 4,
  },
  actionIcon: {
    fontSize: responsiveFontSize(18),
  },

  cardSituation: {
    color: "white",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "800",
    marginBottom: responsiveSpacing(8),
    lineHeight: 20,
  },
  cardPreview: {
    color: "rgba(255,255,255,0.65)",
    fontSize: dimensions.fontSize.xs,
    fontWeight: "600",
    lineHeight: 18,
    marginBottom: responsiveSpacing(10),
  },
  cardFooter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: responsiveSpacing(10),
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.08)",
  },
  cardCategory: {
    color: "rgba(255,255,255,0.5)",
    fontSize: responsiveFontSize(11),
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  cardArrow: {
    color: "rgba(255,255,255,0.4)",
    fontSize: dimensions.fontSize.md,
    fontWeight: "700",
  },
});
