import { Pressable, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";

export default function Home() {
  return (
    <View style={styles.screen}>
      {/* Top ambiance (subtle hero) */}
      <LinearGradient
        colors={["rgba(0,0,0,0.85)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.95)"]}
        style={styles.ambience}
      />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.brand}>Sturdy</Text>
        <Pressable onPress={() => router.push("/(tabs)/settings")}>
          <Text style={styles.headerLink}>Settings</Text>
        </Pressable>
      </View>

      {/* Hero copy */}
      <View style={styles.hero}>
        <Text style={styles.kicker}>Calm + confidence in 3 taps</Text>
        <Text style={styles.headline}>
          Your words matter.
          {"\n"}
          <Text style={styles.gold}>Let’s choose them well.</Text>
        </Text>
        <Text style={styles.subhead}>
          Quick scripts for hard moments — and a record you’ll be proud of later.
        </Text>
      </View>

      {/* Primary actions */}
      <View style={styles.actions}>
        <Pressable
          onPress={() => router.push("/(tabs)/crisis")}
          style={({ pressed }) => [
            styles.primaryBtn,
            pressed && { transform: [{ scale: 0.99 }], opacity: 0.95 },
          ]}
        >
          <Text style={styles.primaryBtnText}>Crisis Mode</Text>
          <Text style={styles.primaryBtnSub}>Get an instant script</Text>
        </Pressable>

        <Pressable
          onPress={() => router.push("/(tabs)")}
          style={({ pressed }) => [
            styles.secondaryBtn,
            pressed && { transform: [{ scale: 0.99 }], opacity: 0.95 },
          ]}
        >
          <Text style={styles.secondaryBtnText}>Guidance Mode</Text>
          <Text style={styles.secondaryBtnSub}>Shape patterns over time</Text>
        </Pressable>
      </View>

      {/* Progress preview */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Your Progress</Text>

        <View style={styles.glassCard}>
          <View style={styles.row}>
            <Text style={styles.cardTitle}>Moments Calendar</Text>
            <Text style={styles.pill}>PREMIUM</Text>
          </View>
          <Text style={styles.cardBody}>
            Save situations, scripts, and wins — then look back and feel proud.
          </Text>

          <View style={styles.miniGrid}>
            {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
              <View key={i} style={styles.day}>
                <Text style={styles.dayText}>{d}</Text>
                <View style={[styles.dot, i === 1 || i === 3 ? styles.dotOn : null]} />
              </View>
            ))}
          </View>

          <Pressable
            onPress={() => router.push("/(tabs)/settings")}
            style={styles.linkBtn}
          >
            <Text style={styles.linkBtnText}>See your moments</Text>
          </Pressable>
        </View>
      </View>

      {/* Bottom reassurance */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          You don’t need perfect. You need steady.
        </Text>
      </View>
    </View>
  );
}

const GOLD = "#D4AF37";

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#0B0F19",
    paddingHorizontal: 20,
    paddingTop: 56,
  },
  ambience: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: 260,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 18,
  },
  brand: {
    color: "white",
    fontSize: 20,
    fontWeight: "700",
    letterSpacing: 0.2,
  },
  headerLink: {
    color: "rgba(255,255,255,0.75)",
    fontWeight: "600",
  },
  hero: {
    marginBottom: 18,
  },
  kicker: {
    color: "rgba(255,255,255,0.75)",
    fontSize: 13,
    fontWeight: "600",
    marginBottom: 10,
  },
  headline: {
    color: "white",
    fontSize: 28,
    fontWeight: "800",
    lineHeight: 34,
    marginBottom: 10,
  },
  gold: {
    color: GOLD,
  },
  subhead: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 14,
    lineHeight: 20,
    maxWidth: 340,
  },

  actions: {
    gap: 12,
    marginTop: 10,
    marginBottom: 18,
  },
  primaryBtn: {
    backgroundColor: GOLD,
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 16,
  },
  primaryBtnText: {
    color: "#101318",
    fontSize: 16,
    fontWeight: "800",
  },
  primaryBtnSub: {
    marginTop: 4,
    color: "rgba(16,19,24,0.75)",
    fontSize: 13,
    fontWeight: "600",
  },

  secondaryBtn: {
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 16,
    backgroundColor: "rgba(255,255,255,0.08)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
  },
  secondaryBtnText: {
    color: "white",
    fontSize: 16,
    fontWeight: "800",
  },
  secondaryBtnSub: {
    marginTop: 4,
    color: "rgba(255,255,255,0.65)",
    fontSize: 13,
    fontWeight: "600",
  },

  section: {
    marginTop: 4,
  },
  sectionTitle: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 14,
    fontWeight: "800",
    marginBottom: 10,
  },
  glassCard: {
    backgroundColor: "rgba(255,255,255,0.08)",
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.14)",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  cardTitle: {
    color: "white",
    fontSize: 15,
    fontWeight: "800",
  },
  pill: {
    color: GOLD,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 0.8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "rgba(212,175,55,0.14)",
    borderWidth: 1,
    borderColor: "rgba(212,175,55,0.22)",
  },
  cardBody: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 14,
  },

  miniGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  day: {
    width: 34,
    height: 46,
    borderRadius: 12,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.10)",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  dayText: {
    color: "rgba(255,255,255,0.65)",
    fontSize: 11,
    fontWeight: "700",
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 999,
    backgroundColor: "rgba(255,255,255,0.18)",
  },
  dotOn: {
    backgroundColor: GOLD,
  },

  linkBtn: {
    marginTop: 6,
    alignSelf: "flex-start",
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 12,
    backgroundColor: "rgba(255,255,255,0.06)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.12)",
  },
  linkBtnText: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 12,
    fontWeight: "700",
  },

  footer: {
    marginTop: "auto",
    paddingVertical: 16,
    alignItems: "center",
  },
  footerText: {
    color: "rgba(255,255,255,0.45)",
    fontSize: 12,
    fontWeight: "600",
  },
});
