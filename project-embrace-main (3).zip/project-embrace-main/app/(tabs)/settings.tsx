import { Pressable, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { supabase } from "../../lib/supabase";
import { dimensions } from "../../theme/dimensions";

export default function Settings() {
  const onLogout = async () => {
    await supabase.auth.signOut();
    router.replace("/(auth)/sign-in");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <Pressable onPress={onLogout} style={styles.button}>
        <Text style={styles.buttonText}>Log out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: dimensions.padding.lg,
    justifyContent: "center",
    gap: dimensions.margin.sm,
  },
  title: {
    fontSize: dimensions.fontSize["2xl"],
    fontWeight: "700",
  },
  button: {
    paddingVertical: dimensions.padding.md,
    borderRadius: dimensions.borderRadius.md,
    alignItems: "center",
    backgroundColor: "#111827",
  },
  buttonText: {
    color: "white",
    fontSize: dimensions.fontSize.md,
    fontWeight: "600",
  },
});
