import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  Share,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";

import { Card } from "../../components/shared/Card";
import { Button } from "../../components/shared/Button";
import { LoadingSpinner } from "../../components/shared/LoadingSpinner";
import { useScript, useToggleFavorite, useDeleteScript } from "../../hooks/useScripts";
import { useChildren } from "../../hooks/useChildren";
import { dimensions, responsiveFontSize, responsiveSpacing } from "../../theme/dimensions";

const GOLD = "#D4AF37";

export default function ScriptDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { script, loading } = useScript(id!);
  const { children } = useChildren();
  const { toggleFavorite, loading: toggling } = useToggleFavorite();
  const { deleteScript, loading: deleting } = useDeleteScript();

  const child = children.find((c) => c.id === script?.child_id);

  const handleToggleFavorite = async () => {
    if (!script) return;
    try {
      await toggleFavorite(script.id, script.is_favorite);
    } catch (error: any) {
      Alert.alert("Error", error.message || "Failed to update favorite status");
    }
  };

  const handleShare = async () => {
    if (!script) return;

    try {
      await Share.share({
        message: `Situation: ${script.situation}\n\n${script.script_text}`,
        title: "Sturdy Script",
      });
    } catch (error: any) {
      Alert.alert("Error", "Failed to share");
    }
  };

  const handleDelete = () => {
    if (!script) return;

    Alert.alert(
      "Delete Script",
      "Are you sure? This can't be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteScript(script.id);
              router.back();
            } catch (error: any) {
              Alert.alert("Error", error.message || "Failed to delete script");
            }
          },
        },
      ]
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (loading || !script) {
    return (
      <SafeAreaView style={styles.screen}>
        <LoadingSpinner />
      </SafeAreaView>
    );
  }

  const scriptParts = script.script_text.split("\n\n");

  return (
    <SafeAreaView style={styles.screen} edges={["top", "left", "right"]}>
      <LinearGradient
        colors={["rgba(0,0,0,0.85)", "rgba(0,0,0,0.55)", "rgba(0,0,0,0.95)"]}
        style={styles.ambience}
      />

      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Text style={styles.headerLink}>← Back</Text>
        </Pressable>

        <View style={styles.headerActions}>
          <Pressable
            onPress={handleToggleFavorite}
            disabled={toggling}
            hitSlop={12}
            style={styles.headerBtn}
          >
            <Text style={styles.headerIcon}>{script.is_favorite ? "⭐" : "☆"}</Text>
          </Pressable>
          <Pressable onPress={handleShare} hitSlop={12} style={styles.headerBtn}>
            <Text style={styles.headerIcon}>↗️</Text>
          </Pressable>
          <Pressable
            onPress={handleDelete}
            disabled={deleting}
            hitSlop={12}
            style={styles.headerBtn}
          >
            <Text style={styles.headerIcon}>🗑️</Text>
          </Pressable>
        </View>
      </View>

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        {/* Metadata */}
        <View style={styles.metaSection}>
          <Text style={styles.metaDate}>{formatDate(script.created_at)}</Text>
          {child && (
            <View style={styles.metaBadge}>
              <Text style={styles.metaBadgeText}>{child.name}</Text>
            </View>
          )}
          <View style={styles.metaBadge}>
            <Text style={styles.metaBadgeText}>{script.category}</Text>
          </View>
        </View>

        {/* Situation */}
        <Card style={styles.situationCard}>
          <Text style={styles.situationLabel}>Situation</Text>
          <Text style={styles.situationText}>{script.situation}</Text>
        </Card>

        {/* Script Content */}
        <View style={styles.scriptSection}>
          <Text style={styles.scriptTitle}>Your Script</Text>
          {scriptParts.map((part, index) => {
            const lines = part.split("\n");
            const title = lines[0];
            const content = lines.slice(1).join("\n");

            return (
              <Card key={index} style={styles.scriptCard}>
                <View style={styles.partHeader}>
                  <View style={styles.partNumber}>
                    <Text style={styles.partNumberText}>
                      {title.includes("Mantra") ? "💫" : index + 1}
                    </Text>
                  </View>
                  <Text style={styles.partTitle}>{title}</Text>
                </View>
                <Text style={styles.partContent}>{content}</Text>
              </Card>
            );
          })}
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <Button
            title="Share Script"
            variant="outline"
            onPress={handleShare}
            style={{ flex: 1 }}
          />
          <Button
            title="New Script"
            onPress={() => router.push("/(tabs)/crisis")}
            style={{ flex: 1 }}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#0B0F19",
  },
  ambience: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    height: 200,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: dimensions.padding.md,
    paddingTop: responsiveSpacing(10),
    paddingBottom: responsiveSpacing(10),
  },
  headerLink: {
    color: "rgba(255,255,255,0.8)",
    fontWeight: "800",
    fontSize: dimensions.fontSize.sm,
  },
  headerActions: {
    flexDirection: "row",
    gap: responsiveSpacing(16),
  },
  headerBtn: {
    padding: 4,
  },
  headerIcon: {
    fontSize: responsiveFontSize(20),
  },

  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: dimensions.padding.md,
    paddingBottom: dimensions.padding.lg,
  },

  metaSection: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: responsiveSpacing(8),
    marginBottom: dimensions.margin.sm,
  },
  metaDate: {
    color: "rgba(255,255,255,0.5)",
    fontSize: responsiveFontSize(11),
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  metaBadge: {
    paddingHorizontal: responsiveSpacing(10),
    paddingVertical: responsiveSpacing(6),
    borderRadius: dimensions.borderRadius.full,
    backgroundColor: "rgba(212,175,55,0.14)",
    borderWidth: 1,
    borderColor: "rgba(212,175,55,0.22)",
  },
  metaBadgeText: {
    color: GOLD,
    fontSize: responsiveFontSize(11),
    fontWeight: "900",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },

  situationCard: {
    padding: dimensions.padding.md,
    marginBottom: dimensions.margin.md,
  },
  situationLabel: {
    color: "rgba(255,255,255,0.6)",
    fontSize: responsiveFontSize(11),
    fontWeight: "800",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: responsiveSpacing(8),
  },
  situationText: {
    color: "white",
    fontSize: dimensions.fontSize.md,
    fontWeight: "800",
    lineHeight: 24,
  },

  scriptSection: {
    marginBottom: dimensions.margin.md,
  },
  scriptTitle: {
    color: "white",
    fontSize: dimensions.fontSize.lg,
    fontWeight: "900",
    marginBottom: dimensions.margin.sm,
  },
  scriptCard: {
    padding: dimensions.padding.md,
    marginBottom: dimensions.margin.sm,
  },
  partHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: responsiveSpacing(12),
    paddingBottom: responsiveSpacing(12),
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.1)",
  },
  partNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "rgba(212,175,55,0.14)",
    borderWidth: 1,
    borderColor: "rgba(212,175,55,0.3)",
    alignItems: "center",
    justifyContent: "center",
    marginRight: responsiveSpacing(12),
  },
  partNumberText: {
    color: GOLD,
    fontSize: responsiveFontSize(14),
    fontWeight: "900",
  },
  partTitle: {
    flex: 1,
    color: "white",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "900",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  partContent: {
    color: "rgba(255,255,255,0.85)",
    fontSize: dimensions.fontSize.sm,
    fontWeight: "600",
    lineHeight: 22,
  },

  actions: {
    flexDirection: "row",
    gap: responsiveSpacing(12),
    marginTop: dimensions.margin.sm,
  },
});
