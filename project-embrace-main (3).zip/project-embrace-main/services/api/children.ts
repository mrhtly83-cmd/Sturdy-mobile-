import { supabase } from '../../lib/supabase';
import { Child } from '../../lib/types';

/**
 * Fetch all children for the current user
 */
export async function fetchChildren(): Promise<Child[]> {
  try {
    const { data, error } = await supabase
      .from('children')
      .select('*')
      .order('created_at', { ascending: true });

    if (error) throw error;

    return data || [];
  } catch (error: any) {
    console.error('Fetch children error:', error);
    throw error;
  }
}

/**
 * Add a new child profile
 */
export async function addChild(data: {
  name: string;
  birthDate: string;
  neurotype: string;
}): Promise<Child> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      throw new Error('You must be logged in to add a child');
    }

    // Ensure user profile exists
    await supabase
      .from('profiles')
      .upsert({ id: user.id }, { onConflict: 'id' });

    const { data: newChild, error } = await supabase
      .from('children')
      .insert([
        {
          name: data.name,
          birth_date: data.birthDate || null,
          neurotype: data.neurotype,
          parent_id: user.id,
        },
      ])
      .select()
      .single();

    if (error) throw error;

    return newChild;
  } catch (error: any) {
    console.error('Add child error:', error);
    throw error;
  }
}

/**
 * Update a child profile
 */
export async function updateChild(data: {
  id: string;
  name: string;
  birthDate: string;
  neurotype: string;
}): Promise<void> {
  try {
    const { error } = await supabase
      .from('children')
      .update({
        name: data.name,
        birth_date: data.birthDate || null,
        neurotype: data.neurotype,
      })
      .eq('id', data.id);

    if (error) throw error;
  } catch (error: any) {
    console.error('Update child error:', error);
    throw error;
  }
}

/**
 * Delete a child profile
 */
export async function deleteChild(childId: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('children')
      .delete()
      .eq('id', childId);

    if (error) throw error;
  } catch (error: any) {
    console.error('Delete child error:', error);
    throw error;
  }
}

/**
 * Get a single child by ID
 */
export async function getChild(childId: string): Promise<Child | null> {
  try {
    const { data, error } = await supabase
      .from('children')
      .select('*')
      .eq('id', childId)
      .single();

    if (error && error.code !== 'PGRST116') {
      // PGRST116 = no rows returned
      throw error;
    }

    return data;
  } catch (error: any) {
    console.error('Get child error:', error);
    throw error;
  }
}
