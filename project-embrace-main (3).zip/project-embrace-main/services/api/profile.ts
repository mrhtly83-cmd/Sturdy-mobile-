import { supabase } from '../../lib/supabase';
import { Profile } from '../../lib/types';

/**
 * Fetch user profile
 */
export async function fetchProfile(): Promise<Profile | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) return null;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (error && error.code !== 'PGRST116') {
      // PGRST116 = no rows returned (new user)
      throw error;
    }

    return data;
  } catch (error: any) {
    console.error('Fetch profile error:', error);
    throw error;
  }
}

/**
 * Update user profile
 */
export async function updateProfile(data: Partial<Profile>): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      throw new Error('You must be logged in to update profile');
    }

    const { error } = await supabase
      .from('profiles')
      .upsert(
        {
          id: user.id,
          ...data,
        },
        { onConflict: 'id' }
      );

    if (error) throw error;
  } catch (error: any) {
    console.error('Update profile error:', error);
    throw error;
  }
}

/**
 * Get default child ID
 */
export async function getDefaultChildId(): Promise<string | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) return null;

    const { data, error } = await supabase
      .from('profiles')
      .select('default_child_id')
      .eq('id', user.id)
      .single();

    if (error && error.code !== 'PGRST116') {
      throw error;
    }

    return data?.default_child_id || null;
  } catch (error: any) {
    console.error('Get default child error:', error);
    throw error;
  }
}

/**
 * Set default child
 */
export async function setDefaultChildId(childId: string | null): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      throw new Error('You must be logged in to set default child');
    }

    const { error } = await supabase
      .from('profiles')
      .update({ default_child_id: childId })
      .eq('id', user.id);

    if (error) throw error;
  } catch (error: any) {
    console.error('Set default child error:', error);
    throw error;
  }
}
