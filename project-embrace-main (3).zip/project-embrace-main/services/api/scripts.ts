import { supabase } from "../../lib/supabase";
import { ConsciousDisciplineResponse, CrisisFormRequest } from "../../lib/types";

/**
 * Generate a crisis script using Supabase Edge Function: generate-crisis-script
 * Maps the Edge Function response into the existing mobile UI shape (ConsciousDisciplineResponse)
 */
export async function generateScript(
  request: CrisisFormRequest
): Promise<ConsciousDisciplineResponse> {
  try {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    // NOTE: Your edge function currently requires auth (401 if not logged in)
    if (!session) {
      throw new Error("You must be logged in to generate scripts.");
    }

    const { data, error } = await supabase.functions.invoke(
      "generate-crisis-script",
      {
        body: {
          situation: request.situation,
          childAge: request.childAge,
          neurotype: request.neurotype,
        },
        // In most setups, invoke already includes auth, but keeping this is fine and explicit.
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      }
    );

    if (error) {
      console.error("Edge function error:", error);
      throw new Error(error.message || "Failed to generate crisis script");
    }

    if (!data) {
      throw new Error("No data returned from crisis script generation");
    }

    const mapped: ConsciousDisciplineResponse = {
      frameworkUsed: "Sturdy Crisis",
      toneUsed: "calm + firm",
      part1: { title: "Regulate", script: data.script?.regulate ?? "" },
      part2: { title: "Connect", script: data.script?.connect ?? "" },
      part3: { title: "Guide", script: data.script?.guide ?? "" },
      parentMantra: data.script?.identity ?? "",
      deliveryTip: Array.isArray(data.deliveryTips)
        ? data.deliveryTips.join(" • ")
        : "",
      whyThisWorks: data.whyItWorks ?? null,
      proactiveFollowUp: data.proactiveFollowUp ?? null,
      frameworkReasoning: null,
    };

    return mapped;
  } catch (err: any) {
    console.error("Generate script error:", err);
    throw err;
  }
}

/**
 * Save a script to the database.
 * Phase 1 enhancement:
 * - store mode/neurotype/child_age/script_json (new columns you added)
 * - return inserted script id so UI can later attach a user_rating outcome
 */
export async function saveScriptToDatabase(data: {
  situation: string;
  scriptText: string;
  childId?: string;

  // new metadata (all optional to preserve backward compatibility)
  mode?: "crisis" | "guidance";
  childAge?: string;
  neurotype?: string;
  scriptJson?: any;
}): Promise<string> {
  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) throw new Error("You must be logged in to save a script.");

    const payload: Record<string, any> = {
      parent_id: user.id,
      child_id: data.childId || null,
      situation: data.situation,
      script_text: data.scriptText,

      // existing column in your table
      is_favorite: false,

      // new columns (Phase 1)
      mode: data.mode ?? "crisis",
      child_age: data.childAge ?? null,
      neurotype: data.neurotype ?? null,
      script_json: data.scriptJson ?? null,
    };

    const { data: inserted, error: insertError } = await supabase
      .from("scripts")
      .insert([payload])
      .select("id")
      .single();

    if (insertError) throw insertError;
    if (!inserted?.id) throw new Error("Saved, but no script id returned.");

    return inserted.id as string;
  } catch (err: any) {
    console.error("Save script error:", err);
    throw err;
  }
}

/**
 * Update the user's rating for a saved script.
 * Uses existing `user_rating` column:
 *   3 = Better than usual
 *   2 = About the same
 *   1 = Still hard
 */
export async function updateScriptRating(params: {
  scriptId: string;
  userRating: 1 | 2 | 3;
}): Promise<void> {
  try {
    const { error } = await supabase
      .from("scripts")
      .update({ user_rating: params.userRating })
      .eq("id", params.scriptId);

    if (error) throw error;
  } catch (err: any) {
    console.error("Update script rating error:", err);
    throw err;
  }
}
