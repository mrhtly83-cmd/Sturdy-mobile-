import React from 'react';
import {
  TextInput,
  View,
  Text,
  StyleSheet,
  TextInputProps,
  ViewStyle,
} from 'react-native';
import { colors } from '../../theme/colors';
import { typography, textStyles } from '../../theme/typography';
import { spacing } from '../../theme/spacing';

interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  containerStyle?: ViewStyle;
}

export function Input({
  label,
  error,
  containerStyle,
  style,
  ...props
}: InputProps) {
  return (
    <View style={[styles.container, containerStyle]}>
      {label && <Text style={styles.label}>{label}</Text>}
      <TextInput
        style={[
          styles.input,
          error && styles.input_error,
          props.multiline && styles.input_multiline,
          style,
        ]}
        placeholderTextColor={colors.foregroundLight}
        {...props}
      />
      {error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: spacing.md,
  },
  label: {
    ...textStyles.label,
    color: colors.foreground,
    marginBottom: spacing.xs,
  },
  input: {
    height: spacing.inputHeight.md,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: spacing.borderRadius.md,
    paddingHorizontal: spacing.md,
    fontSize: typography.fontSize.base,
    color: colors.foreground,
  },
  input_multiline: {
    height: 120,
    paddingTop: spacing.md,
    textAlignVertical: 'top',
  },
  input_error: {
    borderColor: colors.destructive,
  },
  error: {
    ...textStyles.caption,
    color: colors.destructive,
    marginTop: spacing.xs,
  },
});
