import React, { ReactNode } from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { colors } from '../../theme/colors';
import { spacing } from '../../theme/spacing';

interface CardProps {
  children: ReactNode;
  style?: ViewStyle;
  padding?: number;
  elevation?: 'sm' | 'md' | 'lg';
}

export function Card({ children, style, padding, elevation = 'md' }: CardProps) {
  const cardStyles = [
    styles.card,
    spacing.shadow[elevation],
    padding !== undefined && { padding },
    style,
  ];

  return <View style={cardStyles}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: spacing.borderRadius.lg,
    padding: spacing.cardPadding,
    borderWidth: 1,
    borderColor: colors.border,
  },
});
