import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../theme/colors';
import { textStyles } from '../../theme/typography';
import { spacing } from '../../theme/spacing';
import { Input } from '../shared/Input';
import { Button } from '../shared/Button';
import { Child } from '../../lib/types';

interface ChildAgeSelectorProps {
  childrenList?: Child[];
  selectedChildId: string | null;
  customAge: string;
  onSelectChild: (childId: string) => void;
  onCustomAgeChange: (age: string) => void;
}

export function ChildAgeSelector({
  childrenList = [],
  selectedChildId,
  customAge,
  onSelectChild,
  onCustomAgeChange,
}: ChildAgeSelectorProps) {
  const [showCustomAge, setShowCustomAge] = useState(false);

  const calculateAge = (birthDate: string): string => {
    const birth = new Date(birthDate);
    const today = new Date();
    const years = today.getFullYear() - birth.getFullYear();
    const months = today.getMonth() - birth.getMonth();

    if (years === 0) {
      return `${months} months`;
    } else if (years < 2) {
      return `${years} year, ${months} months`;
    } else {
      return `${years} years`;
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Who is this for?</Text>
      <Text style={styles.subtitle}>
        Select a child or enter an age
      </Text>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Saved Children */}
        {childrenList.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Your Children</Text>
            {childrenList.map((child) => {
              const isSelected = selectedChildId === child.id;
              return (
                <TouchableOpacity
                  key={child.id}
                  style={[
                    styles.childCard,
                    isSelected && styles.childCard_selected,
                  ]}
                  onPress={() => onSelectChild(child.id)}
                  activeOpacity={0.7}
                >
                  <View style={styles.childInfo}>
                    <View
                      style={[
                        styles.avatar,
                        isSelected && styles.avatar_selected,
                      ]}
                    >
                      <Text style={styles.avatarText}>
                        {child.name.charAt(0).toUpperCase()}
                      </Text>
                    </View>
                    <View style={styles.childDetails}>
                      <Text
                        style={[
                          styles.childName,
                          isSelected && { color: colors.white },
                        ]}
                      >
                        {child.name}
                      </Text>
                      <Text
                        style={[
                          styles.childAge,
                          isSelected && { color: colors.white },
                        ]}
                      >
                        {child.birth_date
                          ? calculateAge(child.birth_date)
                          : child.neurotype}
                      </Text>
                    </View>
                  </View>
                  {isSelected && (
                    <Ionicons
                      name="checkmark-circle"
                      size={24}
                      color={colors.white}
                    />
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {/* Custom Age Input */}
        <View style={styles.section}>
          {!showCustomAge ? (
            <Button
              title="Enter Age Manually"
              onPress={() => {
                setShowCustomAge(true);
                onSelectChild('');
              }}
              variant="outline"
            />
          ) : (
            <View>
              <Text style={styles.sectionTitle}>Child&apos;s Age</Text>
              <Input
                placeholder="e.g., 4 years, 18 months"
                value={customAge}
                onChangeText={onCustomAgeChange}
                autoFocus
              />
              <Button
                title="Use Saved Child Instead"
                onPress={() => {
                  setShowCustomAge(false);
                  onCustomAgeChange('');
                }}
                variant="ghost"
              />
            </View>
          )}
        </View>

        {/* Helpful Note */}
        <View style={styles.noteContainer}>
          <Ionicons
            name="information-circle-outline"
            size={20}
            color={colors.info}
          />
          <Text style={styles.noteText}>
            Scripts are tailored based on your child&apos;s age and developmental
            stage
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    ...textStyles.h2,
    color: colors.foreground,
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
    marginBottom: spacing.lg,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingBottom: spacing.xl,
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    ...textStyles.label,
    color: colors.foreground,
    marginBottom: spacing.md,
  },
  childCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    borderRadius: spacing.borderRadius.lg,
    borderWidth: 2,
    borderColor: colors.border,
    padding: spacing.md,
    marginBottom: spacing.md,
    ...spacing.shadow.sm,
  },
  childCard_selected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  childInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: spacing.borderRadius.full,
    backgroundColor: colors.muted,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  avatar_selected: {
    backgroundColor: colors.primaryDark,
  },
  avatarText: {
    ...textStyles.h3,
    color: colors.primary,
  },
  childDetails: {
    flex: 1,
  },
  childName: {
    ...textStyles.h4,
    color: colors.foreground,
    marginBottom: spacing.xs,
  },
  childAge: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
  },
  noteContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.infoLight,
    borderRadius: spacing.borderRadius.md,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  noteText: {
    ...textStyles.bodySmall,
    color: colors.info,
    marginLeft: spacing.sm,
    flex: 1,
  },
});
