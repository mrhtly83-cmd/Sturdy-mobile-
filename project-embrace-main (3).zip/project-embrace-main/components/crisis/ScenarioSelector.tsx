import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../theme/colors';
import { textStyles } from '../../theme/typography';
import { spacing } from '../../theme/spacing';
import { SCENARIOS } from '../../config/scenarios';

interface ScenarioSelectorProps {
  selectedScenario: string | null;
  onSelectScenario: (scenarioId: string) => void;
}

export function ScenarioSelector({
  selectedScenario,
  onSelectScenario,
}: ScenarioSelectorProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>What&apos;s happening?</Text>
      <Text style={styles.subtitle}>
        Select the situation you&apos;re dealing with right now
      </Text>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.grid}
        showsVerticalScrollIndicator={false}
      >
        {SCENARIOS.map((scenario) => {
          const isSelected = selectedScenario === scenario.id;
          return (
            <TouchableOpacity
              key={scenario.id}
              style={[
                styles.card,
                isSelected && {
                  backgroundColor: scenario.color,
                  borderColor: scenario.color,
                },
              ]}
              onPress={() => onSelectScenario(scenario.id)}
              activeOpacity={0.7}
            >
              <View style={styles.iconContainer}>
                <Ionicons
                  name={scenario.icon as any}
                  size={spacing.iconSize.lg}
                  color={isSelected ? colors.white : scenario.color}
                />
              </View>
              <Text
                style={[
                  styles.label,
                  isSelected && { color: colors.white },
                ]}
              >
                {scenario.label}
              </Text>
              {isSelected && (
                <View style={styles.checkmark}>
                  <Ionicons
                    name="checkmark-circle"
                    size={20}
                    color={colors.white}
                  />
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    ...textStyles.h2,
    color: colors.foreground,
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
    marginBottom: spacing.lg,
  },
  scrollView: {
    flex: 1,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingBottom: spacing.xl,
  },
  card: {
    width: '48%',
    aspectRatio: 1,
    backgroundColor: colors.card,
    borderRadius: spacing.borderRadius.lg,
    borderWidth: 2,
    borderColor: colors.border,
    padding: spacing.md,
    marginBottom: spacing.md,
    justifyContent: 'center',
    alignItems: 'center',
    ...spacing.shadow.md,
  },
  iconContainer: {
    marginBottom: spacing.sm,
  },
  label: {
    ...textStyles.label,
    color: colors.foreground,
    textAlign: 'center',
  },
  checkmark: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
  },
});
