import React, { useMemo, useState } from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../../theme/colors";
import { textStyles } from "../../theme/typography";
import { spacing } from "../../theme/spacing";
import { Button } from "../shared/Button";
import { Card } from "../shared/Card";
import { ConsciousDisciplineResponse } from "../../lib/types";
import { updateScriptRating } from "../../services/api/scripts";

interface ScriptDisplayProps {
  script: ConsciousDisciplineResponse;
  isSaving: boolean;
  onSave: () => void;
  onStartOver: () => void;
  isPremium: boolean;

  // NEW: once saved, CrisisScreen passes the inserted scripts.id here
  scriptId?: string | null;
}

type SectionKey = "regulate" | "connect" | "guide" | "why" | "followUp";

export function ScriptDisplay({
  script,
  isSaving,
  onSave,
  onStartOver,
  isPremium,
  scriptId,
}: ScriptDisplayProps) {
  const [expandedSections, setExpandedSections] = useState<Record<SectionKey, boolean>>({
    regulate: true,
    connect: false,
    guide: false,
    why: false,
    followUp: false,
  });

  // NEW: rating UX state
  const [ratingSubmitting, setRatingSubmitting] = useState(false);
  const [savedRating, setSavedRating] = useState<1 | 2 | 3 | null>(null);

  const toggleSection = (section: SectionKey) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const steps = useMemo(
    () =>
      [
        {
          key: "regulate" as const,
          number: "1",
          title: "Regulate",
          subtitle: "Lower the heat fast",
          color: colors.primary,
          body: script.part1?.script ?? "",
        },
        {
          key: "connect" as const,
          number: "2",
          title: "Connect",
          subtitle: "Make them feel seen",
          color: colors.info,
          body: script.part2?.script ?? "",
        },
        {
          key: "guide" as const,
          number: "3",
          title: "Guide",
          subtitle: "Hold the boundary with calm authority",
          color: colors.success,
          body: script.part3?.script ?? "",
        },
      ].filter((s) => (s.body ?? "").trim().length > 0),
    [script]
  );

  const identityLine = (script.parentMantra ?? "").trim();
  const deliveryTip = (script.deliveryTip ?? "").trim();

  const canRate = !!scriptId && !ratingSubmitting;

  const submitRating = async (userRating: 1 | 2 | 3) => {
    if (!scriptId) return;
    if (ratingSubmitting) return;

    try {
      setRatingSubmitting(true);
      await updateScriptRating({ scriptId, userRating });
      setSavedRating(userRating);
    } catch (e) {
      // Keep it quiet; rating is a nice-to-have
      console.error("Failed to save rating:", e);
    } finally {
      setRatingSubmitting(false);
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Your Script</Text>
        <Text style={styles.subtitle}>
          {script.frameworkUsed} • {script.toneUsed}
        </Text>
      </View>

      {/* 3-Step Framework */}
      <Card style={styles.scriptCard}>
        {steps.map((s, idx) => {
          const isExpanded = expandedSections[s.key];
          return (
            <View key={s.key}>
              <TouchableOpacity
                style={styles.partHeader}
                onPress={() => toggleSection(s.key)}
                activeOpacity={0.7}
              >
                <View style={[styles.partNumber, { backgroundColor: s.color }]}>
                  <Text style={styles.partNumberText}>{s.number}</Text>
                </View>

                <View style={styles.partTitleContainer}>
                  <Text style={styles.partTitle}>{s.title}</Text>
                  <Text style={styles.partSubtitle}>{s.subtitle}</Text>
                </View>

                <Ionicons
                  name={isExpanded ? "chevron-up" : "chevron-down"}
                  size={20}
                  color={colors.foregroundLight}
                />
              </TouchableOpacity>

              {isExpanded && (
                <View style={styles.partContent}>
                  <Text style={styles.scriptText}>{s.body}</Text>
                </View>
              )}

              {idx !== steps.length - 1 && <View style={styles.divider} />}
            </View>
          );
        })}
      </Card>

      {/* Identity Line */}
      {!!identityLine && (
        <Card style={styles.identityCard}>
          <View style={styles.identityHeader}>
            <Ionicons name="shield-outline" size={22} color={colors.primary} />
            <Text style={styles.identityTitle}>Identity</Text>
          </View>
          <Text style={styles.identityText}>“{identityLine}”</Text>
        </Card>
      )}

      {/* Delivery Tip */}
      {!!deliveryTip && (
        <Card style={styles.tipCard}>
          <View style={styles.tipHeader}>
            <Ionicons name="bulb-outline" size={24} color={colors.warning} />
            <Text style={styles.tipTitle}>Delivery Tip</Text>
          </View>
          <Text style={styles.tipText}>{deliveryTip}</Text>
        </Card>
      )}

      {/* Premium Content */}
      {isPremium && script.whyThisWorks && (
        <Card style={styles.premiumCard}>
          <TouchableOpacity
            style={styles.premiumHeader}
            onPress={() => toggleSection("why")}
            activeOpacity={0.7}
          >
            <View style={styles.premiumHeaderLeft}>
              <View style={styles.premiumBadge}>
                <Ionicons name="star" size={16} color={colors.primary} />
              </View>
              <Text style={styles.premiumTitle}>Why This Works</Text>
            </View>
            <Ionicons
              name={expandedSections.why ? "chevron-up" : "chevron-down"}
              size={20}
              color={colors.foregroundLight}
            />
          </TouchableOpacity>
          {expandedSections.why && (
            <View style={styles.premiumContent}>
              <Text style={styles.premiumText}>{script.whyThisWorks}</Text>
            </View>
          )}
        </Card>
      )}

      {isPremium && script.proactiveFollowUp && (
        <Card style={styles.premiumCard}>
          <TouchableOpacity
            style={styles.premiumHeader}
            onPress={() => toggleSection("followUp")}
            activeOpacity={0.7}
          >
            <View style={styles.premiumHeaderLeft}>
              <View style={styles.premiumBadge}>
                <Ionicons name="star" size={16} color={colors.primary} />
              </View>
              <Text style={styles.premiumTitle}>Proactive Follow-Up</Text>
            </View>
            <Ionicons
              name={expandedSections.followUp ? "chevron-up" : "chevron-down"}
              size={20}
              color={colors.foregroundLight}
            />
          </TouchableOpacity>
          {expandedSections.followUp && (
            <View style={styles.premiumContent}>
              <Text style={styles.premiumText}>{script.proactiveFollowUp}</Text>
            </View>
          )}
        </Card>
      )}

      {/* NEW: Outcome rating (only shows after a successful Save, when scriptId exists) */}
      {!!scriptId && (
        <Card style={styles.ratingCard}>
          <View style={styles.ratingHeader}>
            <Ionicons name="heart-outline" size={20} color={colors.primary} />
            <Text style={styles.ratingTitle}>How did that go?</Text>
          </View>

          <Text style={styles.ratingSubtitle}>
            This helps Sturdy learn what works for your family.
          </Text>

          <View style={styles.ratingRow}>
            <TouchableOpacity
              style={[
                styles.ratingBtn,
                savedRating === 3 && styles.ratingBtnActive,
              ]}
              activeOpacity={0.8}
              disabled={!canRate}
              onPress={() => submitRating(3)}
            >
              <Text
                style={[
                  styles.ratingBtnText,
                  savedRating === 3 && styles.ratingBtnTextActive,
                ]}
              >
                Better 😊
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.ratingBtn,
                savedRating === 2 && styles.ratingBtnActive,
              ]}
              activeOpacity={0.8}
              disabled={!canRate}
              onPress={() => submitRating(2)}
            >
              <Text
                style={[
                  styles.ratingBtnText,
                  savedRating === 2 && styles.ratingBtnTextActive,
                ]}
              >
                Same 😐
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.ratingBtn,
                savedRating === 1 && styles.ratingBtnActive,
              ]}
              activeOpacity={0.8}
              disabled={!canRate}
              onPress={() => submitRating(1)}
            >
              <Text
                style={[
                  styles.ratingBtnText,
                  savedRating === 1 && styles.ratingBtnTextActive,
                ]}
              >
                Still hard 😣
              </Text>
            </TouchableOpacity>
          </View>

          {!!savedRating && (
            <Text style={styles.ratingThanks}>
              Saved — thank you.
            </Text>
          )}
        </Card>
      )}

      {/* Action Buttons */}
      <View style={styles.actions}>
        <Button
          title={isSaving ? "Saving..." : "Save Script"}
          onPress={onSave}
          disabled={isSaving}
          style={styles.saveButton}
        />
        <Button title="Start Over" onPress={onStartOver} variant="outline" />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingBottom: spacing.xl,
  },
  header: {
    marginBottom: spacing.lg,
  },
  title: {
    ...textStyles.h2,
    color: colors.foreground,
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
  },

  scriptCard: {
    marginBottom: spacing.md,
  },
  partHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: spacing.md,
  },
  partNumber: {
    width: 32,
    height: 32,
    borderRadius: spacing.borderRadius.full,
    justifyContent: "center",
    alignItems: "center",
    marginRight: spacing.md,
  },
  partNumberText: {
    ...textStyles.label,
    color: colors.white,
  },
  partTitleContainer: {
    flex: 1,
  },
  partTitle: {
    ...textStyles.h4,
    color: colors.foreground,
    marginBottom: spacing.xs / 2,
  },
  partSubtitle: {
    ...textStyles.caption,
    color: colors.foregroundLight,
  },
  partContent: {
    paddingLeft: 48,
    paddingRight: spacing.md,
    paddingBottom: spacing.md,
  },
  scriptText: {
    ...textStyles.scriptText,
    color: colors.foreground,
    lineHeight: 28,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.sm,
  },

  identityCard: {
    backgroundColor: colors.muted,
    marginBottom: spacing.md,
  },
  identityHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.md,
  },
  identityTitle: {
    ...textStyles.h4,
    color: colors.foreground,
    marginLeft: spacing.sm,
  },
  identityText: {
    ...textStyles.bodyLarge,
    color: colors.foreground,
    fontStyle: "italic",
  },

  tipCard: {
    backgroundColor: colors.warningLight,
    marginBottom: spacing.md,
  },
  tipHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.md,
  },
  tipTitle: {
    ...textStyles.h4,
    color: colors.foreground,
    marginLeft: spacing.sm,
  },
  tipText: {
    ...textStyles.body,
    color: colors.foreground,
  },

  premiumCard: {
    borderWidth: 2,
    borderColor: colors.primary,
    marginBottom: spacing.md,
  },
  premiumHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  premiumHeaderLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  premiumBadge: {
    width: 28,
    height: 28,
    borderRadius: spacing.borderRadius.full,
    backgroundColor: colors.muted,
    justifyContent: "center",
    alignItems: "center",
    marginRight: spacing.sm,
  },
  premiumTitle: {
    ...textStyles.h4,
    color: colors.foreground,
  },
  premiumContent: {
    marginTop: spacing.md,
  },
  premiumText: {
    ...textStyles.body,
    color: colors.foreground,
  },

  // NEW: Rating card
  ratingCard: {
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  ratingHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.sm,
  },
  ratingTitle: {
    ...textStyles.h4,
    color: colors.foreground,
    marginLeft: spacing.sm,
  },
  ratingSubtitle: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
    marginBottom: spacing.md,
  },
  ratingRow: {
    flexDirection: "row",
    gap: spacing.sm as any, // RN types sometimes dislike gap; safe fallback is margin if needed
    justifyContent: "space-between",
  },
  ratingBtn: {
    flex: 1,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.sm,
    borderRadius: spacing.borderRadius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.card,
    alignItems: "center",
  },
  ratingBtnActive: {
    borderColor: colors.primary,
    backgroundColor: colors.muted,
  },
  ratingBtnText: {
    ...textStyles.label,
    color: colors.foreground,
  },
  ratingBtnTextActive: {
    color: colors.primary,
  },
  ratingThanks: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
    marginTop: spacing.md,
  },

  actions: {
    marginTop: spacing.md,
  },
  saveButton: {
    marginBottom: spacing.md,
  },
});
