import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../theme/colors';
import { textStyles } from '../../theme/typography';
import { spacing } from '../../theme/spacing';
import { Child } from '../../lib/types';
import { NEUROTYPES } from '../../config/neurotypes';
import { formatChildAge } from '../../lib/utils';
import { Card } from '../shared/Card';

interface ChildSelectorProps {
  childList?: Child[];
  loading: boolean;
  selectedChildId: string | null;
  manualAge: string;
  manualNeurotype: string;
  onSelectChild: (childId: string | null) => void;
  onManualAgeChange: (age: string) => void;
  onManualNeurotypeChange: (neurotype: string) => void;
}

const AGE_RANGES = [
  { label: '0-2 years', value: '0-2' },
  { label: '2-4 years', value: '2-4' },
  { label: '5-7 years', value: '5-7' },
  { label: '8-11 years', value: '8-11' },
  { label: '12+ years', value: '12+' },
];

export function ChildSelector({
  childList = [],
  loading,
  selectedChildId,
  manualAge,
  manualNeurotype,
  onSelectChild,
  onManualAgeChange,
  onManualNeurotypeChange,
}: ChildSelectorProps) {
  const [useManual, setUseManual] = useState(!childList.length);

  const handleSelectChild = (childId: string) => {
    setUseManual(false);
    onSelectChild(childId);
    // Clear manual fields when selecting a child
    onManualAgeChange('');
    onManualNeurotypeChange('');
  };

  const handleUseManual = () => {
    setUseManual(true);
    onSelectChild(null);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>Who needs help?</Text>
      <Text style={styles.subtitle}>
        Select your child or enter details manually
      </Text>

      {/* Children list */}
      {childList.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Children</Text>
          {childList.map((child) => {
            const isSelected = selectedChildId === child.id && !useManual;
            return (
              <TouchableOpacity
                key={child.id}
                style={[
                  styles.childCard,
                  isSelected && styles.childCardSelected,
                ]}
                onPress={() => handleSelectChild(child.id)}
                activeOpacity={0.7}
              >
                <View style={styles.childAvatar}>
                  <Ionicons
                    name="person"
                    size={24}
                    color={isSelected ? colors.primary : colors.foregroundLight}
                  />
                </View>
                <View style={styles.childInfo}>
                  <Text
                    style={[
                      styles.childName,
                      isSelected && styles.childNameSelected,
                    ]}
                  >
                    {child.name}
                  </Text>
                  <Text style={styles.childDetails}>
                    {formatChildAge(child.birth_date)} • {child.neurotype}
                  </Text>
                </View>
                {isSelected && (
                  <Ionicons
                    name="checkmark-circle"
                    size={24}
                    color={colors.primary}
                  />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      )}

      {/* Manual entry section */}
      <View style={styles.section}>
        <TouchableOpacity
          style={[styles.manualToggle, useManual && styles.manualToggleActive]}
          onPress={handleUseManual}
          activeOpacity={0.7}
        >
          <View style={styles.manualToggleContent}>
            <Ionicons
              name="create-outline"
              size={24}
              color={useManual ? colors.primary : colors.foregroundLight}
            />
            <Text
              style={[
                styles.manualToggleText,
                useManual && styles.manualToggleTextActive,
              ]}
            >
              Enter details manually
            </Text>
          </View>
          {useManual && (
            <Ionicons name="checkmark-circle" size={24} color={colors.primary} />
          )}
        </TouchableOpacity>

        {useManual && (
          <Card style={styles.manualForm}>
            {/* Age selection */}
            <Text style={styles.fieldLabel}>{"Child's Age"}</Text>
            <View style={styles.optionsGrid}>
              {AGE_RANGES.map((range) => (
                <TouchableOpacity
                  key={range.value}
                  style={[
                    styles.optionChip,
                    manualAge === range.value && styles.optionChipSelected,
                  ]}
                  onPress={() => onManualAgeChange(range.value)}
                  activeOpacity={0.7}
                >
                  <Text
                    style={[
                      styles.optionChipText,
                      manualAge === range.value && styles.optionChipTextSelected,
                    ]}
                  >
                    {range.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Neurotype selection */}
            <Text style={styles.fieldLabel}>Neurotype (optional)</Text>
            <View style={styles.optionsGrid}>
              {NEUROTYPES.map((neurotype) => (
                <TouchableOpacity
                  key={neurotype.value}
                  style={[
                    styles.optionChip,
                    manualNeurotype === neurotype.value &&
                      styles.optionChipSelected,
                  ]}
                  onPress={() => onManualNeurotypeChange(neurotype.value)}
                  activeOpacity={0.7}
                >
                  <Text
                    style={[
                      styles.optionChipText,
                      manualNeurotype === neurotype.value &&
                        styles.optionChipTextSelected,
                    ]}
                  >
                    {neurotype.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </Card>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    ...textStyles.h2,
    color: colors.foreground,
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...textStyles.body,
    color: colors.foregroundLight,
    marginBottom: spacing.lg,
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    ...textStyles.label,
    color: colors.foregroundLight,
    marginBottom: spacing.sm,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  childCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: spacing.borderRadius.lg,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 2,
    borderColor: colors.border,
    ...spacing.shadow.sm,
  },
  childCardSelected: {
    borderColor: colors.primary,
    backgroundColor: `${colors.primary}10`,
  },
  childAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.muted,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  childInfo: {
    flex: 1,
  },
  childName: {
    ...textStyles.h4,
    color: colors.foreground,
  },
  childNameSelected: {
    color: colors.primary,
  },
  childDetails: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
    marginTop: 2,
  },
  manualToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    borderRadius: spacing.borderRadius.lg,
    padding: spacing.md,
    borderWidth: 2,
    borderColor: colors.border,
    ...spacing.shadow.sm,
  },
  manualToggleActive: {
    borderColor: colors.primary,
    backgroundColor: `${colors.primary}10`,
  },
  manualToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  manualToggleText: {
    ...textStyles.body,
    color: colors.foreground,
  },
  manualToggleTextActive: {
    color: colors.primary,
    fontWeight: '600',
  },
  manualForm: {
    marginTop: spacing.md,
  },
  fieldLabel: {
    ...textStyles.label,
    color: colors.foreground,
    marginBottom: spacing.sm,
    marginTop: spacing.md,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  optionChip: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.muted,
    borderRadius: spacing.borderRadius.full,
    borderWidth: 1,
    borderColor: colors.border,
  },
  optionChipSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  optionChipText: {
    ...textStyles.bodySmall,
    color: colors.foreground,
  },
  optionChipTextSelected: {
    color: colors.white,
    fontWeight: '600',
  },
});
