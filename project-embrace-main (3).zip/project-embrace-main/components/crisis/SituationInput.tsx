import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../theme/colors';
import { textStyles } from '../../theme/typography';
import { spacing } from '../../theme/spacing';
import { Input } from '../shared/Input';

interface SituationInputProps {
  situation: string;
  onSituationChange: (text: string) => void;
  scenarioLabel?: string;
}

const MAX_CHARS = 300;

export function SituationInput({
  situation,
  onSituationChange,
  scenarioLabel,
}: SituationInputProps) {
  const charsRemaining = MAX_CHARS - situation.length;
  const isOverLimit = charsRemaining < 0;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Describe the situation</Text>
      <Text style={styles.subtitle}>
        {scenarioLabel
          ? `Tell us more about this ${scenarioLabel.toLowerCase()} situation`
          : 'Provide details about what\'s happening'}
      </Text>

      <View style={styles.inputContainer}>
        <Input
          value={situation}
          onChangeText={onSituationChange}
          placeholder="Example: My 4-year-old hits his sister when she takes his toys. He gets very upset and won't listen when I tell him to stop."
          multiline
          maxLength={MAX_CHARS}
          style={styles.textArea}
        />
        <View style={styles.charCounter}>
          <Text
            style={[
              styles.charCountText,
              isOverLimit && styles.charCountText_error,
            ]}
          >
            {charsRemaining} characters remaining
          </Text>
        </View>
      </View>

      {/* Tips Section */}
      <View style={styles.tipsContainer}>
        <View style={styles.tipHeader}>
          <Ionicons
            name="bulb-outline"
            size={20}
            color={colors.primary}
          />
          <Text style={styles.tipHeaderText}>Tips for better scripts</Text>
        </View>
        <View style={styles.tipsList}>
          <Text style={styles.tipItem}>
            • Mention specific behaviors and triggers
          </Text>
          <Text style={styles.tipItem}>
            • Include your child&apos;s typical reactions
          </Text>
          <Text style={styles.tipItem}>
            • Note what you&apos;ve already tried
          </Text>
        </View>
      </View>

      {/* Privacy Note */}
      <View style={styles.privacyNote}>
        <Ionicons
          name="lock-closed-outline"
          size={16}
          color={colors.foregroundLight}
        />
        <Text style={styles.privacyText}>
          Your information is private and secure
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    ...textStyles.h2,
    color: colors.foreground,
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
    marginBottom: spacing.lg,
  },
  inputContainer: {
    marginBottom: spacing.lg,
  },
  textArea: {
    minHeight: 120,
  },
  charCounter: {
    marginTop: spacing.sm,
  },
  charCountText: {
    ...textStyles.caption,
    color: colors.foregroundLight,
    textAlign: 'right',
  },
  charCountText_error: {
    color: colors.destructive,
  },
  tipsContainer: {
    backgroundColor: colors.muted,
    borderRadius: spacing.borderRadius.lg,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  tipHeaderText: {
    ...textStyles.label,
    color: colors.foreground,
    marginLeft: spacing.sm,
  },
  tipsList: {
    marginLeft: spacing.sm,
  },
  tipItem: {
    ...textStyles.bodySmall,
    color: colors.foregroundLight,
    marginBottom: spacing.xs,
  },
  privacyNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  privacyText: {
    ...textStyles.caption,
    color: colors.foregroundLight,
    marginLeft: spacing.xs,
  },
});
