import { PricingTier } from '../lib/types';

/**
 * Subscription pricing tiers
 * Free tier: 5 scripts total (lifetime limit)
 * Paid tiers: Unlimited scripts
 */
export const PRICING_TIERS: PricingTier[] = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    interval: 'lifetime',
    features: [
      '5 scripts total',
      'Basic script generation',
      'Save & favorite scripts',
      'Single child profile',
    ],
  },
  {
    id: 'monthly',
    name: 'Monthly',
    price: 7.99,
    interval: 'month',
    popular: true,
    features: [
      'Unlimited scripts',
      'Advanced script generation',
      'Multiple child profiles',
      'Priority support',
      'Premium features',
    ],
    stripePriceId: process.env.EXPO_PUBLIC_STRIPE_MONTHLY_PRICE_ID,
  },
  {
    id: 'annual',
    name: 'Annual',
    price: 79.99,
    interval: 'year',
    features: [
      'Everything in Monthly',
      '7-day free trial',
      'Save 17% vs monthly',
      'Early access to new features',
    ],
    stripePriceId: process.env.EXPO_PUBLIC_STRIPE_ANNUAL_PRICE_ID,
    trialDays: 7,
  },
];

/**
 * Free tier script limit
 */
export const FREE_TIER_SCRIPT_LIMIT = 5;

/**
 * Premium tier names (all paid tiers)
 */
export const PREMIUM_TIERS = ['monthly', 'annual', 'weekly', 'lifetime', 'premium', 'complete'];

/**
 * Check if a tier is premium
 */
export function isPremiumTier(tier: string): boolean {
  return PREMIUM_TIERS.includes(tier.toLowerCase());
}

/**
 * Get pricing tier by ID
 */
export function getPricingTierById(id: string): PricingTier | undefined {
  return PRICING_TIERS.find(t => t.id === id);
}

/**
 * Format price for display
 */
export function formatPrice(price: number, interval: string): string {
  if (price === 0) return 'Free';
  
  const formatted = `$${price.toFixed(2)}`;
  
  switch (interval) {
    case 'month':
      return `${formatted}/month`;
    case 'year':
      return `${formatted}/year`;
    case 'lifetime':
      return formatted;
    default:
      return formatted;
  }
}

/**
 * Calculate savings for annual plan
 */
export function calculateAnnualSavings(): number {
  const monthly = PRICING_TIERS.find(t => t.id === 'monthly');
  const annual = PRICING_TIERS.find(t => t.id === 'annual');
  
  if (!monthly || !annual) return 0;
  
  const monthlyYearlyCost = monthly.price * 12;
  return monthlyYearlyCost - annual.price;
}
