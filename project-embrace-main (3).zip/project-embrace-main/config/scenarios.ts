import { Scenario } from '../lib/types';

/**
 * Crisis scenarios for parenting situations
 * Each scenario includes an Ionicon name and color theme
 */
export const SCENARIOS: Scenario[] = [
  {
    id: 'hitting',
    label: 'Hitting/Aggression',
    color: '#ef4444', // red-500
    icon: 'hand-right-outline',
    description: 'Physical aggression towards others',
  },
  {
    id: 'tantrum',
    label: 'Meltdown',
    color: '#f59e0b', // amber-500
    icon: 'thunderstorm-outline',
    description: 'Emotional meltdown or tantrum',
  },
  {
    id: 'bedtime',
    label: 'Bedtime',
    color: '#8b5cf6', // violet-500
    icon: 'moon-outline',
    description: 'Bedtime resistance or sleep issues',
  },
  {
    id: 'transition',
    label: 'Leaving/Transitions',
    color: '#3b82f6', // blue-500
    icon: 'exit-outline',
    description: 'Difficulty with transitions or leaving places',
  },
  {
    id: 'food',
    label: 'Food Refusal',
    color: '#10b981', // green-500
    icon: 'restaurant-outline',
    description: 'Refusing to eat or food-related conflicts',
  },
  {
    id: 'sibling',
    label: 'Sibling Conflict',
    color: '#ec4899', // pink-500
    icon: 'people-outline',
    description: 'Conflict between siblings',
  },
  {
    id: 'defiance',
    label: 'Defiance',
    color: '#f97316', // orange-500
    icon: 'shield-outline',
    description: 'Refusing to follow instructions',
  },
  {
    id: 'whining',
    label: 'Whining',
    color: '#06b6d4', // cyan-500
    icon: 'volume-high-outline',
    description: 'Persistent whining or complaining',
  },
];

/**
 * Get a scenario by its ID
 */
export function getScenarioById(id: string): Scenario | undefined {
  return SCENARIOS.find(s => s.id === id);
}

/**
 * Get scenario color by ID
 */
export function getScenarioColor(id: string): string {
  return getScenarioById(id)?.color || '#64748b'; // slate-500 default
}
