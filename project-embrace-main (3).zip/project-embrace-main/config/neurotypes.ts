import { Neurotype, NeurotypeOption } from '../lib/types';

/**
 * Neurotype options for child profiles
 * Used in child creation/editing and crisis script generation
 */
export const NEUROTYPES: NeurotypeOption[] = [
  {
    value: 'neurotypical',
    label: 'Neurotypical',
    description: 'Typical developmental pattern',
  },
  {
    value: 'ADHD',
    label: 'ADHD',
    description: 'Attention-Deficit/Hyperactivity Disorder',
  },
  {
    value: 'Autism',
    label: 'Autism',
    description: 'Autism Spectrum Disorder',
  },
  {
    value: 'AuDHD',
    label: 'AuDHD',
    description: 'Both Autism and ADHD',
  },
  {
    value: 'Anxiety',
    label: 'Anxiety',
    description: 'Anxiety disorders',
  },
  {
    value: 'Highly Sensitive',
    label: 'Highly Sensitive',
    description: 'Highly Sensitive Person (HSP)',
  },
  {
    value: 'Sensory',
    label: 'Sensory',
    description: 'Sensory Processing Disorder',
  },
  {
    value: 'Gifted',
    label: 'Gifted',
    description: 'Intellectually gifted',
  },
];

/**
 * Get neurotype option by value
 */
export function getNeurotypeByValue(value: string): NeurotypeOption | undefined {
  return NEUROTYPES.find(n => n.value === value);
}

/**
 * Get neurotype label by value
 */
export function getNeurotypeLabel(value: string): string {
  return getNeurotypeByValue(value)?.label || value;
}

/**
 * Simple array of neurotype values for legacy compatibility
 */
export const NEUROTYPE_VALUES: Neurotype[] = NEUROTYPES.map(n => n.value);
