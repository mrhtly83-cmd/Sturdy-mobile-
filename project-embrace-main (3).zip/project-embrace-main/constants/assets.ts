export const assets = {
  hero: require("../assets/images/hero-home.jpg"),
  logo: require("../assets/images/logo.png"),
};
