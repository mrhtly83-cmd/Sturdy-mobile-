/**
 * Clinical Luxury Design System - Colors
 * Based on the web app's color scheme with mobile optimizations
 */

export const colors = {
  // Primary brand color
  primary: '#CA8A04', // Gold - matches web app
  primaryLight: '#EAB308',
  primaryDark: '#A16207',
  
  // Background colors
  background: '#F8FAFC', // Slate 50
  backgroundDark: '#0F172A', // Slate 900
  card: '#FFFFFF',
  cardDark: '#1E293B', // Slate 800
  
  // Foreground/text colors
  foreground: '#0F172A', // Slate 900
  foregroundLight: '#64748B', // Slate 500
  foregroundDark: '#F1F5F9', // Slate 100
  
  // Muted/subtle colors
  muted: '#F1F5F9', // Slate 100
  mutedForeground: '#64748B', // Slate 500
  
  // Border colors
  border: '#E2E8F0', // Slate 200
  borderDark: '#334155', // Slate 700
  
  // Accent colors
  accent: '#CA8A04', // Same as primary
  accentForeground: '#FFFFFF',
  
  // Status colors
  destructive: '#EF4444', // Red 500
  destructiveLight: '#FEE2E2', // Red 100
  success: '#10B981', // Green 500
  successLight: '#D1FAE5', // Green 100
  warning: '#F59E0B', // Amber 500
  warningLight: '#FEF3C7', // Amber 100
  info: '#3B82F6', // Blue 500
  infoLight: '#DBEAFE', // Blue 100
  
  // Semantic colors for scenarios
  scenario: {
    hitting: '#EF4444',      // red
    tantrum: '#F59E0B',      // amber
    bedtime: '#8B5CF6',      // violet
    transition: '#3B82F6',   // blue
    food: '#10B981',         // green
    sibling: '#EC4899',      // pink
    defiance: '#F97316',     // orange
    whining: '#06B6D4',      // cyan
  },
  
  // Overlay colors
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.2)',
  
  // Input colors
  input: '#E2E8F0', // Slate 200
  inputForeground: '#0F172A', // Slate 900
  
  // System colors
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
} as const;

/**
 * Get color with opacity
 */
export function withOpacity(color: string, opacity: number): string {
  // Convert hex to rgba
  const hex = color.replace('#', '');
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
}

export type Colors = typeof colors;
