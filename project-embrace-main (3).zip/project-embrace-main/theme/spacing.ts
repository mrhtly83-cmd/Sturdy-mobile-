/**
 * Spacing and layout constants
 * Using 4px base unit for consistency
 */

export const spacing = {
  // Base spacing units (4px increments)
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  '2xl': 48,
  '3xl': 64,
  
  // Specific use cases
  screenPadding: 16,
  cardPadding: 16,
  sectionMargin: 24,
  listItemSpacing: 12,
  
  // Border radius
  borderRadius: {
    none: 0,
    sm: 4,
    md: 8,
    lg: 12,
    xl: 16,
    '2xl': 24,
    full: 9999,
  },
  
  // Shadows (for iOS/Android elevation)
  shadow: {
    sm: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 2,
      elevation: 1,
    },
    md: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    },
    lg: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.15,
      shadowRadius: 8,
      elevation: 5,
    },
    xl: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.2,
      shadowRadius: 16,
      elevation: 8,
    },
  },
  
  // Icon sizes
  iconSize: {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 32,
    xl: 40,
  },
  
  // Button heights
  buttonHeight: {
    sm: 32,
    md: 44,
    lg: 56,
  },
  
  // Input heights
  inputHeight: {
    sm: 36,
    md: 44,
    lg: 52,
  },
} as const;

/**
 * Layout constants
 */
export const layout = {
  // Screen dimensions
  maxWidth: 600, // Max width for tablet optimization
  
  // Tab bar
  tabBarHeight: 60,
  
  // Header
  headerHeight: 56,
  
  // Bottom sheet heights
  bottomSheet: {
    small: 300,
    medium: 500,
    large: '80%',
  },
} as const;

export type Spacing = typeof spacing;
export type Layout = typeof layout;
