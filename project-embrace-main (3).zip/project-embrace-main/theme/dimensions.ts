import { Dimensions } from "react-native";

// Get device dimensions
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");

// Reference dimensions (iPhone 14 Pro - standard size)
const REFERENCE_WIDTH = 393;
const REFERENCE_HEIGHT = 852;

// Device type detection
export const isSmallDevice = SCREEN_WIDTH < 375; // iPhone SE, small Android
export const isLargeDevice = SCREEN_WIDTH > 428; // iPhone Pro Max, large Android
export const isTablet = SCREEN_WIDTH >= 768; // iPad mini and up

/**
 * Scales a value based on screen width
 * Use this for horizontal spacing, widths, and font sizes
 */
export function scaleWidth(size: number): number {
  return (SCREEN_WIDTH / REFERENCE_WIDTH) * size;
}

/**
 * Scales a value based on screen height
 * Use this for vertical spacing and heights
 */
export function scaleHeight(size: number): number {
  return (SCREEN_HEIGHT / REFERENCE_HEIGHT) * size;
}

/**
 * Scales with moderate factor - prevents extreme scaling on very large/small devices
 * Best for font sizes to keep them readable
 */
export function moderateScale(size: number, factor = 0.5): number {
  const scale = SCREEN_WIDTH / REFERENCE_WIDTH;
  return size + (scale - 1) * factor * size;
}

/**
 * Responsive font size with min/max constraints
 */
export function responsiveFontSize(
  size: number,
  min?: number,
  max?: number
): number {
  const scaled = moderateScale(size);
  if (min && scaled < min) return min;
  if (max && scaled > max) return max;
  return Math.round(scaled);
}

/**
 * Responsive spacing with min/max constraints
 */
export function responsiveSpacing(
  size: number,
  min?: number,
  max?: number
): number {
  const scaled = scaleWidth(size);
  if (min && scaled < min) return min;
  if (max && scaled > max) return max;
  return Math.round(scaled);
}

/**
 * Responsive height with min/max constraints
 */
export function responsiveHeight(
  size: number,
  min?: number,
  max?: number
): number {
  const scaled = scaleHeight(size);
  if (min && scaled < min) return min;
  if (max && scaled > max) return max;
  return Math.round(scaled);
}

// Responsive dimension constants
export const dimensions = {
  // Screen dimensions
  screenWidth: SCREEN_WIDTH,
  screenHeight: SCREEN_HEIGHT,

  // Common responsive values
  borderRadius: {
    xs: responsiveSpacing(4, 4, 6),
    sm: responsiveSpacing(8, 6, 10),
    md: responsiveSpacing(12, 10, 16),
    lg: responsiveSpacing(16, 14, 20),
    xl: responsiveSpacing(20, 18, 28),
    full: 9999,
  },

  padding: {
    xs: responsiveSpacing(4, 4, 8),
    sm: responsiveSpacing(8, 6, 12),
    md: responsiveSpacing(16, 12, 20),
    lg: responsiveSpacing(24, 20, 32),
    xl: responsiveSpacing(32, 28, 40),
  },

  margin: {
    xs: responsiveSpacing(4, 4, 8),
    sm: responsiveSpacing(8, 6, 12),
    md: responsiveSpacing(16, 12, 20),
    lg: responsiveSpacing(24, 20, 32),
    xl: responsiveSpacing(32, 28, 40),
  },

  fontSize: {
    xs: responsiveFontSize(11, 10, 13),
    sm: responsiveFontSize(13, 12, 15),
    base: responsiveFontSize(15, 14, 17),
    md: responsiveFontSize(16, 15, 18),
    lg: responsiveFontSize(18, 16, 22),
    xl: responsiveFontSize(20, 18, 24),
    "2xl": responsiveFontSize(24, 22, 28),
    "3xl": responsiveFontSize(30, 26, 36),
    "4xl": responsiveFontSize(36, 32, 44),
    "5xl": responsiveFontSize(48, 40, 60),
  },

  // Component-specific dimensions
  button: {
    height: {
      sm: responsiveHeight(36, 32, 40),
      md: responsiveHeight(44, 40, 52),
      lg: responsiveHeight(52, 48, 60),
    },
    paddingHorizontal: {
      sm: responsiveSpacing(12, 10, 16),
      md: responsiveSpacing(16, 14, 20),
      lg: responsiveSpacing(20, 18, 24),
    },
  },

  input: {
    height: {
      sm: responsiveHeight(36, 32, 40),
      md: responsiveHeight(44, 40, 52),
      lg: responsiveHeight(52, 48, 60),
    },
    paddingHorizontal: responsiveSpacing(12, 10, 16),
  },

  icon: {
    xs: responsiveSpacing(16, 14, 18),
    sm: responsiveSpacing(20, 18, 24),
    md: responsiveSpacing(24, 22, 28),
    lg: responsiveSpacing(32, 28, 36),
    xl: responsiveSpacing(40, 36, 48),
  },

  header: {
    height: responsiveHeight(56, 50, 64),
  },

  tabBar: {
    height: responsiveHeight(60, 54, 68),
  },
};

// Device-specific adjustments
export const deviceAdjustments = {
  // Extra padding for small devices to prevent cramping
  screenPadding: isSmallDevice
    ? dimensions.padding.sm
    : isLargeDevice
    ? dimensions.padding.lg
    : dimensions.padding.md,

  // Card padding adjustments
  cardPadding: isSmallDevice
    ? dimensions.padding.sm
    : isTablet
    ? dimensions.padding.xl
    : dimensions.padding.md,

  // Section spacing
  sectionSpacing: isSmallDevice
    ? dimensions.margin.md
    : isTablet
    ? dimensions.margin.xl
    : dimensions.margin.lg,
};

// Export for convenience
export { SCREEN_WIDTH as screenWidth, SCREEN_HEIGHT as screenHeight };
