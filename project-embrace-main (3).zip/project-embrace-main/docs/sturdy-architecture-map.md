# STURDY — Architecture Map

**Single Source of Truth** | **Updated:** February 2026

---

## Table of Contents

1. [User Journey Flow](#1-user-journey-flow)
2. [Dual-Mode Strategy](#2-dual-mode-strategy)
3. [Dashboard Feature Map](#3-dashboard-feature-map)
4. [Backend Architecture](#4-backend-architecture)
5. [Database Schema](#5-database-schema)
6. [Monetization Flow](#6-monetization-flow)
7. [Development Status Scorecard](#7-development-status-scorecard)

---

## 1. User Journey Flow

Auth-aware routing: unauthenticated → Landing, authenticated → Dashboard.

### Main Flow

```mermaid
graph LR
    A["Landing (/) ✅"] --> B["IntroSlider (/intro) ✅"]
    B --> C["Auth Gate (/login) ✅"]
    C --> D["Dashboard (/dashboard) ✅"]
```

### Authenticated Routes

| Route | Path | Status |
|-------|------|--------|
| Crisis Mode | `/crisis` | `[DONE]` |
| Guidance | _(in dashboard)_ | `[DONE]` |
| What If | _(in dashboard)_ | `[DONE]` |
| Saved Scripts | `/saved` | `[DONE]` |
| Profiles | `/profile` | `[DONE]` |
| Pricing | `/pricing` | `[DONE]` |
| Generate | `/generate` | `[DONE]` |

---

## 2. Dual-Mode Strategy

Sturdy serves two distinct parenting moments with complementary features.

| Feature | Timing | Use Case | Access |
|---------|--------|----------|--------|
| **Crisis Mode** | Immediate, high-stress | Parent needs a script NOW | Free (5 lifetime, then premium) |
| **Guidance Mode** | Planned, reflective | Parent wants to learn frameworks | Premium (3 free/month) |

### How They Work Together

- **Crisis Mode** gives immediate scripts → parent survives the moment
- **Guidance Mode** teaches underlying principles → parent builds long-term skills
- **Together** they create behavior change through education + immediate support

### The 6 Struggle Categories

Both modes share a common taxonomy of parenting challenges:

| Category | Emoji | Framework |
|----------|-------|-----------|
| **Warmth** vs. Rejection | 💕 | Attachment Theory |
| **Structure** vs. Chaos | 🏗️ | Authoritative Parenting |
| **Autonomy** vs. Coercion | 🦅 | Self-Determination Theory |
| **Calm** (Regulation) | 😌 | Polyvagal Theory & Co-Regulation |
| **Curiosity** (Understanding) | 🧠 | Collaborative Problem-Solving |
| **Conversation** (Connection) | 💬 | Nonviolent Communication |

### Monetization Psychology

- **Crisis Mode free** = Trust signal (not exploiting emergencies)
- **Guidance Mode gated** = Premium value (learning, not just crisis reaction)
- **Positioning** = "Build sturdy parenting" not "handle emergencies"

---

## 3. Dashboard Feature Map

Three core modes accessible from the Dashboard hub.

### Crisis Mode `[DONE]`

Form-based flow: free-text situation → age + neurotype → AI script.

```mermaid
graph TD
    A1[Situation - free text] --> A2[Age + Neurotype select]
    A2 --> A3[generate-crisis-script EF]
    A3 --> A4[PII scrub → Gemini 3 Flash → PII restore]
    A4 --> A5[Pilot Mode display - 3 phases]
```

**Script Structure (CrisisFormScript):**
1. Attention Phrases (observe / direct)
2. Empathy Phrases (perspective-taking / make amends)
3. Parent Regulation (neutral statement / model accountability)
4. Delivery Tips

Premium extras: "Why This Works", "Proactive Follow-Up", framework reasoning.

### Guidance Mode `[DONE]`

```mermaid
graph TD
    B1[6 category buttons] --> B2[Free-form question input]
    B2 --> B3[generate-guidance EF]
    B3 --> B4[Response + principles + strategies]
```

### What If Mode `[DONE]`

```mermaid
graph TD
    C1[6 scenario cards / custom input] --> C2[Age + neurotype selectors]
    C2 --> C3[generate-proactive-script EF]
    C3 --> C4[Practice script display]
```

### Supporting Features

| Feature | Description | Status |
|---------|-------------|--------|
| Saved Scripts | Search, filter, favorites | `[DONE]` |
| Child Profiles | CRUD + default | `[DONE]` |
| Usage Widget | Progress bar | `[DONE]` |
| Repair Protocol | Post-crisis reconnection | `[NOT BUILT]` |

---

## 4. Backend Architecture

9 Edge Functions + 4 shared utility modules.

### Edge Functions

| Function | Description | AI |
|----------|-------------|----|
| `generate-crisis-script` | Crisis script gen w/ PII scrub | Gemini 3 Flash |
| `generate-guidance` | Guidance mode AI responses | Gemini 3 Flash |
| `generate-proactive-script` | What If practice scripts | Gemini 3 Flash |
| `generate-prevention-plan` | Prevention plan generation | Gemini 3 Flash |
| `generate-script` | General script generation | Gemini 3 Flash |
| `record-script-feedback` | Save thumbs up/down + tags | — |
| `create-checkout-session` | Stripe checkout creation | — |
| `create-customer-portal` | Stripe portal session | — |
| `stripe-webhook` | Subscription lifecycle handler | — |

### Edge Function Request Flow (The "Money Gate")

```mermaid
sequenceDiagram
    participant User as Client (App)
    participant Edge as Edge Function
    participant Auth as Supabase Auth
    participant DB as Database (Tiers)
    participant AI as OpenAI / Lovable

    User->>Edge: Request Script (POST)
    
    rect rgb(20, 20, 20)
    Note over Edge, DB: 🛡️ Security & Billing Check
    Edge->>Auth: 1. Verify User Token
    Auth-->>Edge: User ID / Valid
    
    Edge->>DB: 2. Check Subscription Tier
    DB-->>Edge: "Free" or "Premium"
    
    Edge->>DB: 3. Check Usage Count
    DB-->>Edge: Count (e.g. 2/5 used)
    end
    
    alt Limit Reached / Not Paid
        Edge-->>User: 🚫 403 Forbidden (Upgrade Trigger)
    else Allowed
        Note over Edge, AI: 💸 Money Spent Here
        Edge->>AI: 4. Generate Script
        AI-->>Edge: Script Content
        Edge->>DB: 5. Increment Usage Count (+1)
        Edge-->>User: ✅ Return Script
    end
```

### Shared Utilities

| File | Exports |
|------|---------|
| `auth.ts` | `verifyAuth`, `scrubPII`, `restorePII` |
| `tier-check.ts` | `checkSubscriptionTier`, `canAccessFeature` |
| `cors.ts` | `getCorsHeaders`, `corsHeaders` |
| `validation.ts` | Input validation (crisis, script, guidance, proactive) |

### External Services

- **Lovable AI** — Gemini 3 Flash (script generation)
- **Stripe** — Payments, subscriptions, customer portal
- **Lovable Cloud** — Database, auth, edge function hosting

---

## 5. Database Schema

9 tables with RLS policies enforcing ownership.

```mermaid
erDiagram
    profiles ||--o{ children : "parent_id"
    profiles ||--o{ scripts : "parent_id"
    profiles ||--o{ script_usage : "user_id"
    children ||--o{ scripts : "child_id"
    children ||--o{ crisis_events : "child_id"
    scripts ||--o{ crisis_events : "script_id"
    scripts ||--o{ script_usage : "script_id"
    scripts ||--o{ script_feedback : "script_id"
```

### `profiles`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `subscription_tier` | text | Default: `'free'` |
| `subscription_status` | text | `'active'` / `'trialing'` / null |
| `scripts_used` | integer | Paywall counter |
| `stripe_customer_id` | text | Indexed for webhook lookups |
| `default_child_id` | uuid | FK → `children.id` |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | |

### `children`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `parent_id` | uuid | FK → `profiles.id` |
| `name` | text | |
| `birth_date` | date | |
| `neurotype` | text | Default: `'neurotypical'` |
| `triggers` | text[] | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | |

### `scripts`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `parent_id` | uuid | FK → `profiles.id` |
| `child_id` | uuid | FK → `children.id` |
| `situation` | text | |
| `script_text` | text | |
| `validation_text` | text | |
| `reframe_text` | text | |
| `insight_text` | text | |
| `tone` | integer | 0–100 |
| `is_favorite` | boolean | |
| `user_rating` | integer | |
| `created_at` | timestamptz | |

### `crisis_events`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `user_id` | uuid | |
| `child_id` | uuid | FK → `children.id` |
| `script_id` | uuid | FK → `scripts.id` |
| `crisis_type` | text | Default: `'general'` |
| `intensity` | integer | Default: 5 |
| `repair_sent_at` | timestamptz | |
| `repair_completed_at` | timestamptz | |
| `repair_script_used` | text | |
| `notes` | text | |
| `created_at` | timestamptz | |

### `script_usage`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `user_id` | uuid | FK → `profiles.id` |
| `script_id` | uuid | FK → `scripts.id` |
| `used_at` | timestamptz | |

### `script_feedback`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `user_id` | uuid | |
| `script_id` | uuid | FK → `scripts.id` |
| `tag` | text | |
| `feedback` | text | |
| `created_at` | timestamptz | |

### `repair_scripts`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `title` | text | |
| `age_range` | text | Default: `'all'` |
| `script_text` | text | |
| `context` | text | |
| `created_at` | timestamptz | |

> Read-only curated content. RLS: authenticated SELECT only, no INSERT/UPDATE/DELETE.

### `user_roles`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `user_id` | uuid | |
| `role` | enum | `admin` / `moderator` / `user` |
| `created_at` | timestamptz | |

### `whatif_events`

| Column | Type | Notes |
|--------|------|-------|
| `id` | uuid | PK |
| `user_id` | uuid | |
| `scenario` | text | |
| `child_age` | text | |
| `neurotype` | text | |
| `created_at` | timestamptz | |

---

## 6. Monetization Flow

### Payment Lifecycle

```mermaid
graph LR
    F1[Free Tier - 5 scripts] --> F2[Paywall - scripts_used ≥ 5]
    F2 --> F3[Stripe Checkout - Payment Links]
    F3 --> F4[stripe-webhook]
    F4 --> F5[Profile Update - subscription_tier]
```

### Pricing Tiers

| Tier | Price | Features |
|------|-------|----------|
| Free | $0 | 5 lifetime scripts, basic crisis mode |
| Monthly | $7.99/mo | Unlimited scripts, all modes, premium insights |
| Annual | $79.99/yr | Everything + 7-day free trial |

### Emergency Pass (Bypass)

> 1 extra script/month for free users who hit their limit. Stored in `localStorage` (⚠️ bypassable). Customer Portal available for subscription management.

---

## 7. Development Status Scorecard

### Safety ✅

| Area | Status | Notes |
|------|--------|-------|
| 988 Crisis Triggers | `[DONE]` | US/Canada/UK/AU resources on self-harm keywords |
| "Not Medical Advice" Disclaimers | `[DONE]` | Active across all script displays |

### Core Features ✅

| Area | Status |
|------|--------|
| Authentication (Email + Google) | `[DONE]` |
| Landing Page | `[DONE]` |
| IntroSlider | `[DONE]` |
| Dashboard (3 modes + widgets) | `[DONE]` |
| Crisis Mode (form-based) | `[DONE]` |
| Guidance Mode (6 categories) | `[DONE]` |
| What If Mode | `[DONE]` |
| Saved Scripts | `[DONE]` |
| Child Profiles | `[DONE]` |
| Stripe Payments | `[DONE]` |
| Onboarding | `[DONE]` |

### Pending Features 🔵

| Area | Status | Notes |
|------|--------|-------|
| Repair Protocol | `[DONE]` | Dashboard tile + crisis CTA + practice flow + 45-min notification |
| Green Days Momentum | `[NOT BUILT]` | No implementation |
| Roleplay Mode | `[NOT BUILT]` | AI practice not built |
| Persistent Analytics | `[PARTIAL]` | Console-only, no backend storage |
| Offline Support | `[NOT BUILT]` | No service worker |
| Password Reset | `[NOT BUILT]` | No forgot password link |

---

_This document mirrors the interactive Architecture Map at `/architecture` in a portable, version-controllable format._
