-- Add explicit deny policies for repair_scripts table (defense-in-depth)
-- This table contains curated content that should only be readable, never modified by users

-- Deny all INSERT operations
CREATE POLICY "No user inserts to repair scripts"
ON public.repair_scripts
FOR INSERT
WITH CHECK (false);

-- Deny all UPDATE operations  
CREATE POLICY "No user updates to repair scripts"
ON public.repair_scripts
FOR UPDATE
USING (false);

-- Deny all DELETE operations
CREATE POLICY "No user deletes of repair scripts"
ON public.repair_scripts
FOR DELETE
USING (false);