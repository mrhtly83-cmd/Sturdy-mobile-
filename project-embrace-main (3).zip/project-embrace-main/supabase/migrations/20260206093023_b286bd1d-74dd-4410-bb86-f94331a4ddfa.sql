-- Add subscription_status column to track 'active', 'trialing', 'canceled', etc.
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT NULL;