-- Add scripts_used counter to profiles for paywall tracking
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS scripts_used INTEGER NOT NULL DEFAULT 0;

-- Add index for efficient queries
CREATE INDEX IF NOT EXISTS idx_profiles_scripts_used ON public.profiles(scripts_used);