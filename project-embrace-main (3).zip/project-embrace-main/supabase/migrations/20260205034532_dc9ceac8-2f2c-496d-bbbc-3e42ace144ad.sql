-- Fix conflicting RLS policies on repair_scripts table
-- Drop the public policy that allows anyone to view repair scripts
-- This ensures only authenticated users can access the curated reconnection scripts

DROP POLICY IF EXISTS "Everyone can view repair scripts" ON public.repair_scripts;

-- The remaining policy "Authenticated users can view repair scripts" 
-- will now correctly require authentication for access