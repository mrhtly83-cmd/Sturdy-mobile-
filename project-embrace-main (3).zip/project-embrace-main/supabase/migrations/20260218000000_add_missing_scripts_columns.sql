-- Add missing columns to scripts table
-- These columns are used by the saveScriptToDatabase function

ALTER TABLE public.scripts 
ADD COLUMN IF NOT EXISTS category TEXT,
ADD COLUMN IF NOT EXISTS mode TEXT DEFAULT 'crisis' CHECK (mode IN ('crisis', 'guidance')),
ADD COLUMN IF NOT EXISTS child_age TEXT,
ADD COLUMN IF NOT EXISTS neurotype TEXT,
ADD COLUMN IF NOT EXISTS script_json JSONB;

-- Create index for faster filtering by mode
CREATE INDEX IF NOT EXISTS idx_scripts_mode ON public.scripts (mode);

-- Create index for faster filtering by category
CREATE INDEX IF NOT EXISTS idx_scripts_category ON public.scripts (category);
