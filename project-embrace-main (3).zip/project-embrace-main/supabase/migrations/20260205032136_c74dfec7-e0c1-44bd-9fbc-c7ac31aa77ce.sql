-- Add SELECT policy so users can only view their own feedback
CREATE POLICY "Users can view their own feedback"
ON public.script_feedback
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);