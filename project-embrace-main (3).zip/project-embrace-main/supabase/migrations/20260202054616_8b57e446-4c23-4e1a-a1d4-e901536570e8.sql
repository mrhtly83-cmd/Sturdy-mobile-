-- Fix INFO_LEAKAGE: get_monthly_script_count should validate user_uuid matches auth.uid()
CREATE OR REPLACE FUNCTION public.get_monthly_script_count(user_uuid UUID)
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT CASE 
    WHEN user_uuid = auth.uid() THEN (
      SELECT COUNT(*)::INTEGER
      FROM public.script_usage
      WHERE user_id = user_uuid
        AND used_at >= date_trunc('month', CURRENT_TIMESTAMP)
    )
    ELSE NULL
  END
$$;

-- Fix MISSING_RLS: Add DELETE policy for profiles table (GDPR compliance)
CREATE POLICY "Users can delete their own profile"
  ON public.profiles FOR DELETE
  USING (auth.uid() = id);