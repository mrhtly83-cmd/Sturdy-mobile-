-- Create table for tracking crisis events and repair protocol
CREATE TABLE public.crisis_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  child_id UUID REFERENCES public.children(id) ON DELETE SET NULL,
  script_id UUID REFERENCES public.scripts(id) ON DELETE SET NULL,
  crisis_type TEXT NOT NULL DEFAULT 'general',
  intensity INTEGER DEFAULT 5 CHECK (intensity >= 1 AND intensity <= 10),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  repair_sent_at TIMESTAMP WITH TIME ZONE,
  repair_completed_at TIMESTAMP WITH TIME ZONE,
  repair_script_used TEXT,
  notes TEXT
);

-- Enable RLS
ALTER TABLE public.crisis_events ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can view their own crisis events"
  ON public.crisis_events FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own crisis events"
  ON public.crisis_events FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own crisis events"
  ON public.crisis_events FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own crisis events"
  ON public.crisis_events FOR DELETE
  USING (auth.uid() = user_id);

-- Create table for repair scripts (pre-built reconnection scripts)
CREATE TABLE public.repair_scripts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  age_range TEXT NOT NULL DEFAULT 'all',
  script_text TEXT NOT NULL,
  context TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS (public read)
ALTER TABLE public.repair_scripts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view repair scripts"
  ON public.repair_scripts FOR SELECT
  USING (true);

-- Insert default repair scripts
INSERT INTO public.repair_scripts (title, age_range, script_text, context) VALUES
('The Reconnection', 'all', 'Hey buddy. Earlier, when I got upset, that was about me, not you. My feelings got too big. I''m sorry. Can I have a hug?', 'General reconnection after losing your temper'),
('The Acknowledgment', 'all', 'I want to talk about earlier. I didn''t handle that well, and you deserved better from me. I love you, and I''m working on doing better.', 'When you reacted harshly'),
('The Repair Question', '4-8', 'Can we have a do-over? I think we both got frustrated. What would help you feel better right now?', 'For younger children who need agency'),
('The Teen Check-in', '12+', 'I know earlier was rough. I''m not going to lecture. Just wanted to say I''m here when you''re ready to talk, no pressure.', 'For teens who need space'),
('The Body-Based Repair', 'all', 'My body got stressed earlier and I didn''t stay calm. Let''s take three deep breaths together and start fresh.', 'When physical regulation helps');