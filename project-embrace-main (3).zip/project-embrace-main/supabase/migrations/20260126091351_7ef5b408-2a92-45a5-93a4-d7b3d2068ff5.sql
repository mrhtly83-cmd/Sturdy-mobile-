-- Create table for What If proactive script events
CREATE TABLE public.whatif_events (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    scenario TEXT NOT NULL,
    child_age TEXT,
    neurotype TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.whatif_events ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own whatif events" 
ON public.whatif_events 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own whatif events" 
ON public.whatif_events 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own whatif events" 
ON public.whatif_events 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX idx_whatif_events_user_created ON public.whatif_events (user_id, created_at DESC);