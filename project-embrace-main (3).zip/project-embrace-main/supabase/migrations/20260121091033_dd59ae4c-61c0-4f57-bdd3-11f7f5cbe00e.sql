-- Add default_child_id column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN default_child_id uuid REFERENCES public.children(id) ON DELETE SET NULL;

-- Create index for faster lookups
CREATE INDEX idx_profiles_default_child ON public.profiles(default_child_id);