-- Fix repair_scripts public exposure - require authentication
DROP POLICY IF EXISTS "Anyone can view repair scripts" ON public.repair_scripts;

CREATE POLICY "Authenticated users can view repair scripts"
ON public.repair_scripts
FOR SELECT
USING (auth.uid() IS NOT NULL);