-- Drop the restrictive policies and recreate as permissive
DROP POLICY IF EXISTS "Users can view their own children" ON public.children;
DROP POLICY IF EXISTS "Users can insert their own children" ON public.children;
DROP POLICY IF EXISTS "Users can update their own children" ON public.children;
DROP POLICY IF EXISTS "Users can delete their own children" ON public.children;

-- Recreate as permissive (default)
CREATE POLICY "Users can view their own children" ON public.children
FOR SELECT USING (auth.uid() = parent_id);

CREATE POLICY "Users can insert their own children" ON public.children
FOR INSERT WITH CHECK (auth.uid() = parent_id);

CREATE POLICY "Users can update their own children" ON public.children
FOR UPDATE USING (auth.uid() = parent_id);

CREATE POLICY "Users can delete their own children" ON public.children
FOR DELETE USING (auth.uid() = parent_id);

-- Fix profiles policies too
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;

CREATE POLICY "Users can view their own profile" ON public.profiles
FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" ON public.profiles
FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
FOR UPDATE USING (auth.uid() = id);

-- Fix scripts policies
DROP POLICY IF EXISTS "Users can view their own scripts" ON public.scripts;
DROP POLICY IF EXISTS "Users can insert their own scripts" ON public.scripts;
DROP POLICY IF EXISTS "Users can update their own scripts" ON public.scripts;
DROP POLICY IF EXISTS "Users can delete their own scripts" ON public.scripts;

CREATE POLICY "Users can view their own scripts" ON public.scripts
FOR SELECT USING (auth.uid() = parent_id);

CREATE POLICY "Users can insert their own scripts" ON public.scripts
FOR INSERT WITH CHECK (auth.uid() = parent_id);

CREATE POLICY "Users can update their own scripts" ON public.scripts
FOR UPDATE USING (auth.uid() = parent_id);

CREATE POLICY "Users can delete their own scripts" ON public.scripts
FOR DELETE USING (auth.uid() = parent_id);

-- Fix script_usage policies
DROP POLICY IF EXISTS "Users can view their own usage" ON public.script_usage;
DROP POLICY IF EXISTS "Users can insert their own usage" ON public.script_usage;

CREATE POLICY "Users can view their own usage" ON public.script_usage
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own usage" ON public.script_usage
FOR INSERT WITH CHECK (auth.uid() = user_id);