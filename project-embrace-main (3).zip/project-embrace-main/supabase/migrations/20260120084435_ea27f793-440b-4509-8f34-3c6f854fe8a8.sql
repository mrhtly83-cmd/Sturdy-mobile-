-- Fix function search_path for get_monthly_script_count
CREATE OR REPLACE FUNCTION public.get_monthly_script_count(user_uuid UUID)
RETURNS INTEGER AS $$
  SELECT COUNT(*)::INTEGER
  FROM public.script_usage
  WHERE user_id = user_uuid
    AND used_at >= date_trunc('month', CURRENT_TIMESTAMP)
$$ LANGUAGE sql SECURITY DEFINER STABLE SET search_path = public;