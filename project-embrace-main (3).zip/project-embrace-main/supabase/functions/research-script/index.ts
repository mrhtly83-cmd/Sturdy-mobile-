import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { getCorsHeaders } from "../_shared/cors.ts";
import { verifyAuth } from "../_shared/auth.ts";
import { checkSubscriptionTier } from "../_shared/tier-check.ts";

serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth check
    const { userId, error: authError } = await verifyAuth(req);
    if (authError || !userId) {
      return new Response(JSON.stringify({ error: authError || "Authentication required" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Premium check
    const { isPremium, error: tierError } = await checkSubscriptionTier(userId);
    if (tierError || !isPremium) {
      return new Response(JSON.stringify({ error: "Premium subscription required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { situation, framework, childAge, neurotype } = await req.json();

    if (!situation) {
      return new Response(JSON.stringify({ error: "Situation is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const PERPLEXITY_API_KEY = Deno.env.get("PERPLEXITY_API_KEY");
    if (!PERPLEXITY_API_KEY) {
      console.error("PERPLEXITY_API_KEY is not configured");
      return new Response(JSON.stringify({
        summary: "Research is temporarily unavailable. The advice provided is based on established child development frameworks.",
        citations: [],
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const systemPrompt = `You are a child development researcher. Given a parenting situation and intervention approach, explain in 2-3 sentences why this approach works based on published research in developmental psychology, attachment theory, or neuroscience. Be specific about the mechanisms (e.g., co-regulation, neural pathways, attachment security). Do NOT give parenting advice — only explain the science behind why the described approach is effective.`;

    const userPrompt = `Situation: ${situation}
Framework/Approach used: ${framework || "attachment-based parenting"}
Child age: ${childAge || "school-age"}
Child neurotype: ${neurotype || "neurotypical"}

Why does this intervention approach work from a research perspective?`;

    const response = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${PERPLEXITY_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "sonar",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        search_domain_filter: [
          "pubmed.ncbi.nlm.nih.gov",
          "scholar.google.com",
          "apa.org",
          "zerotothree.org",
          "childmind.org",
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Perplexity API error:", response.status, errorText);
      return new Response(JSON.stringify({
        summary: "Research lookup is temporarily unavailable. Please try again later.",
        citations: [],
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const summary = data.choices?.[0]?.message?.content || "No research summary available.";
    
    // Extract citations from Perplexity response
    const rawCitations: string[] = data.citations || [];
    const citations = rawCitations.map((url: string) => {
      // Extract a readable title from the URL
      try {
        const parsed = new URL(url);
        const host = parsed.hostname.replace("www.", "");
        return { title: host, url };
      } catch {
        return { title: url, url };
      }
    });

    return new Response(JSON.stringify({ summary, citations }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("research-script error:", err);
    return new Response(JSON.stringify({
      error: err instanceof Error ? err.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
