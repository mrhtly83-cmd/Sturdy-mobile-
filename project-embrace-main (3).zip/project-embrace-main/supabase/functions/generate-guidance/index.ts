import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { corsHeaders } from "../_shared/cors.ts";
import { verifyAuth, scrubPII, restorePII } from "../_shared/auth.ts";
import { canAccessFeature } from "../_shared/tier-check.ts";
import { validateGuidanceRequest } from "../_shared/validation.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const OPENAI_URL = "https://api.openai.com/v1/chat/completions";

const SYSTEM_PROMPT = `
You are a warm, emotionally intelligent parenting language trainer.

Your method is always:
1. REGULATE the parent
2. CONNECT with the child
3. GUIDE with a clear boundary
4. Reinforce IDENTITY (separate child from behavior)

Voice:
- Use contractions.
- No clinical jargon.
- Short. Clear. Calm.
- No long lists.
- No lectures.
- No shame.

Return ONLY valid JSON (no markdown, no extra text) in this exact shape:
{
  "regulate": "...",
  "connect": "...",
  "guide": "...",
  "identity": "..."
}
`;

const NEUROTYPE_NOTES = `
Neurotype considerations:
- ADHD: Look for overwhelm + impulse + "can't stop" moments; keep it short, action-based.
- Autism: Look for sensory overwhelm or sudden routine changes; be concrete and predictable.
- PDA: Look for threat response to demands; use collaboration, autonomy, "I wonder if…".
- Anxiety: Look for need for control/safety; add reassurance and small choices.
`;

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function extractJsonObject(text: string) {
  const t = text.trim();
  try {
    return JSON.parse(t);
  } catch {
    const start = t.indexOf("{");
    const end = t.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(t.slice(start, end + 1));
    }
    throw new Error("Model did not return valid JSON.");
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    // 1) Auth
    const { userId, error: authError } = await verifyAuth(req);
    if (authError || !userId) return json(401, { error: authError || "Unauthorized" });

    // 2) Validate request
    const body = await req.json();
    const validation = validateGuidanceRequest(body);
    if (!validation.valid) return json(400, { error: "Invalid request", details: validation.errors });

    const { category, question, childAge, childName, neurotype } = body;

    // 3) Tier limits (guidance is premium-capped per your tier-check.ts)
    const accessCheck = await canAccessFeature(userId, "guidance");
    if (!accessCheck.allowed) {
      return json(402, {
        error: "Upgrade required",
        message: accessCheck.reason,
        used: accessCheck.used,
        limit: accessCheck.limit,
        remaining: accessCheck.remaining,
        resetDate: accessCheck.resetDate,
        code: accessCheck.code ?? "PAYWALL_REQUIRED",
        upgradeRequired: true,
      });
    }

    // 4) Scrub child name before AI
    const scrubbedQuestion = scrubPII(question, childName);

    // 5) Build prompt
    const userPrompt = `
CHILD AGE: ${childAge || "Unknown"}
NEUROTYPE: ${neurotype || "Neurotypical"}
CATEGORY: ${category || "Unspecified"}

PARENT QUESTION: "${scrubbedQuestion}"

${NEUROTYPE_NOTES}

Return the JSON object only.
`;

    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    if (!openaiKey) return json(500, { error: "Missing OPENAI_API_KEY in Supabase secrets." });

    // 6) Call OpenAI
    const resp = await fetch(OPENAI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.6,
      }),
    });

    if (!resp.ok) {
      const t = await resp.text();
      console.error("OpenAI error:", resp.status, t);
      return json(502, { error: "AI request failed", status: resp.status });
    }

    const data = await resp.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) return json(502, { error: "AI response missing content" });

    let guidance = extractJsonObject(content);

    // 7) Restore child name for display
    if (childName) {
      guidance.regulate = restorePII(guidance.regulate ?? "", childName);
      guidance.connect = restorePII(guidance.connect ?? "", childName);
      guidance.guide = restorePII(guidance.guide ?? "", childName);
      guidance.identity = restorePII(guidance.identity ?? "", childName);
    }

    // 8) Log usage (shares whatif_events pool per your tier-check.ts)
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    await supabase.from("whatif_events").insert({
      user_id: userId,
      scenario: scrubbedQuestion,
      child_age: childAge ?? null,
      neurotype: neurotype ?? null,
      category: category ?? null,
      type: "guidance",
    });

    return json(200, guidance);
  } catch (e) {
    console.error("generate-guidance error:", e);
    return json(500, { error: "Something went wrong." });
  }
});
