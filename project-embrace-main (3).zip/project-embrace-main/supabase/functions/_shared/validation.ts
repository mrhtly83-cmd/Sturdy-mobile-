/**
 * Input validation utilities for edge functions.
 * Prevents resource exhaustion and validates input formats.
 */

// Valid age ranges
const VALID_AGE_RANGES = ['0-2', '2-4', '4-6', '6-10', '10-13', '13+'];

// Valid neurotypes
const VALID_NEUROTYPES = [
  'neurotypical',
  'adhd',
  'audhd',
  'autism',
  'anxiety',
  'sensitive',
  'pda',
];

// Valid guidance categories
const VALID_CATEGORIES = [
  'warmth',
  'structure',
  'autonomy',
  'calm',
  'curiosity',
  'conversation',
];

// Max lengths for various fields
const MAX_LENGTHS = {
  situation: 1000,
  question: 500,
  scenario: 500,
  childName: 50,
};

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Validates a string field for length and control characters.
 */
function validateString(
  value: unknown,
  fieldName: string,
  maxLength: number,
  required: boolean = true
): string[] {
  const errors: string[] = [];

  if (value === undefined || value === null || value === '') {
    if (required) {
      errors.push(`${fieldName} is required`);
    }
    return errors;
  }

  if (typeof value !== 'string') {
    errors.push(`${fieldName} must be a string`);
    return errors;
  }

  if (value.length > maxLength) {
    errors.push(`${fieldName} must be less than ${maxLength} characters`);
  }

  // Check for null bytes and other dangerous control characters
  if (/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(value)) {
    errors.push(`${fieldName} contains invalid characters`);
  }

  return errors;
}

/**
 * Validates enum value against allowed list.
 */
function validateEnum(
  value: unknown,
  fieldName: string,
  allowedValues: string[],
  required: boolean = true
): string[] {
  const errors: string[] = [];

  if (value === undefined || value === null || value === '') {
    if (required) {
      errors.push(`${fieldName} is required`);
    }
    return errors;
  }

  if (typeof value !== 'string') {
    errors.push(`${fieldName} must be a string`);
    return errors;
  }

  if (!allowedValues.includes(value)) {
    errors.push(`${fieldName} must be one of: ${allowedValues.join(', ')}`);
  }

  return errors;
}

/**
 * Validates tone value (0-100).
 */
function validateTone(value: unknown): string[] {
  const errors: string[] = [];

  if (value === undefined || value === null) {
    return errors; // Tone is optional
  }

  if (typeof value !== 'number') {
    errors.push('tone must be a number');
    return errors;
  }

  if (value < 0 || value > 100) {
    errors.push('tone must be between 0 and 100');
  }

  return errors;
}

/**
 * Validates crisis script request body.
 */
export function validateCrisisRequest(body: Record<string, unknown>): ValidationResult {
  const errors: string[] = [];

  errors.push(...validateString(body.situation, 'situation', MAX_LENGTHS.situation));
  errors.push(...validateEnum(body.childAge, 'childAge', VALID_AGE_RANGES));
  errors.push(...validateEnum(body.neurotype, 'neurotype', VALID_NEUROTYPES, false));
  errors.push(...validateString(body.childName, 'childName', MAX_LENGTHS.childName, false));

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validates script generation request body.
 */
export function validateScriptRequest(body: Record<string, unknown>): ValidationResult {
  const errors: string[] = [];

  errors.push(...validateString(body.situation, 'situation', MAX_LENGTHS.situation));
  errors.push(...validateTone(body.tone));
  errors.push(...validateEnum(body.childAge, 'childAge', VALID_AGE_RANGES, false));
  errors.push(...validateEnum(body.neurotype, 'neurotype', VALID_NEUROTYPES, false));
  errors.push(...validateString(body.childName, 'childName', MAX_LENGTHS.childName, false));

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validates guidance request body.
 */
export function validateGuidanceRequest(body: Record<string, unknown>): ValidationResult {
  const errors: string[] = [];

  errors.push(...validateEnum(body.category, 'category', VALID_CATEGORIES));
  errors.push(...validateString(body.question, 'question', MAX_LENGTHS.question));
  errors.push(...validateEnum(body.childAge, 'childAge', VALID_AGE_RANGES, false));
  errors.push(...validateString(body.childName, 'childName', MAX_LENGTHS.childName, false));
  errors.push(...validateEnum(body.neurotype, 'neurotype', VALID_NEUROTYPES, false));

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validates proactive/what-if request body.
 */
export function validateProactiveRequest(body: Record<string, unknown>): ValidationResult {
  const errors: string[] = [];

  errors.push(...validateString(body.scenario, 'scenario', MAX_LENGTHS.scenario));
  errors.push(...validateEnum(body.childAge, 'childAge', VALID_AGE_RANGES, false));
  errors.push(...validateEnum(body.neurotype, 'neurotype', VALID_NEUROTYPES, false));
  errors.push(...validateString(body.childName, 'childName', MAX_LENGTHS.childName, false));

  return {
    valid: errors.length === 0,
    errors,
  };
}
