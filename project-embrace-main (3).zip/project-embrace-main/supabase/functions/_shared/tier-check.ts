import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const PREMIUM_TIERS = [
  "premium",
  "weekly",
  "monthly",
  "annual",
  "lifetime",
  "complete",
] as const;

export const FREE_TIER_LIMITS = {
  // Crisis is intentionally unlimited for Free
  crisis: Number.POSITIVE_INFINITY,
  // Guidance + What-if share a combined cap via whatif_events
  guidance: 3,
  whatif: 3,
} as const;

export type UsageType = "crisis" | "guidance" | "whatif";

function getSupabaseAdmin() {
  return createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );
}

function startOfCurrentMonth(): Date {
  const d = new Date();
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
}

function startOfNextMonth(): Date {
  const d = startOfCurrentMonth();
  d.setMonth(d.getMonth() + 1);
  return d;
}

export async function checkSubscriptionTier(
  userId: string
): Promise<{
  isPremium: boolean;
  tier: string;
  error: string | null;
}> {
  const supabase = getSupabaseAdmin();

  const { data: profile, error } = await supabase
    .from("profiles")
    .select("subscription_tier")
    .eq("id", userId)
    .single();

  if (error) {
    console.error("Error fetching profile:", error);
    return { isPremium: false, tier: "free", error: error.message };
  }

  const tier = profile?.subscription_tier || "free";
  const isPremium = PREMIUM_TIERS.includes(tier as any);

  return { isPremium, tier, error: null };
}

export async function checkUsageLimits(
  userId: string,
  usageType: UsageType
): Promise<{
  used: number;
  limit: number;
  remaining: number;
  resetDate: string;
  limitReached: boolean;
  error: string | null;
}> {
  // Crisis is unlimited on Free: skip counting
  if (usageType === "crisis") {
    return {
      used: 0,
      limit: Number.POSITIVE_INFINITY,
      remaining: Number.POSITIVE_INFINITY,
      resetDate: startOfNextMonth().toISOString(),
      limitReached: false,
      error: null,
    };
  }

  const supabase = getSupabaseAdmin();
  const limit = FREE_TIER_LIMITS[usageType];

  // guidance + whatif share the same pool
  const table = "whatif_events";

  const { count, error } = await supabase
    .from(table)
    .select("*", { count: "exact", head: true })
    .eq("user_id", userId)
    .gte("created_at", startOfCurrentMonth().toISOString());

  if (error) {
    console.error("Error checking usage:", error);
    return {
      used: 0,
      limit,
      remaining: limit,
      resetDate: startOfNextMonth().toISOString(),
      limitReached: false,
      error: error.message,
    };
  }

  const used = count || 0;
  const remaining = Math.max(0, limit - used);

  return {
    used,
    limit,
    remaining,
    resetDate: startOfNextMonth().toISOString(),
    limitReached: used >= limit,
    error: null,
  };
}

export async function canAccessFeature(
  userId: string,
  usageType: UsageType
): Promise<{
  allowed: boolean;
  code?: "PAYWALL_REQUIRED" | "TEMPORARILY_UNAVAILABLE";
  reason: string | null;
  used: number;
  limit: number;
  remaining?: number;
  resetDate?: string;
  isPremium: boolean;
}> {
  // Crisis is always allowed
  if (usageType === "crisis") {
    return { allowed: true, reason: null, used: 0, limit: 0, isPremium: false };
  }

  const { isPremium, error: tierError } = await checkSubscriptionTier(userId);

  if (tierError) {
    return {
      allowed: false,
      code: "TEMPORARILY_UNAVAILABLE",
      reason:
        "We couldn’t verify your access right now. Please try again in a moment.",
      used: 0,
      limit: FREE_TIER_LIMITS[usageType],
      isPremium: false,
    };
  }

  if (isPremium) {
    return { allowed: true, reason: null, used: 0, limit: 0, isPremium: true };
  }

  const { used, limit, remaining, resetDate, limitReached, error: usageError } =
    await checkUsageLimits(userId, usageType);

  if (usageError) {
    return {
      allowed: false,
      code: "TEMPORARILY_UNAVAILABLE",
      reason:
        "We couldn’t check your usage right now. Please try again in a moment.",
      used: 0,
      limit,
      remaining,
      resetDate,
      isPremium: false,
    };
  }

  if (limitReached) {
    return {
      allowed: false,
      code: "PAYWALL_REQUIRED",
      reason: `You’ve used ${used}/${limit} free scripts this month. Upgrade to keep going.`,
      used,
      limit,
      remaining,
      resetDate,
      isPremium: false,
    };
  }

  return {
    allowed: true,
    reason: null,
    used,
    limit,
    remaining,
    resetDate,
    isPremium: false,
  };
}
