import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

/**
 * Verifies authentication for edge function requests.
 * Returns user ID if authenticated, null otherwise.
 * Uses getUser(token) for Lovable Cloud compatibility (ES256 signing).
 */
export async function verifyAuth(req: Request): Promise<{ userId: string | null; error: string | null }> {
  const authHeader = req.headers.get("Authorization");
  
  if (!authHeader?.startsWith("Bearer ")) {
    return { userId: null, error: "Authentication required" };
  }

  const token = authHeader.replace("Bearer ", "");

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? "",
    { global: { headers: { Authorization: authHeader } } }
  );

  // CRITICAL: Pass token explicitly for Lovable Cloud (ES256 signing)
  const { data: { user }, error } = await supabaseClient.auth.getUser(token);
  
  if (error || !user) {
    return { userId: null, error: "Invalid authentication" };
  }

  return { userId: user.id, error: null };
}

/**
 * Scrubs PII (child names) from text before sending to AI APIs.
 * Replaces names with [CHILD] placeholder.
 */
export function scrubPII(text: string, childName?: string): string {
  if (!text) return text;
  
  let scrubbed = text;
  
  // Replace provided child name with placeholder
  if (childName && childName.trim()) {
    const nameRegex = new RegExp(childName.trim(), "gi");
    scrubbed = scrubbed.replace(nameRegex, "[CHILD]");
  }
  
  return scrubbed;
}

/**
 * Restores child name in AI response by replacing placeholder.
 */
export function restorePII(text: string, childName?: string): string {
  if (!text || !childName) return text;
  return text.replace(/\[CHILD\]/gi, childName);
}
