/**
 * CORS configuration for edge functions.
 * Restricts origins to known application domains.
 */

// Allowed origins - Expo dev client, dev tools, and mobile deep-link schemes
export const ALLOWED_ORIGINS = [
  // Expo dev client / expo dev tools
  'exp://127.0.0.1:19000',
  'http://localhost:19006',
  'http://localhost:19000',
  'http://localhost:8080',
  // TODO: Replace with your actual production web domain
  'https://app.example.com',
];

/**
 * Get CORS headers with dynamic origin checking.
 * Returns the origin if it's in the allowed list, otherwise returns the first allowed origin.
 */
export function getCorsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get('Origin') || '';

  // Check if origin is in allowed list, is an Expo dev URL, or is the mobile deep-link scheme
  const isAllowed = ALLOWED_ORIGINS.includes(origin) ||
    origin.startsWith('exp://') ||
    origin.startsWith('sturdy://');

  const allowedOrigin = isAllowed ? origin : ALLOWED_ORIGINS[0];

  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };
}

/**
 * Static CORS headers for OPTIONS preflight requests.
 * Uses wildcard for preflight to avoid CORS errors during development.
 */
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
