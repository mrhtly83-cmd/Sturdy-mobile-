import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { corsHeaders, getCorsHeaders } from "../_shared/cors.ts";
import { verifyAuth } from "../_shared/auth.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.48.0";

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const headers = getCorsHeaders(req);

  try {
    const { userId, error: authError } = await verifyAuth(req);
    if (authError || !userId) {
      return new Response(
        JSON.stringify({ error: authError || "Authentication required" }),
        { status: 401, headers: { ...headers, "Content-Type": "application/json" } },
      );
    }

    const body = await req.json().catch(() => ({}));
    const { scriptId, feedback, tag } = body as {
      scriptId?: string;
      feedback?: "up" | "down";
      tag?: "too_soft" | "too_firm" | "off_topic";
    };

    if (!scriptId || (!feedback && !tag)) {
      return new Response(
        JSON.stringify({ error: "scriptId and at least one of feedback or tag are required" }),
        { status: 400, headers: { ...headers, "Content-Type": "application/json" } },
      );
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false },
    });

    const { error } = await supabase.from("script_feedback").insert({
      user_id: userId,
      script_id: scriptId,
      feedback: feedback ?? null,
      tag: tag ?? null,
    });

    if (error) {
      console.error("Insert feedback error:", error);
      return new Response(
        JSON.stringify({ error: "Failed to record feedback" }),
        { status: 500, headers: { ...headers, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { ...headers, "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error("record-script-feedback error:", e);
    return new Response(
      JSON.stringify({ error: "Unexpected error" }),
      { status: 500, headers: { ...headers, "Content-Type": "application/json" } },
    );
  }
});
