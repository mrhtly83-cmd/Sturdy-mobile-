import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders, getCorsHeaders } from "../_shared/cors.ts";
import { verifyAuth, scrubPII, restorePII } from "../_shared/auth.ts";
import { validateScriptRequest } from "../_shared/validation.ts";

const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";

function getSupabaseAdmin() {
  return createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );
}

// Unified fallback (crisis)
const FALLBACK_RESPONSE = {
  mode: "crisis",
  script: {
    regulate: "Take one breath. You’re in control.",
    connect: "I won’t let you do that. Something big is happening.",
    guide: "Hands down. Use words—tell me what happened.",
    identity: "You’re a kid who can handle big feelings safely.",
  },
  repair: "If I raised my voice, I’m sorry. I’m working on staying calm.",
  foundationTag: "Safety + Connection",
  deliveryTips: ["Voice: low and slow", "Body: open hands, block gently"],
};

const TOOL_DEFINITION = {
  type: "function" as const,
  function: {
    name: "generate_crisis",
    description:
      "Generate a structured crisis script using Regulate → Connect → Guide → Identity.",
    parameters: {
      type: "object",
      properties: {
        mode: { type: "string", enum: ["crisis"] },
        script: {
          type: "object",
          properties: {
            regulate: { type: "string" },
            connect: { type: "string" },
            guide: { type: "string" },
            identity: { type: "string" },
          },
          required: ["regulate", "connect", "guide", "identity"],
        },
        repair: { type: "string", default: "" },
        foundationTag: { type: "string" },
        deliveryTips: {
          type: "array",
          items: { type: "string" },
          minItems: 2,
          maxItems: 2,
        },
      },
      required: ["mode", "script", "foundationTag", "deliveryTips"],
      additionalProperties: false,
    },
  },
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const responseCorsHeaders = getCorsHeaders(req);

  try {
    // 1) Auth
    const { userId, error: authError } = await verifyAuth(req);
    if (authError || !userId) {
      return new Response(
        JSON.stringify({ error: authError || "Authentication required" }),
        {
          status: 401,
          headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // 2) Validate
    const body = await req.json();
    const validation = validateScriptRequest(body);
    if (!validation.valid) {
      return new Response(
        JSON.stringify({ error: "Invalid request", details: validation.errors }),
        {
          status: 400,
          headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { situation, tone, childAge, neurotype, childName, category } = body;

    // 3) Crisis is unlimited: NO paywall check here

    // 4) Scrub PII
    const scrubbedSituation = scrubPII(situation, childName);

    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
    if (!OPENAI_API_KEY) {
      // No key configured → safe fallback
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // 5) Tone mapping (calm + firm baseline)
    let toneLabel = "calm and firm";
    let toneInstruction =
      "Be calm, firm, and short. Hold the boundary without shame. Use gentle curiosity after the boundary.";

    if (typeof tone === "number") {
      if (tone <= 20) {
        toneLabel = "very gentle, calm, steady";
        toneInstruction =
          "Be calm and gentle. Keep boundary firm but soft. Use minimal words.";
      } else if (tone >= 80) {
        toneLabel = "calm, firm, direct";
        toneInstruction =
          "Be calm and firm. Use clear, direct language. Still no shame or threats.";
      }
    }

    // 6) Neurotype adjustments (light touch)
    const neuroGuidanceMap: Record<string, string> = {
      adhd: "Keep it brief and action-oriented. One clear direction.",
      audhd: "Be concrete and predictable. Avoid rapid questions.",
      autism: "Use literal language. Predictable phrasing. No fast follow-up questions.",
      anxiety: "Add reassurance of safety. Keep tone steady.",
      sensitive: "Gentle tone. Brief validation, then direction.",
      pda: "Avoid demands. Use calm boundary + invitational phrasing after safety.",
    };
    const neuroGuidance = neurotype ? neuroGuidanceMap[neurotype] || "" : "";

    const systemPrompt = `You are Sturdy: thoughtful, calm, steady, warm.

CRISIS MODE:
- Purpose: direct boundary support while protecting connection.
- Order: REGULATE (parent) → BOUNDARY + brief curiosity → REDIRECT → IDENTITY.
- NO consequences. NO lectures. NO threats. NO shame.
- Avoid "Why did you...". Prefer "What happened?" / "Tell me what’s going on."
- Keep each line short. Under ~18 words for kids under 10.

VOICE:
- Use contractions.
- No therapy-speak. No clinical jargon. No "I notice..." language.

CHILD CONTEXT:
Age: ${childAge || "unspecified"}
Neurotype: ${neurotype || "neurotypical"}
${neuroGuidance ? `Note: ${neuroGuidance}` : ""}

TONE: ${toneLabel}
Instruction: ${toneInstruction}

Return ONLY via the function tool schema.`;

    const userPrompt = `SITUATION: "${scrubbedSituation}"
${category ? `CATEGORY: ${category}` : ""}

Generate the crisis script now.`;

    // 7) OpenAI call (function/tool calling)
    const response = await fetch(OPENAI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [TOOL_DEFINITION],
        tool_choice: { type: "function", function: { name: "generate_crisis" } },
        temperature: 0.35, // consistency for crisis
      }),
    });

    if (!response.ok) {
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data?.choices?.[0]?.message?.tool_calls?.[0];

    if (!toolCall?.function?.arguments) {
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    let crisisData: any;
    try {
      crisisData = JSON.parse(toolCall.function.arguments);
    } catch {
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // 8) Restore child name
    if (childName) {
      crisisData.script.regulate = restorePII(crisisData.script.regulate, childName);
      crisisData.script.connect = restorePII(crisisData.script.connect, childName);
      crisisData.script.guide = restorePII(crisisData.script.guide, childName);
      crisisData.script.identity = restorePII(crisisData.script.identity, childName);
      if (crisisData.repair) crisisData.repair = restorePII(crisisData.repair, childName);
    }

    // 9) Record crisis event (optional but recommended; does not gate)
    try {
      const supabase = getSupabaseAdmin();
      await supabase.from("crisis_events").insert({
        user_id: userId,
        situation: scrubbedSituation,
        child_age: childAge,
        neurotype: neurotype,
        category: category ?? null,
      });
    } catch (e) {
      console.warn("Failed to record crisis event:", e);
    }

    return new Response(JSON.stringify(crisisData), {
      headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(JSON.stringify(FALLBACK_RESPONSE), {
      headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
    });
  }
});
