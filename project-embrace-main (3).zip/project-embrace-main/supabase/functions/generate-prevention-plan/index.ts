import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders, getCorsHeaders } from "../_shared/cors.ts";
import { verifyAuth, scrubPII } from "../_shared/auth.ts";
import { checkSubscriptionTier } from "../_shared/tier-check.ts";

const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";

function getSupabaseAdmin() {
  return createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  );
}

// -------------------------------
// Fallbacks
// -------------------------------
const FALLBACK_FREE = {
  isPremium: false,
  teaserTip:
    "Pick one tiny prevention step you can repeat daily. Consistency beats intensity.",
};

const FALLBACK_PREMIUM = {
  isPremium: true,
  mode: "whatif",
  patternInsight: "Looks like this has been coming up lately. You're not alone.",
  preScript: "Before things escalate, I’m going to help you. Hands stay safe.",
  environmentShift: "Separate bodies early—give each child a clear space and task.",
  boundaryPlan: "If it starts again, we pause and reset together. Then we try again.",
  practicePrompt: "Practice this once today during a calm moment—short, steady, and kind.",
  foundationTag: "Proactive Structure",
  teaserTip:
    "Practice the plan when you’re calm. In the moment, your child can’t learn new words.",
};

// -------------------------------
// Tool schema (aligned with A+B+C)
// -------------------------------
const TOOL_DEFINITION = {
  type: "function" as const,
  function: {
    name: "generate_whatif",
    description:
      "Generate a structured What-If plan: preScript + environmentShift + boundaryPlan + optional pattern insight.",
    parameters: {
      type: "object",
      properties: {
        mode: { type: "string", enum: ["whatif"] },
        patternInsight: {
          type: "string",
          description:
            "One gentle observational line. No numbers/stats. Only include when repeatCount > 0.",
        },
        preScript: {
          type: "string",
          description: "One short sentence said BEFORE escalation (practice line).",
        },
        environmentShift: {
          type: "string",
          description: "One practical change (space/routine/transition) to reduce the trigger.",
        },
        boundaryPlan: {
          type: "string",
          description: "One calm, predictable boundary if behavior repeats (no threats).",
        },
        practicePrompt: {
          type: "string",
          description: "One short instruction for when/how to practice this plan.",
        },
        foundationTag: {
          type: "string",
          description: "Short label like 'Proactive Structure' or 'Connection Repair'.",
        },
        teaserTip: {
          type: "string",
          description: "A short universal tip (15-20 words).",
        },
      },
      required: [
        "mode",
        "preScript",
        "environmentShift",
        "boundaryPlan",
        "practicePrompt",
        "foundationTag",
        "teaserTip",
      ],
      additionalProperties: false,
    },
  },
};

// -------------------------------
// Helpers
// -------------------------------
function daysAgoISO(days: number) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString();
}

async function getRepeatContext(params: {
  userId: string;
  category?: string;
  childAge?: string;
  neurotype?: string;
}) {
  const supabase = getSupabaseAdmin();

  // Count events in last 7 days
  let countQ = supabase
    .from("whatif_events")
    .select("id", { count: "exact", head: true })
    .eq("user_id", params.userId)
    .gte("created_at", daysAgoISO(7));

  if (params.category) countQ = countQ.eq("category", params.category);
  if (params.childAge) countQ = countQ.eq("child_age", params.childAge);
  if (params.neurotype) countQ = countQ.eq("neurotype", params.neurotype);

  const { count, error: countError } = await countQ;

  if (countError) {
    console.warn("Repeat count query failed:", countError);
    return { repeatCount: 0, lastSeenAt: null as string | null };
  }

  // Get lastSeenAt (most recent event)
  let lastQ = supabase
    .from("whatif_events")
    .select("created_at")
    .eq("user_id", params.userId)
    .gte("created_at", daysAgoISO(7));

  if (params.category) lastQ = lastQ.eq("category", params.category);
  if (params.childAge) lastQ = lastQ.eq("child_age", params.childAge);
  if (params.neurotype) lastQ = lastQ.eq("neurotype", params.neurotype);

  const { data: lastData, error: lastError } = await lastQ
    .order("created_at", { ascending: false })
    .limit(1);

  if (lastError) {
    console.warn("LastSeen query failed:", lastError);
    return { repeatCount: count ?? 0, lastSeenAt: null as string | null };
  }

  return {
    repeatCount: count ?? 0,
    lastSeenAt: lastData?.[0]?.created_at ?? null,
  };
}

// -------------------------------
// Main handler
// -------------------------------
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const responseCorsHeaders = getCorsHeaders(req);

  try {
    // Optional warning (won’t block): service key needed for logging + repeat detection
    if (!Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")) {
      console.warn("Missing SUPABASE_SERVICE_ROLE_KEY (repeat detection/logging may fail).");
    }

    // 1) Auth
    const { userId, error: authError } = await verifyAuth(req);
    if (authError || !userId) {
      return new Response(JSON.stringify(FALLBACK_FREE), {
        status: 200,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // 2) Premium status
    const { isPremium } = await checkSubscriptionTier(userId);

    // 3) Parse request
    const body = await req.json();
    const { situation, childAge, neurotype, category } = body;

    if (!situation) {
      return new Response(JSON.stringify({ error: "Missing situation" }), {
        status: 400,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    const scrubbedSituation = scrubPII(situation, undefined);

    // 4) Free users -> teaser only
    if (!isPremium) {
      const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
      if (!OPENAI_API_KEY) {
        return new Response(JSON.stringify(FALLBACK_FREE), {
          status: 200,
          headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
        });
      }

      const teaserPrompt = `Based on this parenting situation: "${scrubbedSituation}"
Return ONE practical prevention tip (15-20 words). No quotes. No formatting.`;

      const teaserResponse = await fetch(OPENAI_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: "You are Sturdy: thoughtful, calm, practical. Give one short tip." },
            { role: "user", content: teaserPrompt },
          ],
          temperature: 0.5,
          max_tokens: 60,
        }),
      });

      if (teaserResponse.ok) {
        const teaserData = await teaserResponse.json();
        const teaserTip =
          teaserData.choices?.[0]?.message?.content?.trim() || FALLBACK_FREE.teaserTip;

        return new Response(JSON.stringify({ isPremium: false, teaserTip }), {
          status: 200,
          headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify(FALLBACK_FREE), {
        status: 200,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // 5) Premium: intelligent What-If
    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
    if (!OPENAI_API_KEY) {
      return new Response(JSON.stringify(FALLBACK_PREMIUM), {
        status: 200,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    const { repeatCount } = await getRepeatContext({
      userId,
      category,
      childAge,
      neurotype,
    });

    const systemPrompt = `You are Sturdy: thoughtful, calm, steady, warm.

You generate a structured What-If plan to prevent repeated hard moments.

VOICE:
- Calm, measured, practical.
- No shame. No lectures. No therapy-speak.
- Short sentences.

OUTPUT:
Return ONLY valid JSON using the function tool.

RULES:
- preScript: one sentence said BEFORE escalation.
- environmentShift: one practical change (space/routine/transition).
- boundaryPlan: one calm, predictable boundary (no threats).
- practicePrompt: one line when/how to rehearse.
- patternInsight: only if repeatCount > 0. Gentle, no numbers.
- teaserTip: 15-20 words universal advice.`;

    const userPrompt = `SITUATION: "${scrubbedSituation}"
CHILD AGE: ${childAge || "unspecified"}
NEUROTYPE: ${neurotype || "neurotypical"}
CATEGORY: ${category || "unspecified"}

repeatCount (last 7 days) = ${repeatCount}

If repeatCount >= 2, strengthen structure slightly (clearer boundaryPlan + simpler environmentShift).
If repeatCount >= 3, include a gentle patternInsight line that stays curious (no stats).

Generate the What-If plan now.`;

    const response = await fetch(OPENAI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [TOOL_DEFINITION],
        tool_choice: { type: "function", function: { name: "generate_whatif" } },
        temperature: 0.5,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("OpenAI error:", response.status, errorText);
      return new Response(JSON.stringify(FALLBACK_PREMIUM), {
        status: 200,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];

    if (!toolCall?.function?.arguments) {
      return new Response(JSON.stringify(FALLBACK_PREMIUM), {
        status: 200,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    let plan: any;
    try {
      plan = JSON.parse(toolCall.function.arguments);
    } catch {
      return new Response(JSON.stringify(FALLBACK_PREMIUM), {
        status: 200,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // Ensure patternInsight only when repeated
    if (!repeatCount || repeatCount === 0) {
      delete plan.patternInsight;
    } else if (!plan.patternInsight) {
      plan.patternInsight =
        "Looks like this has been coming up lately. Let’s make the plan simpler and steadier.";
    }

    // Log event (best effort)
    try {
      const supabase = getSupabaseAdmin();
      await supabase.from("whatif_events").insert({
        user_id: userId,
        scenario: scrubbedSituation,
        child_age: childAge ?? null,
        neurotype: neurotype ?? null,
        category: category ?? null,
      });
    } catch (e) {
      console.warn("Failed to log whatif event:", e);
    }

    return new Response(JSON.stringify({ isPremium: true, ...plan }), {
      status: 200,
      headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(JSON.stringify(FALLBACK_FREE), {
      status: 200,
      headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
    });
  }
});