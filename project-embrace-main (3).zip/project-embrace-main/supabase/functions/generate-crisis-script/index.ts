import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders, getCorsHeaders } from "../_shared/cors.ts";
import { verifyAuth, scrubPII, restorePII } from "../_shared/auth.ts";
import { checkSubscriptionTier } from "../_shared/tier-check.ts";

const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";

// ============================================================================
// AGE BAND LOGIC
// ============================================================================

type AgeBand = "toddler" | "school" | "preteen" | "teen";

function getAgeBand(childAge: string): AgeBand {
  if (["2-4"].includes(childAge)) return "toddler";
  if (["4-6", "6-10"].includes(childAge)) return "school";
  if (["10-13"].includes(childAge)) return "preteen";
  return "teen";
}

function getAgeProfile(band: AgeBand): string {
  switch (band) {
    case "toddler":
      return `AGE: Toddler (2-4)
- Very short phrases (6-12 words)
- Safety + co-regulation first
- One simple question max ("What happened?")`;

    case "school":
      return `AGE: School-age (5-9)
- Short phrases (8-16 words)
- Safety boundary first, then brief curiosity
- Keep it simple and steady`;

    case "preteen":
      return `AGE: Preteen (10-12)
- Calm, firm, respectful language
- Brief curiosity after boundary
- No lectures`;

    case "teen":
      return `AGE: Teen (13+)
- Calm authority, no baby talk
- Respect autonomy while holding boundary
- Brief curiosity, invite reset`;
  }
}

// ============================================================================
// NEUROTYPE PROFILES
// ============================================================================

function getNeurotypeGuidance(neurotype: string): string {
  const profiles: Record<string, string> = {
    pda: "NEUROTYPE: PDA - Avoid demands. Use calm, collaborative language after safety boundary.",
    autism: "NEUROTYPE: Autism - Concrete, predictable language. Avoid rapid questions.",
    anxiety: "NEUROTYPE: Anxiety - Extra safety reassurance. Calm, steady tone.",
    sensitive: "NEUROTYPE: Highly Sensitive - Gentle tone. Acknowledge overwhelm briefly.",
    adhd: "NEUROTYPE: ADHD - Action-oriented, brief. Give one clear direction.",
    audhd: "NEUROTYPE: ADHD + Autism - Structured + sensory-aware. Keep it concrete.",
  };
  return profiles[neurotype] || "";
}

// ============================================================================
// TOOL SCHEMA (Unified Crisis Output)
// ============================================================================

const TOOL_DEFINITION = {
  type: "function" as const,
  function: {
    name: "generate_crisis",
    description:
      "Generate a structured crisis script using Regulate → Connect → Guide → Identity.",
    parameters: {
      type: "object",
      properties: {
        mode: { type: "string", enum: ["crisis"] },
        script: {
          type: "object",
          properties: {
            regulate: {
              type: "string",
              description: "One grounding line for the parent.",
            },
            connect: {
              type: "string",
              description:
                "Connection + containment line (includes the boundary).",
            },
            guide: {
              type: "string",
              description: "Clear redirection (no consequences).",
            },
            identity: {
              type: "string",
              description:
                "Identity reinforcement (separate child from behavior).",
            },
          },
          required: ["regulate", "connect", "guide", "identity"],
        },
        repair: {
          type: "string",
          description: "Optional short repair line if parent escalated.",
          default: "",
        },
        foundationTag: {
          type: "string",
          description: "Short label like 'Safety + Connection'.",
        },
        deliveryTips: {
          type: "array",
          items: { type: "string" },
          description: "2 short delivery tips (voice/body).",
          minItems: 2,
          maxItems: 2,
        },
        // Premium-only extras (optional, keep voice consistent)
        whyItWorks: {
          type: "string",
          description: "2 short sentences, accessible.",
          default: "",
        },
        proactiveFollowUp: {
          type: "string",
          description: "One simple prevention step.",
          default: "",
        },
      },
      required: ["mode", "script", "foundationTag", "deliveryTips"],
      additionalProperties: false,
    },
  },
};

// ============================================================================
// SYSTEM PROMPT
// ============================================================================

const SYSTEM_PROMPT = `
You are Sturdy: a thoughtful, calm, steady, warm parenting language trainer.

CRISIS MODE RULES:
- Voice is calm + firm. Short. Clear. No shame.
- Do NOT give consequences. Do NOT lecture.
- Structure is always: REGULATE → (BOUNDARY + CURIOSITY) → REDIRECT → IDENTITY
- Curiosity must be invitational, not interrogating. Prefer: "What happened?" / "Tell me what's going on."
- Avoid "Why did you..." in crisis.

STYLE:
- Use contractions.
- Keep each line under ~18 words for kids under 10.
- No therapy-speak. No clinical jargon. No "I notice..." language.
- Do not call the child bad. Separate behavior from identity.

Return ONLY via the function tool schema.
`;

// Premium prompt just adds optional fields; voice stays identical.
const PREMIUM_SYSTEM_PROMPT = `${SYSTEM_PROMPT}
If premium, also include whyItWorks (2 short sentences) and proactiveFollowUp (one simple step).`;

// ============================================================================
// FALLBACK SCRIPT (Unified)
// ============================================================================

const FALLBACK_RESPONSE = {
  mode: "crisis",
  script: {
    regulate: "Take one breath. You’re in control.",
    connect: "I won’t let you hit. Something big is happening.",
    guide: "Hands down. Use words—tell me what happened.",
    identity: "You’re a kid who can handle big feelings safely.",
  },
  repair: "If I raised my voice, I’m sorry. I’m working on staying calm.",
  foundationTag: "Safety + Connection",
  deliveryTips: ["Voice: low and slow", "Body: open hands, block gently"],
  whyItWorks: "",
  proactiveFollowUp: "",
};

// ============================================================================
// MAIN HANDLER
// ============================================================================

function getSupabaseAdmin() {
  return createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const responseCorsHeaders = getCorsHeaders(req);

  try {
    // 1) Auth
    const { userId, error: authError } = await verifyAuth(req);
    if (authError || !userId) {
      return new Response(
        JSON.stringify({ error: authError || "Authentication required" }),
        {
          status: 401,
          headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // 2) Premium status (Crisis is unlimited either way; premium just adds optional fields)
    const { isPremium } = await checkSubscriptionTier(userId);

    // 3) Parse request
    const body = await req.json();
    const { situation, childAge, neurotype, childName, category } = body;

    if (!situation) {
      return new Response(JSON.stringify({ error: "Missing situation" }), {
        status: 400,
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // 4) Scrub PII
    const scrubbedSituation = scrubPII(situation, childName);

    // 5) Profiles
    const ageBand = getAgeBand(childAge || "6-10");
    const ageProfile = getAgeProfile(ageBand);
    const neurotypeGuidance = getNeurotypeGuidance(neurotype || "neurotypical");

    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
    if (!OPENAI_API_KEY) {
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // 6) Prompt
    const userPrompt = `${ageProfile}

${neurotypeGuidance}

${category ? `CRISIS CATEGORY: ${category}` : ""}

SITUATION: "${scrubbedSituation}"

Generate a crisis script.
Remember: Boundary first, then gentle curiosity, then redirection, then identity.
No consequences. No lectures. Keep it short.`;

    // 7) OpenAI call (tool-based)
    const response = await fetch(OPENAI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: isPremium ? PREMIUM_SYSTEM_PROMPT : SYSTEM_PROMPT,
          },
          { role: "user", content: userPrompt },
        ],
        tools: [TOOL_DEFINITION],
        tool_choice: { type: "function", function: { name: "generate_crisis" } },
        temperature: 0.35,
      }),
    });

    if (!response.ok) {
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data?.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    let crisisData: any;
    try {
      crisisData = JSON.parse(toolCall.function.arguments);
    } catch {
      return new Response(JSON.stringify(FALLBACK_RESPONSE), {
        headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
      });
    }

    // 8) Restore PII
    if (childName && crisisData?.script) {
      crisisData.script.regulate = restorePII(crisisData.script.regulate, childName);
      crisisData.script.connect = restorePII(crisisData.script.connect, childName);
      crisisData.script.guide = restorePII(crisisData.script.guide, childName);
      crisisData.script.identity = restorePII(crisisData.script.identity, childName);

      if (crisisData.repair) crisisData.repair = restorePII(crisisData.repair, childName);
      if (crisisData.whyItWorks)
        crisisData.whyItWorks = restorePII(crisisData.whyItWorks, childName);
      if (crisisData.proactiveFollowUp)
        crisisData.proactiveFollowUp = restorePII(
          crisisData.proactiveFollowUp,
          childName
        );
    }

    // 9) Record crisis event (analytics/patterns; no gating)
    try {
      const supabase = getSupabaseAdmin();
      await supabase.from("crisis_events").insert({
        user_id: userId,
        // store scrubbed text to reduce risk if you ever export logs
        situation: scrubbedSituation,
        child_age: childAge,
        neurotype: neurotype,
        category: category ?? null,
      });
    } catch (e) {
      // Do not fail the request if logging fails
      console.warn("Failed to record crisis event:", e);
    }

    return new Response(JSON.stringify(crisisData), {
      headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(JSON.stringify(FALLBACK_RESPONSE), {
      headers: { ...responseCorsHeaders, "Content-Type": "application/json" },
    });
  }
});
