import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders, getCorsHeaders } from "../_shared/cors.ts";
import { verifyAuth, scrubPII, restorePII } from "../_shared/auth.ts";
import { canAccessFeature } from "../_shared/tier-check.ts";

const OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";

// ============================================================================
// TOOL SCHEMA
// ============================================================================

const TOOL_DEFINITION = {
  type: "function" as const,
  function: {
    name: "generate_proactive_plan",
    description:
      "Generate a proactive parenting prevention plan using Regulate → Prepare → Boundary → Practice.",
    parameters: {
      type: "object",
      properties: {
        mode: { type: "string", enum: ["proactive"] },

        regulate: {
          type: "string",
          description: "Short grounding reminder for the parent.",
        },

        preScript: {
          type: "string",
          description: "One short sentence said BEFORE escalation.",
        },

        environmentShift: {
          type: "string",
          description:
            "One simple environmental adjustment (routine/space/transition).",
        },

        boundaryPlan: {
          type: "string",
          description:
            "Clear predictable boundary if behavior repeats (no threats).",
        },

        practicePrompt: {
          type: "string",
          description: "When and how to rehearse this plan.",
        },

        foundationTag: {
          type: "string",
          description: "Short growth label like 'Proactive Structure'.",
        },

        teaserTip: {
          type: "string",
          description: "Short universal tip (15-20 words).",
        },
      },
      required: [
        "mode",
        "regulate",
        "preScript",
        "environmentShift",
        "boundaryPlan",
        "practicePrompt",
        "foundationTag",
        "teaserTip",
      ],
      additionalProperties: false,
    },
  },
};

// ============================================================================
// SYSTEM PROMPT
// ============================================================================

const SYSTEM_PROMPT = `
You are Sturdy: calm, steady, warm, practical.

PROACTIVE MODE:
This is prevention — not crisis.

Structure:
1. REGULATE (parent mindset)
2. PRE-SCRIPT (what to say before escalation)
3. ENVIRONMENT SHIFT (small structural change)
4. BOUNDARY PLAN (predictable response)
5. PRACTICE PROMPT

Voice:
- Calm and confident.
- Short sentences.
- No shame.
- No lectures.
- No therapy jargon.
- Clear and realistic.

Return ONLY valid JSON using the function schema.
`;

// ============================================================================
// FALLBACK
// ============================================================================

const FALLBACK_RESPONSE = {
  mode: "proactive",
  regulate: "Pause. You don’t need to fix everything today.",
  preScript: "Before we start, I’m going to help you stay calm.",
  environmentShift: "Separate siblings before play starts.",
  boundaryPlan: "If hitting starts, we pause and reset.",
  practicePrompt: "Practice this once during a calm moment.",
  foundationTag: "Proactive Structure",
  teaserTip: "Consistency builds safety. Small daily shifts matter more than intensity.",
};

// ============================================================================
// MAIN HANDLER
// ============================================================================

function getSupabaseAdmin() {
  return createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const responseCorsHeaders = getCorsHeaders(req);

  try {
    // 🔐 Auth
    const { userId, error: authError } = await verifyAuth(req);

    if (authError || !userId) {
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        {
          status: 401,
          headers: {
            ...responseCorsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    // 💎 Paywall check (Proactive = premium feature)
    const access = await canAccessFeature(userId, "whatif");

    if (!access.allowed) {
      return new Response(
        JSON.stringify({
          error: access.reason || "Upgrade required",
          used: access.used,
          limit: access.limit,
        }),
        {
          status: 403,
          headers: {
            ...responseCorsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const body = await req.json();
    const { situation, childName, childAge, neurotype, category } = body;

    if (!situation) {
      return new Response(
        JSON.stringify({ error: "Missing situation" }),
        {
          status: 400,
          headers: {
            ...responseCorsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const scrubbedSituation = scrubPII(situation, childName);

    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");

    if (!OPENAI_API_KEY) {
      return new Response(
        JSON.stringify(FALLBACK_RESPONSE),
        {
          headers: {
            ...responseCorsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const userPrompt = `
SITUATION: "${scrubbedSituation}"
Child Age: ${childAge || "unspecified"}
Neurotype: ${neurotype || "neurotypical"}
Category: ${category || "unspecified"}

Create a proactive prevention plan.
`;

    const aiResponse = await fetch(OPENAI_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
        tools: [TOOL_DEFINITION],
        tool_choice: {
          type: "function",
          function: { name: "generate_proactive_plan" },
        },
        temperature: 0.6,
      }),
    });

    if (!aiResponse.ok) {
      return new Response(
        JSON.stringify(FALLBACK_RESPONSE),
        {
          headers: {
            ...responseCorsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const data = await aiResponse.json();
    const toolCall = data?.choices?.[0]?.message?.tool_calls?.[0];

    if (!toolCall?.function?.arguments) {
      return new Response(
        JSON.stringify(FALLBACK_RESPONSE),
        {
          headers: {
            ...responseCorsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    let plan;
    try {
      plan = JSON.parse(toolCall.function.arguments);
    } catch {
      return new Response(
        JSON.stringify(FALLBACK_RESPONSE),
        {
          headers: {
            ...responseCorsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    // Restore child name
    if (childName) {
      plan.regulate = restorePII(plan.regulate, childName);
      plan.preScript = restorePII(plan.preScript, childName);
      plan.environmentShift = restorePII(plan.environmentShift, childName);
      plan.boundaryPlan = restorePII(plan.boundaryPlan, childName);
      plan.practicePrompt = restorePII(plan.practicePrompt, childName);
    }

    // Log event
    try {
      const supabase = getSupabaseAdmin();
      await supabase.from("whatif_events").insert({
        user_id: userId,
        scenario: scrubbedSituation,
        child_age: childAge ?? null,
        neurotype: neurotype ?? null,
        category: category ?? null,
      });
    } catch (e) {
      console.warn("Logging failed:", e);
    }

    return new Response(JSON.stringify(plan), {
      headers: {
        ...responseCorsHeaders,
        "Content-Type": "application/json",
      },
    });
  } catch (err) {
    console.error("Proactive error:", err);

    return new Response(
      JSON.stringify(FALLBACK_RESPONSE),
      {
        headers: {
          ...responseCorsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
