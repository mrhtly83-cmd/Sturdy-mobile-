import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import Stripe from "npm:stripe@14.21.0";
import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, stripe-signature",
};

// All known Price IDs → tier mapping (supports old + new IDs)
const PRICE_TO_TIER: Record<string, string> = {
  // Current price IDs
  "price_1SxgDZ5WUEt6UXpad0pKdpLJ": "monthly",
  "price_1SxgKR5WUEt6UXpajgsmk21M": "annual",
  // Legacy price IDs (backwards compat)
  "price_1Sxm5k5WUEt6UXpaqUIWNJlF": "monthly",
  "price_1SxmFb5WUEt6UXpaE11w9Z74": "annual",
};

/**
 * Maps a Stripe price ID to subscription tier.
 */
function getTierFromPriceId(priceId: string): string {
  if (PRICE_TO_TIER[priceId]) {
    return PRICE_TO_TIER[priceId];
  }

  // Fallback: check keywords in price ID
  const lower = priceId.toLowerCase();
  if (lower.includes("annual") || lower.includes("yearly")) return "annual";
  if (lower.includes("monthly") || lower.includes("month")) return "monthly";
  if (lower.includes("lifetime")) return "lifetime";

  console.warn(`Unknown price ID: ${priceId}, defaulting to monthly`);
  return "monthly";
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
  const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!stripeSecretKey || !webhookSecret) {
    console.error("Missing Stripe configuration");
    return new Response(
      JSON.stringify({ error: "Webhook not configured" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (!supabaseUrl || !serviceRoleKey) {
    console.error("Missing Supabase configuration");
    return new Response(
      JSON.stringify({ error: "Database not configured" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const stripe = new Stripe(stripeSecretKey, { apiVersion: "2023-10-16" });
  const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);

  try {
    const body = await req.text();
    const signature = req.headers.get("stripe-signature");

    if (!signature) {
      console.error("No stripe-signature header");
      return new Response(
        JSON.stringify({ error: "No signature" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    } catch (err) {
      console.error("Webhook signature verification failed:", err.message);
      return new Response(
        JSON.stringify({ error: `Webhook signature verification failed: ${err.message}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Received webhook event: ${event.type}`);

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        console.log("Checkout session completed:", session.id);

        // Get user_id from client_reference_id (Payment Links) or metadata (Checkout Sessions)
        const userId = session.client_reference_id || session.metadata?.user_id;
        if (!userId) {
          console.error("No user_id in client_reference_id or session metadata");
          break;
        }

        const subscriptionId = session.subscription as string;
        if (subscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId);
          const priceId = subscription.items.data[0]?.price.id;
          const tier = priceId ? getTierFromPriceId(priceId) : "monthly";
          const status = subscription.status;

          console.log(`Updating user ${userId} to tier: ${tier}, status: ${status}`);

          const { error } = await supabaseAdmin
            .from("profiles")
            .update({
              subscription_tier: tier,
              subscription_status: status,
              stripe_customer_id: session.customer as string,
            })
            .eq("id", userId);

          if (error) {
            console.error("Error updating profile:", error);
          } else {
            console.log(`Successfully updated user ${userId} to ${tier} (${status})`);
          }
        }
        break;
      }

      case "customer.subscription.created": {
        const subscription = event.data.object as Stripe.Subscription;
        console.log("Subscription created:", subscription.id, "Status:", subscription.status);

        const userId = subscription.metadata?.user_id;
        if (!userId) {
          console.log("No user_id in subscription metadata, will rely on checkout.session.completed");
          break;
        }

        const priceId = subscription.items.data[0]?.price.id;
        const tier = priceId ? getTierFromPriceId(priceId) : "monthly";
        const status = subscription.status;

        const { error } = await supabaseAdmin
          .from("profiles")
          .update({
            subscription_tier: tier,
            subscription_status: status,
            stripe_customer_id: subscription.customer as string,
          })
          .eq("id", userId);

        if (error) {
          console.error("Error updating profile on subscription created:", error);
        } else {
          console.log(`Updated user ${userId} to ${tier} (${status}) on subscription created`);
        }
        break;
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        console.log("Subscription updated:", subscription.id, "Status:", subscription.status);

        const customerId = subscription.customer as string;
        const { data: profile, error: findError } = await supabaseAdmin
          .from("profiles")
          .select("id")
          .eq("stripe_customer_id", customerId)
          .maybeSingle();

        const priceId = subscription.items.data[0]?.price.id;

        if (!profile) {
          const userId = subscription.metadata?.user_id;
          if (!userId) {
            console.error("Could not find user for subscription update");
            break;
          }

          const tier = (subscription.status === "active" || subscription.status === "trialing")
            ? (priceId ? getTierFromPriceId(priceId) : "monthly")
            : "free";

          await supabaseAdmin
            .from("profiles")
            .update({
              subscription_tier: tier,
              subscription_status: subscription.status,
              stripe_customer_id: customerId,
            })
            .eq("id", userId);
        } else {
          let tier = "free";
          if (subscription.status === "active" || subscription.status === "trialing") {
            tier = priceId ? getTierFromPriceId(priceId) : "monthly";
          }

          const { error } = await supabaseAdmin
            .from("profiles")
            .update({
              subscription_tier: tier,
              subscription_status: subscription.status,
            })
            .eq("id", profile.id);

          if (error) {
            console.error("Error updating profile on subscription update:", error);
          } else {
            console.log(`Updated user ${profile.id} to tier: ${tier}, status: ${subscription.status}`);
          }
        }
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        console.log("Subscription deleted:", subscription.id);

        const customerId = subscription.customer as string;
        const { data: profile } = await supabaseAdmin
          .from("profiles")
          .select("id")
          .eq("stripe_customer_id", customerId)
          .maybeSingle();

        if (profile) {
          const { error } = await supabaseAdmin
            .from("profiles")
            .update({
              subscription_tier: "free",
              subscription_status: "canceled",
            })
            .eq("id", profile.id);

          if (error) {
            console.error("Error resetting profile tier:", error);
          } else {
            console.log(`Reset user ${profile.id} to free tier (canceled)`);
          }
        } else {
          const userId = subscription.metadata?.user_id;
          if (userId) {
            await supabaseAdmin
              .from("profiles")
              .update({
                subscription_tier: "free",
                subscription_status: "canceled",
              })
              .eq("id", userId);
            console.log(`Reset user ${userId} to free tier (via metadata)`);
          }
        }
        break;
      }

      case "invoice.paid": {
        const invoice = event.data.object as Stripe.Invoice;
        console.log("Invoice paid:", invoice.id, "Amount:", invoice.amount_paid);

        if (invoice.subscription) {
          const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
          const customerId = invoice.customer as string;

          const { data: profile } = await supabaseAdmin
            .from("profiles")
            .select("id")
            .eq("stripe_customer_id", customerId)
            .maybeSingle();

          if (profile && subscription.status === "active") {
            await supabaseAdmin
              .from("profiles")
              .update({ subscription_status: "active" })
              .eq("id", profile.id);
            console.log(`Updated user ${profile.id} status to active after invoice paid`);
          }
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        console.error("Invoice payment failed:", invoice.id);

        if (invoice.subscription) {
          const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
          const customerId = invoice.customer as string;

          const { data: profile } = await supabaseAdmin
            .from("profiles")
            .select("id")
            .eq("stripe_customer_id", customerId)
            .maybeSingle();

          if (profile) {
            if (subscription.status === "past_due" || subscription.status === "unpaid") {
              await supabaseAdmin
                .from("profiles")
                .update({ subscription_status: subscription.status })
                .eq("id", profile.id);
              console.log(`Updated user ${profile.id} status to ${subscription.status}`);
            }
          }
        }
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return new Response(
      JSON.stringify({ received: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Webhook error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Webhook handler failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
