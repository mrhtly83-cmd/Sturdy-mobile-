import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.45.0";
import Stripe from "npm:stripe@14.21.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Price IDs — keep ALL known IDs for compatibility
const ANNUAL_PRICE_IDS = [
  "price_1SxgKR5WUEt6UXpajgsmk21M",
  "price_1SxmFb5WUEt6UXpaE11w9Z74",
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    console.log("------- CHECKOUT FUNCTION STARTED -------");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) {
      console.error("CRITICAL: STRIPE_SECRET_KEY is missing.");
      throw new Error("Server Misconfiguration: Stripe Key missing");
    }

    // Authenticate the user
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError || !user) {
      console.error("User not authenticated:", userError);
      throw new Error("User not logged in");
    }

    const { priceId } = await req.json();
    console.log(`User ${user.id} wants to buy price: ${priceId}`);

    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });

    // Apply 7-day trial for annual plans
    let subscriptionData: Record<string, unknown> = {};
    if (ANNUAL_PRICE_IDS.includes(priceId)) {
      console.log("✅ Annual Plan detected: Applying 7-Day Trial");
      subscriptionData = { trial_period_days: 7 };
    } else {
      console.log("ℹ️ Monthly Plan: Charging immediately (No Trial)");
    }

    // Build success/cancel URLs from request origin
    const origin = req.headers.get("origin") || "https://lovable.dev";

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [{ price: priceId, quantity: 1 }],
      subscription_data: subscriptionData,
      mode: "subscription",
      success_url: `${origin}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/pricing`,
      customer_email: user.email,
      client_reference_id: user.id,
      metadata: { user_id: user.id },
    });

    console.log("Session created! URL:", session.url);

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("🚨 CRASH:", error.message);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
